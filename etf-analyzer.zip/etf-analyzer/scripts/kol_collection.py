"""主观资料协调，不包含数据源HTTP实现。"""
from __future__ import annotations

from typing import Any, Iterable
from kol_config import add_kol_source_to_config, load_kol_sources
from source_common import KOL_SOURCES_FILE
from source_douyin import load_douyin_transcripts
from source_xueqiu import _fetch_single_xueqiu_kol, _load_cached_xueqiu_cookie, _refresh_xueqiu_cookie_via_playwright


def fetch_kol_columns(
    extra_users: Iterable[str] = (),
    *,
    limit_override: int | None = None,
) -> dict[str, Any]:
    """获取所有已配置知名博主的最新专栏/复盘文章（Cookie缓存极速直连 + Playwright无头浏览器自动降级）。"""
    sources = load_kol_sources(extra_users=extra_users, limit_override=limit_override)
    if not sources:
        return {"available": False, "kol_list": []}

    xueqiu_sources = [s for s in sources if s.get("platform", "xueqiu") == "xueqiu"]
    cookie_str = _load_cached_xueqiu_cookie() if xueqiu_sources else None
    refreshed = False
    if xueqiu_sources and not cookie_str:
        cookie_str = _refresh_xueqiu_cookie_via_playwright(seed_uid=xueqiu_sources[0]["id"])
        refreshed = True

    kol_results: list[dict[str, Any]] = []
    for src in sources:
        if src.get("platform") == "douyin":
            kol_results.append(load_douyin_transcripts(src))
            continue
        if src.get("platform", "xueqiu") != "xueqiu":
            kol_results.append({"id": src["id"], "name": src.get("name"),
                                "platform": src.get("platform"), "articles": [],
                                "article_count": 0, "error": "尚未支持此平台"})
            continue
        res: dict[str, Any] | None = None
        need_refresh = True
        if cookie_str:
            res, need_refresh = _fetch_single_xueqiu_kol(src, cookie_str=cookie_str)
        if (res is None or need_refresh) and not refreshed:
            cookie_str = _refresh_xueqiu_cookie_via_playwright(seed_uid=src["id"])
            refreshed = True
            if cookie_str:
                res, _ = _fetch_single_xueqiu_kol(src, cookie_str=cookie_str)
        if res is not None:
            kol_results.append(res)
            if src.get("name", "").startswith("雪球博主_") and res.get("name") and not res["name"].startswith("雪球博主_"):
                try:
                    add_kol_source_to_config(src["id"], name=res["name"], style=src.get("style", ""))
                except Exception:
                    pass
        else:
            kol_results.append(
                {
                    "id": src["id"],
                    "name": src.get("name"),
                    "platform": src.get("platform", "xueqiu"),
                    "style": src.get("style", ""),
                    "profile_url": src.get("url"),
                    "article_count": 0,
                    "articles": [],
                    "error": "未能获取到最新专栏文章（可能触发访问保护或网络超时）",
                }
            )

    return {
        "available": any(k.get("article_count", 0) > 0 for k in kol_results),
        "config_file": str(KOL_SOURCES_FILE),
        "kol_count": len(kol_results),
        "kol_list": kol_results,
    }
