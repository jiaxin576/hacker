"""独立来源CLI的参数、中文状态和原始结果保存；不包含采集实现。"""
import argparse
from dataclasses import asdict,is_dataclass
from datetime import datetime
import json
from pathlib import Path


def _serialize(value):
    if is_dataclass(value):return asdict(value)
    return str(value)


def run_source_cli(provider,handlers,configure=None):
    parser=argparse.ArgumentParser(description=f'{provider}独立采集调试；不运行其他来源或完整分析')
    parser.add_argument('--mode',choices=list(handlers),default=next(iter(handlers)))
    parser.add_argument('--symbol',default='159338',help='单只证券代码')
    parser.add_argument('--keyword',default='人工智能',help='新闻检索关键词')
    parser.add_argument('--author',help='已配置作者编号')
    parser.add_argument('--url',help='公开原文链接')
    parser.add_argument('--limit',type=int,default=10)
    parser.add_argument('--days',type=int,default=7)
    parser.add_argument('--output',type=Path,help='结果JSON路径；默认outputs/debug/')
    if configure is not None: configure(parser)
    args=parser.parse_args()
    if args.limit<=0 or args.days<=0:parser.error('数量和天数必须大于0')
    now=datetime.now().astimezone()
    try:
        data=handlers[args.mode](args)
        missing=not data or (isinstance(data,dict) and (data.get('available') is False or data.get('error')))
        status_map={'failed':'采集失败','blocked':'访问受限','partial':'部分取得','ok':'已取得，待核验','no_update':'已检查，未发现更新'}
        result={'来源':provider,'模式':args.mode,'采集时间':now.isoformat(),'状态':status_map.get(data.get('status')) if isinstance(data,dict) and data.get('status') in status_map else ('部分取得或无可用记录' if missing else '已取得返回值，待核验'),
                '原因':data.get('reason') if isinstance(data,dict) else None,
                '原始数据':data}
    except Exception as exc:
        result={'来源':provider,'模式':args.mode,'采集时间':now.isoformat(),'状态':'采集失败',
                '错误类型':type(exc).__name__,'原因':str(exc),'原始数据':None}
    path=args.output or Path('outputs/debug')/f'{provider}_{args.mode}_{now:%Y%m%d_%H%M%S}.json'
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2,default=_serialize),encoding='utf-8')
    print(json.dumps({'来源':provider,'模式':args.mode,'状态':result['状态'],'结果文件':str(path.resolve()),
                      '原因':result.get('原因')},ensure_ascii=False,indent=2))
    return result
