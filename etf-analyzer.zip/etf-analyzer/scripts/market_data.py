"""跨源行情协调与份额归档，不包含HTTP采集实现。"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
from source_common import DEFAULT_KLINE_LIMIT, DEFAULT_WEEKLY_KLINE_LIMIT, DailyBar, ETF_SHARE_CHANGE_SUSPECT_PCT, Quote, SKILL_DIR, _clean_text, _num, _pct_change, symbol_to_secid
from source_eastmoney_kline import fetch_eastmoney_bars
from source_sse import enrich_with_sse_snapshot
from source_tencent import fetch_tencent_bars, fetch_tencent_quotes
from source_tushare import _fetch_remote_etf_share_history


def resolve_security(raw_symbol: str) -> tuple[str, Quote]:
    """解析证券代码并获取实时行情，自动在沪深市场间容错确认。"""
    secid, t_code, sym = symbol_to_secid(raw_symbol)
    alt_t_code = f"sz{sym}" if t_code.startswith("sh") else f"sh{sym}"
    quotes = fetch_tencent_quotes([t_code, alt_t_code])
    for candidate in (t_code, alt_t_code):
        q = quotes.get(candidate)
        if q and q.symbol == sym and (q.name or q.current_price is not None):
            q = enrich_with_sse_snapshot(q)
            return q.secid, q
    raise RuntimeError(f"未能获取到证券 {raw_symbol} 的有效实时行情")

def fetch_daily_bars(secid: str, *, limit: int = DEFAULT_KLINE_LIMIT, quote: Quote | None = None) -> list[DailyBar]:
    """获取前复权日K线（东方财富与腾讯前复权日K自动互备，并用实时精确价修正盘中最新K线）。"""
    bars = []
    for provider in (fetch_eastmoney_bars, fetch_tencent_bars):
        try:
            bars = provider(secid, period='day', limit=limit)
        except Exception:
            continue
        if bars:
            break
    if not bars:
        raise RuntimeError(f'未取得 {secid} 的可用前复权日K线')
    # 若腾讯日K最后一条是今日盘中数据（有时仅保留2位小数），用实时报价的3位小数精确值修正
    if quote and quote.quote_time and bars:
        q_date = quote.quote_time[:10]
        if bars[-1].date == q_date and quote.current_price is not None:
            prev_close = bars[-2].close if len(bars) >= 2 else quote.prev_close
            bars[-1] = DailyBar(
                date=q_date,
                open=quote.open_price or bars[-1].open,
                close=quote.current_price,
                high=quote.high_price or bars[-1].high,
                low=quote.low_price or bars[-1].low,
                volume=quote.volume or bars[-1].volume,
                amount=quote.amount or bars[-1].amount,
                amplitude_percent=quote.amplitude_percent or bars[-1].amplitude_percent,
                change_percent=quote.change_percent or _pct_change(quote.current_price, prev_close),
                change_amount=quote.change_amount
                or (round(quote.current_price - prev_close, 4) if prev_close else None),
                turnover_rate=quote.turnover_rate,
            )
    return bars

def fetch_weekly_bars(
    secid: str,
    *,
    limit: int = DEFAULT_WEEKLY_KLINE_LIMIT,
    quote: Quote | None = None,
) -> list[DailyBar]:
    """获取前复权周K线（东方财富 klt=102 与腾讯 qfqweek 自动互备，并用实时精确价修正本周最新K线）。"""
    bars = []
    for provider in (fetch_eastmoney_bars, fetch_tencent_bars):
        try:
            bars = provider(secid, period='week', limit=limit)
        except Exception:
            continue
        if bars:
            break
    if quote and quote.current_price is not None and bars:
        last_bar = bars[-1]
        q_date = (quote.quote_time or "")[:10]
        try:
            b_dt = datetime.strptime(last_bar.date[:10], "%Y-%m-%d")
            q_dt = datetime.strptime(q_date, "%Y-%m-%d") if q_date else b_dt
            same_week = abs((q_dt - b_dt).days) <= 6 and q_dt.isocalendar()[:2] == b_dt.isocalendar()[:2]
        except Exception:
            same_week = (q_date == last_bar.date)
        if same_week:
            prev_w_close = bars[-2].close if len(bars) >= 2 else last_bar.open
            new_high = max(x for x in (last_bar.high, quote.high_price, quote.current_price) if x is not None)
            new_low = min(x for x in (last_bar.low, quote.low_price, quote.current_price) if x is not None)
            bars[-1] = DailyBar(
                date=q_date or last_bar.date,
                open=last_bar.open,
                close=quote.current_price,
                high=new_high,
                low=new_low,
                volume=last_bar.volume,
                amount=last_bar.amount,
                amplitude_percent=(
                    round((new_high - new_low) / prev_w_close * 100.0, 2)
                    if prev_w_close not in (None, 0)
                    else last_bar.amplitude_percent
                ),
                change_percent=_pct_change(quote.current_price, prev_w_close, digits=2),
                change_amount=(
                    round(quote.current_price - prev_w_close, 4) if prev_w_close is not None else last_bar.change_amount
                ),
                turnover_rate=last_bar.turnover_rate,
            )
    return bars

def update_etf_share_archive(
    quote: Quote, trade_date: str, bars: list[DailyBar] | None = None
) -> dict[str, Any]:
    """按日归档 ETF 份额，自动回填官方历史份额序列，计算近1日/5日/20日份额变化率与净申赎趋势。"""
    shares = quote.total_shares
    if shares is None and quote.total_market_value and quote.current_price:
        shares = quote.total_market_value / quote.current_price
    if not shares or shares <= 0:
        return {"available": False, "usable_for_statistics": False, "reason": "未取得有效总份额或总市值"}

    data_dir = SKILL_DIR / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    path = data_dir / f"etf_share_history_{quote.symbol}.json"
    legacy_path = Path(f"/media/vdb/PycharmProjects/pythonProject/stock/data/etf_share_history_{quote.symbol}.json")

    records: list[dict[str, Any]] = []
    for p in (legacy_path, path):
        if p.exists():
            try:
                loaded = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(loaded, list):
                    records.extend(x for x in loaded if isinstance(x, dict))
            except Exception:
                continue

    dedup: dict[str, dict[str, Any]] = {
        _clean_text(r.get("trade_date")): r for r in records if _clean_text(r.get("trade_date"))
    }

    price_by_date: dict[str, float] = {}
    if bars:
        for b in bars:
            if b.date and b.close is not None:
                price_by_date[b.date[:10]] = b.close

    # 若本地有效历史交易日不足 22 天，或缺少近期连续序列，自动拉取远程官方历史份额回填
    remote_shares = _fetch_remote_etf_share_history(quote.symbol, quote.market, limit=35)
    for dt_str, sh_val in remote_shares.items():
        hist_p = price_by_date.get(dt_str)
        existing = dedup.get(dt_str) or {}
        dedup[dt_str] = {
            "trade_date": dt_str,
            "known_at": existing.get("known_at") or quote.collected_at,
            "price": existing.get("price") or hist_p,
            "total_market_value": (
                round(sh_val * hist_p, 2) if hist_p else existing.get("total_market_value")
            ),
            "estimated_shares": sh_val,
            "source": "official_fund_share",
        }

    # 今日最新份额：若远程已披露今日官方份额则优先采用，否则使用实时行情的 total_shares
    today_shares = remote_shares.get(trade_date) or round(shares, 2)
    dedup[trade_date] = {
        "trade_date": trade_date,
        "known_at": quote.collected_at,
        "price": quote.current_price,
        "total_market_value": quote.total_market_value,
        "estimated_shares": today_shares,
    }
    sorted_dates = sorted(d for d in dedup if _num(dedup[d].get("estimated_shares")))
    sorted_records = [dedup[k] for k in sorted_dates][-400:]
    path.write_text(json.dumps(sorted_records, ensure_ascii=False, indent=2), encoding="utf-8")

    shares_yi = round(today_shares / 1e8, 2)
    mv_yi = round(quote.total_market_value / 1e8, 2) if quote.total_market_value else None

    prev_dates = [d for d in sorted_dates if d < trade_date]
    if not prev_dates:
        return {
            "available": True,
            "usable_for_statistics": False,
            "status": "baseline_only",
            "current_trade_date": trade_date,
            "shares_yi": shares_yi,
            "market_value_yi": mv_yi,
            "note": "首次建立份额归档基线",
        }

    def _calc_window(lookback_idx: int) -> dict[str, Any]:
        if len(prev_dates) < lookback_idx:
            base_dt = prev_dates[0]
        else:
            base_dt = prev_dates[-lookback_idx]
        base_rec = dedup[base_dt]
        base_sh = _num(base_rec.get("estimated_shares"))
        chg_pct = _pct_change(today_shares, base_sh, digits=2)
        suspected_split = bool(chg_pct is not None and abs(chg_pct) >= ETF_SHARE_CHANGE_SUSPECT_PCT)
        diff_sh_yi = round((today_shares - base_sh) / 1e8, 2) if base_sh and not suspected_split else None
        ref_price = quote.current_price or price_by_date.get(trade_date) or _num(base_rec.get("price")) or 1.0
        net_amt_yi = (
            round((today_shares - base_sh) * ref_price / 1e8, 2)
            if base_sh and not suspected_split
            else None
        )
        return {
            "base_date": base_dt,
            "base_shares_yi": round(base_sh / 1e8, 2) if base_sh else None,
            "share_change_pct": chg_pct,
            "net_shares_yi": diff_sh_yi,
            "net_amount_yi": net_amt_yi,
            "suspected_split": suspected_split,
        }

    w1 = _calc_window(1)
    w5 = _calc_window(5)
    w20 = _calc_window(20)

    # 统计近5个交易日每日净申购/净赎回天数
    recent_6_dates = (prev_dates + [trade_date])[-6:]
    inflow_5d = outflow_5d = flat_5d = 0
    for i in range(1, len(recent_6_dates)):
        s_cur = _num(dedup[recent_6_dates[i]].get("estimated_shares"))
        s_prv = _num(dedup[recent_6_dates[i - 1]].get("estimated_shares"))
        if s_cur and s_prv:
            if s_cur - s_prv > 10000:
                inflow_5d += 1
            elif s_cur - s_prv < -10000:
                outflow_5d += 1
            else:
                flat_5d += 1

    # 近20日份额分位数
    recent_20_shares = [
        _num(dedup[d].get("estimated_shares"))
        for d in (prev_dates + [trade_date])[-20:]
        if _num(dedup[d].get("estimated_shares")) is not None
    ]
    sh_pctile_20d = (
        round(sum(1 for x in recent_20_shares if x <= today_shares) / len(recent_20_shares) * 100.0, 1)
        if recent_20_shares
        else None
    )

    chg_pct = w1["share_change_pct"]
    suspected = w1["suspected_split"]
    state_cn = ("份额变化异常，待核查折算/拆分" if suspected else
                "单日份额变化缺失" if chg_pct is None else f"单日份额变化{chg_pct:+.2f}%")
    s5 = w5.get("share_change_pct")
    s20 = w20.get("share_change_pct")
    trend_summary = f"近5日份额变化={s5}%；近20日份额变化={s20}%（不推断资金动机）"

    return {
        "available": True,
        "usable_for_statistics": not suspected,
        "status": state_cn,
        "trend_5d_20d_summary": trend_summary,
        "current_trade_date": trade_date,
        "previous_trade_date": w1["base_date"],
        "shares_yi": shares_yi,
        "market_value_yi": mv_yi,
        "share_percentile_20d_pct": sh_pctile_20d,
        "share_change_pct": chg_pct,
        "net_creation_shares_yi": w1["net_shares_yi"],
        "net_creation_amount_yi": w1["net_amount_yi"],
        "change_1d": w1,
        "change_5d": {
            **w5,
            "inflow_days": inflow_5d,
            "outflow_days": outflow_5d,
            "flat_days": flat_5d,
        },
        "change_20d": w20,
        "recent_share_series": [
            {
                "date": d,
                "shares_yi": round((_num(dedup[d].get("estimated_shares")) or 0) / 1e8, 2),
                "price": dedup[d].get("price") or price_by_date.get(d),
            }
            for d in (prev_dates + [trade_date])[-10:]
        ],
    }
