"""上交所：ETF官方参考净值快照。"""
from __future__ import annotations

import logging
from source_common import Quote, SSE_SNAPSHOT_URL, _num, _pct_change, _session


def enrich_with_sse_snapshot(quote: Quote) -> Quote:
    """对上交所 ETF 补充上交所官方快照 IOPV/NAV 与五档盘口校验。"""
    if quote.market != 1 or not quote.symbol.startswith(("51", "56", "58")):
        return quote
    try:
        session = _session()
        resp = session.get(
            SSE_SNAPSHOT_URL.format(symbol=quote.symbol),
            params={"select": "name,last,prev_close,nav,iopv,volume,amount,bid,ask"},
            headers={"Referer": "https://www.sse.com.cn/"},
            timeout=6,
        )
        resp.raise_for_status()
        snap = (resp.json() or {}).get("snap") or []
        if len(snap) >= 9:
            sse_iopv = _num(snap[4])
            sse_nav = _num(snap[3])
            if sse_iopv and sse_iopv > 0:
                quote.iopv = sse_iopv
                if quote.current_price:
                    quote.premium_pct = _pct_change(quote.current_price, sse_iopv, digits=3)
            if sse_nav and sse_nav > 0 and not quote.nav:
                quote.nav = sse_nav
            quote.source = "Tencent + SSE Official"
    except Exception as exc:
        logging.debug("上交所官方快照补充跳过 (%s): %s", quote.symbol, exc)
    return quote


if __name__ == '__main__':
    from source_debug import run_source_cli
    from source_tencent import fetch_tencent_quotes
    from source_common import symbol_to_secid
    def snapshot(args):
        secid,code,symbol=symbol_to_secid(args.symbol)
        if not secid.startswith('1.'):raise ValueError('上交所快照请选择上海ETF，例如515180')
        quote=fetch_tencent_quotes([code]).get(code)
        if quote is None:raise RuntimeError('未取得用于快照核对的基础行情')
        return enrich_with_sse_snapshot(quote)
    run_source_cli('上交所快照',{'snapshot':snapshot})
