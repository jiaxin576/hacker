"""东方财富：历史日周K接口。"""
from __future__ import annotations

from source_common import DailyBar, EASTMONEY_HISTORY_BASES, _num, _session


def fetch_eastmoney_bars(secid: str, *, period: str = "day", limit: int = 260) -> list[DailyBar]:
    bars: list[DailyBar] = []
    session = _session()
    params = {
        "secid": secid,
        "klt": "102" if period == "week" else "101",
        "fqt": "1",
        "lmt": str(limit),
        "end": "20500101",
        "iscca": "1",
        "fields1": "f1,f2,f3,f4,f5,f6",
        "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
        "ut": "fa5fd1943c7b386f172d6893dbfba10b",
    }
    for base in EASTMONEY_HISTORY_BASES:
        try:
            resp = session.get(
                f"{base}/stock/kline/get",
                params=params,
                headers={"Referer": "https://quote.eastmoney.com/"},
                timeout=6,
            )
            if resp.status_code == 200:
                klines = ((resp.json().get("data") or {}).get("klines")) or []
                if klines:
                    for item in klines:
                        parts = str(item).split(",")
                        if len(parts) >= 11:
                            bars.append(
                                DailyBar(
                                    date=parts[0],
                                    open=_num(parts[1]),
                                    close=_num(parts[2]),
                                    high=_num(parts[3]),
                                    low=_num(parts[4]),
                                    volume=_num(parts[5]),
                                    amount=_num(parts[6]),
                                    amplitude_percent=_num(parts[7]),
                                    change_percent=_num(parts[8]),
                                    change_amount=_num(parts[9]),
                                    turnover_rate=_num(parts[10]),
                                )
                            )
                    break
        except Exception:
            continue

    return bars



if __name__ == '__main__':
    from source_debug import run_source_cli
    from source_common import symbol_to_secid
    run_source_cli('东方财富K线',{'daily':lambda a:fetch_eastmoney_bars(symbol_to_secid(a.symbol)[0],limit=a.limit),
        'weekly':lambda a:fetch_eastmoney_bars(symbol_to_secid(a.symbol)[0],period='week',limit=a.limit)})
