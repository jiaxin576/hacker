"""东方财富：市场宽度、宏观商品与全A两融。"""
from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from statistics import mean, pstdev
from typing import Any, Iterable
from source_common import EASTMONEY_BASE, EASTMONEY_DATACENTER_URL, EASTMONEY_DELAY_BASE, EASTMONEY_HISTORY_BASES, GLOBAL_MACRO_TARGETS, REQUEST_TIMEOUT, _num, _pct_change, _round, _session
from technical_indicators import _streaks


def fetch_market_margin_context() -> dict[str, Any]:
    """获取全A(沪深京)两融余额、融资净买入(1日/3日/5日/10日/20日)及连增/连降趋势。"""
    session = _session()
    try:
        resp = session.get(
            EASTMONEY_DATACENTER_URL,
            params={
                "reportName": "RPTA_RZRQ_LSHJ",
                "columns": "ALL",
                "pageSize": "25",
                "sortColumns": "DIM_DATE",
                "sortTypes": "-1",
            },
            headers={"Referer": "https://data.eastmoney.com/"},
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        rows = ((resp.json().get("result") or {}).get("data")) or []
    except Exception as exc:
        logging.warning("获取全A两融数据失败: %s", exc)
        return {"available": False, "error": str(exc)}

    if not rows:
        return {"available": False}

    latest = rows[0]
    date_str = str(latest.get("DIM_DATE") or "")[:10]
    total_margin_yi = _round((_num(latest.get("RZRQYE")) or 0) / 1e8, 2)
    fin_balance_yi = _round((_num(latest.get("RZYE")) or 0) / 1e8, 2)
    loan_balance_yi = _round((_num(latest.get("RQYE")) or 0) / 1e8, 2)
    fin_mv_ratio_pct = _round(_num(latest.get("RZYEZB")), 2)
    net_1d_yi = _round((_num(latest.get("RZJME")) or 0) / 1e8, 2)
    net_3d_yi = _round((_num(latest.get("RZJME3D")) or 0) / 1e8, 2)
    net_5d_yi = _round((_num(latest.get("RZJME5D")) or 0) / 1e8, 2)
    net_10d_yi = _round((_num(latest.get("RZJME10D")) or 0) / 1e8, 2)

    net_20d_vals = [_num(r.get("RZJME")) for r in rows[:20] if _num(r.get("RZJME")) is not None]
    net_20d_yi = _round(sum(net_20d_vals) / 1e8, 2) if net_20d_vals else None

    fin_20d_ago = _num(rows[min(len(rows) - 1, 20)].get("RZYE"))
    fin_now_raw = _num(latest.get("RZYE"))
    fin_chg_20d_pct = _pct_change(fin_now_raw, fin_20d_ago, digits=2)

    # 计算融资余额连增/连降天数
    fin_series = [_num(r.get("RZYE")) for r in reversed(rows) if _num(r.get("RZYE")) is not None]
    up_streak, down_streak = _streaks([float(x) for x in fin_series if x is not None])

    if down_streak >= 3:
        status = f"融资余额 {down_streak} 连降（单日 {net_1d_yi:+.2f}亿 / 近5日 {net_5d_yi:+.2f}亿 / 近10日 {net_10d_yi:+.2f}亿，杠杆资金持续去化）"
    elif up_streak >= 3:
        status = f"融资余额 {up_streak} 连增（单日 {net_1d_yi:+.2f}亿 / 近5日 {net_5d_yi:+.2f}亿 / 近10日 {net_10d_yi:+.2f}亿，杠杆资金持续加仓）"
    elif net_1d_yi is not None and net_5d_yi is not None:
        status = f"单日融资净买入 {net_1d_yi:+.2f}亿 | 近5日累计 {net_5d_yi:+.2f}亿 | 近10日累计 {net_10d_yi:+.2f}亿"
    else:
        status = "两融余额平稳"

    return {
        "available": True,
        "date": date_str,
        "total_margin_balance_yi": total_margin_yi,
        "fin_balance_yi": fin_balance_yi,
        "loan_balance_yi": loan_balance_yi,
        "fin_ratio_of_float_mv_pct": fin_mv_ratio_pct,
        "net_buy_1d_yi": net_1d_yi,
        "net_buy_3d_yi": net_3d_yi,
        "net_buy_5d_yi": net_5d_yi,
        "net_buy_10d_yi": net_10d_yi,
        "net_buy_20d_yi": net_20d_yi,
        "fin_change_20d_pct": fin_chg_20d_pct,
        "up_streak_days": up_streak,
        "down_streak_days": down_streak,
        "status_summary": status,
    }

def fetch_global_macro_and_commodities() -> dict[str, dict[str, Any]]:
    """获取亚太股指(韩国KOSPI/日经225)、费城半导体、美债/中债10年期收益率、美元/离岸人民币汇率及原油/黄金/棕榈油行情。"""
    session = _session()
    results: dict[str, dict[str, Any]] = {}

    def _fetch_one(key: str, secid: str, name: str, category: str) -> tuple[str, dict[str, Any] | None]:
        for base in EASTMONEY_HISTORY_BASES:
            try:
                resp = session.get(
                    f"{base}/stock/kline/get",
                    params={
                        "secid": secid,
                        "klt": "101",
                        "fqt": "1",
                        "lmt": "6",
                        "end": "20500101",
                        "fields1": "f1,f2,f3",
                        "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
                    },
                    headers={"Referer": "https://quote.eastmoney.com/"},
                    timeout=6,
                )
                if resp.status_code != 200:
                    continue
                klines = ((resp.json().get("data") or {}).get("klines")) or []
                if not klines:
                    continue
                last = str(klines[-1]).split(",")
                prev = str(klines[-2]).split(",") if len(klines) >= 2 else None
                first = str(klines[0]).split(",")
                close_now = _num(last[2])
                close_first = _num(first[2])
                ret_5d = _pct_change(close_now, close_first, digits=2) if len(klines) >= 5 else None
                return key, {
                    "name": name,
                    "secid": secid,
                    "category": category,
                    "date": last[0],
                    "price": close_now,
                    "change_pct": _num(last[8]),
                    "prev_change_pct": _num(prev[8]) if prev and len(prev) > 8 else None,
                    "return_5d_pct": ret_5d,
                    "high": _num(last[3]),
                    "low": _num(last[4]),
                }
            except Exception:
                continue
        return key, None

    with ThreadPoolExecutor(max_workers=6) as pool:
        futs = [
            pool.submit(_fetch_one, k, sid, name, cat)
            for k, (sid, name, cat) in GLOBAL_MACRO_TARGETS.items()
        ]
        for fut in as_completed(futs):
            try:
                k, val = fut.result()
                if val:
                    results[k] = val
            except Exception:
                continue
    return {k: results[k] for k in GLOBAL_MACRO_TARGETS if k in results}

def _trading_elapsed_minutes(now: datetime) -> int | None:
    """计算 A 股当日已交易分钟数（0~240），盘后或周末返回 240。"""
    if now.weekday() >= 5:
        return 240
    hm = now.hour * 60 + now.minute
    open_am, close_am = 9 * 60 + 30, 11 * 60 + 30
    open_pm, close_pm = 13 * 60, 15 * 60
    if hm < open_am:
        return 0
    if hm <= close_am:
        return max(1, hm - open_am)
    if hm < open_pm:
        return 120
    if hm <= close_pm:
        return 120 + (hm - open_pm)
    return 240

def fetch_market_breadth_and_volume(analysis_time: datetime) -> dict[str, Any]:
    """获取全A(沪深两市)实时涨跌家数宽度、历史总成交额及相对60日/120日峰值的缩量率(历史成交额比例统计)。"""
    session = _session()
    breadth: dict[str, Any] = {}
    for base in (EASTMONEY_BASE, EASTMONEY_DELAY_BASE):
        try:
            r = session.get(
                f"{base}/ulist.np/get",
                params={
                    "fltt": "2",
                    "invt": "2",
                    "fields": "f12,f14,f2,f3,f6,f104,f105,f106",
                    "secids": "1.000001,0.399001",
                },
                headers={"Referer": "https://quote.eastmoney.com/"},
                timeout=6,
            )
            diffs = ((r.json().get("data") or {}).get("diff")) or []
            if diffs:
                up_total = sum(int(_num(d.get("f104")) or 0) for d in diffs)
                down_total = sum(int(_num(d.get("f105")) or 0) for d in diffs)
                flat_total = sum(int(_num(d.get("f106")) or 0) for d in diffs)
                rt_amt_yi = round(sum((_num(d.get("f6")) or 0.0) for d in diffs) / 1e8, 2)
                total_stocks = up_total + down_total + flat_total
                breadth = {
                    "up_count": up_total,
                    "down_count": down_total,
                    "flat_count": flat_total,
                    "up_ratio_pct": round(up_total / total_stocks * 100.0, 1) if total_stocks > 0 else None,
                    "realtime_total_amount_yi": rt_amt_yi,
                }
                break
        except Exception:
            continue

    def _idx_daily_amt(secid: str) -> dict[str, float]:
        for base in EASTMONEY_HISTORY_BASES:
            try:
                r = session.get(
                    f"{base}/stock/kline/get",
                    params={
                        "secid": secid,
                        "klt": "101",
                        "fqt": "1",
                        "lmt": "130",
                        "end": "20500101",
                        "fields1": "f1,f2,f3",
                        "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
                    },
                    headers={"Referer": "https://quote.eastmoney.com/"},
                    timeout=6,
                )
                kl = ((r.json().get("data") or {}).get("klines")) or []
                if kl:
                    res: dict[str, float] = {}
                    for item in kl:
                        ps = str(item).split(",")
                        if len(ps) >= 7 and _num(ps[6]) is not None:
                            res[ps[0]] = float(ps[6]) / 1e8
                    return res
            except Exception:
                continue
        return {}

    sh_amt = _idx_daily_amt("1.000001")
    sz_amt = _idx_daily_amt("0.399001")
    common_dates = sorted(set(sh_amt.keys()) & set(sz_amt.keys()))
    if not common_dates:
        return {"available": False, **breadth}

    daily_totals = [(d, round(sh_amt[d] + sz_amt[d], 2)) for d in common_dates]
    today_str = analysis_time.strftime("%Y-%m-%d")
    elapsed_min = _trading_elapsed_minutes(analysis_time) or 240
    is_intraday = daily_totals[-1][0] == today_str and 0 < elapsed_min < 240

    full_days = daily_totals[:-1] if is_intraday and len(daily_totals) >= 2 else daily_totals
    peak_60 = max(full_days[-60:], key=lambda x: x[1])
    peak_120 = max(full_days[-120:], key=lambda x: x[1])
    last_full_date, last_full_amt = full_days[-1]
    min_5d_date, min_5d_amt = min(full_days[-5:], key=lambda x: x[1])
    avg_5d_amt = round(mean([x[1] for x in full_days[-5:]]), 2)
    avg_20d_amt = round(mean([x[1] for x in full_days[-20:]]), 2)

    last_vs_60 = round(last_full_amt / peak_60[1] * 100.0, 1) if peak_60[1] > 0 else None
    last_vs_120 = round(last_full_amt / peak_120[1] * 100.0, 1) if peak_120[1] > 0 else None
    min5_vs_60 = round(min_5d_amt / peak_60[1] * 100.0, 1) if peak_60[1] > 0 else None
    min5_vs_120 = round(min_5d_amt / peak_120[1] * 100.0, 1) if peak_120[1] > 0 else None

    # 只返回已观测成交额，不外推全天成交额或判断市场底部。
    ref_ratios = [r for r in (last_vs_120, min5_vs_120, last_vs_60, min5_vs_60) if r is not None]
    min_ratio = min(ref_ratios) if ref_ratios else None
    shrink_status = f"已完成交易日成交额比例最小值={min_ratio}%"

    return {
        "available": True,
        **breadth,
        "is_intraday": is_intraday,
        "elapsed_trading_minutes": elapsed_min,
        "last_full_day_date": last_full_date,
        "last_full_day_amount_yi": last_full_amt,
        "last_full_vs_60d_peak_pct": last_vs_60,
        "last_full_vs_120d_peak_pct": last_vs_120,
        "min_5d_full_date": min_5d_date,
        "min_5d_full_amount_yi": min_5d_amt,
        "min_5d_vs_60d_peak_pct": min5_vs_60,
        "min_5d_vs_120d_peak_pct": min5_vs_120,
        "avg_5d_amount_yi": avg_5d_amt,
        "avg_20d_amount_yi": avg_20d_amt,
        "peak_60d_date": peak_60[0],
        "peak_60d_amount_yi": peak_60[1],
        "peak_120d_date": peak_120[0],
        "peak_120d_amount_yi": peak_120[1],
        "volume_shrinkage_status": shrink_status,
        "recent_10d_amounts_yi": [{"date": d, "amount_yi": a} for d, a in daily_totals[-10:]],
    }


if __name__ == '__main__':
    from source_debug import run_source_cli
    run_source_cli('东方财富市场',{'margin':lambda a:fetch_market_margin_context(),
        'macro':lambda a:fetch_global_macro_and_commodities(),
        'breadth':lambda a:fetch_market_breadth_and_volume(datetime.now())})
