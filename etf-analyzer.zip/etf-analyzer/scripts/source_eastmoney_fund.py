"""东方财富：基金档案、持仓、公司财务与两融。"""
from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from statistics import mean, pstdev
from typing import Any, Iterable
from source_common import EASTMONEY_DATACENTER_URL, FUND_MOB_BASE, REQUEST_TIMEOUT, _clean_text, _num, _round, _session, symbol_to_secid
from source_tencent import fetch_stock_daily_rows, fetch_tencent_quotes
from technical_indicators import _period_return


def fetch_fund_profile_and_valuation(symbol: str, *, cn10y_yield: float | None = None) -> dict[str, Any]:
    """从天天基金移动端接口获取 ETF 基本面、夏普/回撤、跟踪指数 PE/PB/分位数/股息率/ROE 及相对国债利差。"""
    session = _session()
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://fund.eastmoney.com/"}
    url = f"{FUND_MOB_BASE}/FundMNNBasicInformation"
    try:
        resp = session.get(
            url,
            params={
                "FCODE": symbol,
                "deviceid": "Wap",
                "plat": "Wap",
                "product": "EFund",
                "version": "2.0.0",
            },
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        payload = resp.json() or {}
        d = payload.get("Datas") or {}
        idx = (payload.get("Expansion") or {}).get("INDEXINFO") or {}
    except Exception as exc:
        logging.warning("获取 %s 基金概况与指数估值失败: %s", symbol, exc)
        return {"available": False, "error": str(exc)}

    end_nav = _num(d.get("ENDNAV"))
    scale_yi = round(end_nav / 1e8, 2) if end_nav else None
    pe_ttm = _num(idx.get("PETTM"))
    pe_pct = _num(idx.get("PEP100"))
    pb = _num(idx.get("PB"))
    pb_pct = _num(idx.get("PBP100"))
    gxl = _num(idx.get("GXL"))
    roe = _num(idx.get("ROE"))
    ep_pct = round(100.0 / pe_ttm, 2) if pe_ttm and pe_ttm > 0 else None
    erp_vs_cn10y = round(ep_pct - cn10y_yield, 2) if ep_pct is not None and cn10y_yield is not None else None
    div_spread_vs_cn10y = round(gxl - cn10y_yield, 2) if gxl is not None and cn10y_yield is not None else None

    val_status = "未知"
    if pe_pct is not None:
        if pe_pct < 20:
            val_status = "PE历史分位<20%"
        elif pe_pct < 40:
            val_status = "20%≤PE历史分位<40%"
        elif pe_pct <= 60:
            val_status = "40%≤PE历史分位≤60%"
        elif pe_pct <= 80:
            val_status = "60%<PE历史分位≤80%"
        else:
            val_status = "PE历史分位>80%"

    return {
        "available": bool(d),
        "fund_code": d.get("FCODE") or symbol,
        "short_name": d.get("SHORTNAME"),
        "fund_type": d.get("FTYPE"),
        "establish_date": d.get("ESTABDATE"),
        "fund_company": d.get("JJGS"),
        "benchmark": d.get("BENCH"),
        "report_scale_yi": scale_yi,
        "report_scale_date": d.get("FEGMRQ"),
        "latest_nav": _num(d.get("DWJZ")),
        "accumulated_nav": _num(d.get("LJJZ")),
        "nav_date": d.get("FSRQ"),
        "tracking_error_pct": _num(d.get("TRKERROR")),
        "risk_level": d.get("RISKLEVEL"),
        "sharpe_1y": _num(d.get("SHARP1")),
        "sharpe_2y": _num(d.get("SHARP2")),
        "sharpe_3y": _num(d.get("SHARP3")),
        "max_drawdown_1y_pct": _num(d.get("MAXRETRA1")),
        "volatility_1y_pct": _num(d.get("STDDEV1")),
        "sip_return_1y_pct": _num(d.get("PTDT_Y")),
        "sip_return_2y_pct": _num(d.get("PTDT_TWY")),
        "sip_return_3y_pct": _num(d.get("PTDT_TRY")),
        "index_valuation": {
            "index_code": idx.get("INDEXCODE") or d.get("INDEXCODE"),
            "index_name": idx.get("FULLINDEXNAME") or d.get("INDEXNAME") or idx.get("INDEXNAME"),
            "valuation_date": idx.get("PDATE"),
            "pe_ttm": pe_ttm,
            "pe_percentile_pct": pe_pct,
            "pb": pb,
            "pb_percentile_pct": pb_pct,
            "dividend_yield_pct": gxl,
            "roe_pct": roe,
            "cn10y_yield_pct": cn10y_yield,
            "earnings_yield_ep_pct": ep_pct,
            "erp_vs_cn10y_pct": erp_vs_cn10y,
            "dividend_spread_vs_cn10y_pct": div_spread_vs_cn10y,
            "valuation_status": val_status,
            "return_1w_pct": _num(idx.get("W")),
            "return_1m_pct": _num(idx.get("M")),
            "return_3m_pct": _num(idx.get("Q")),
            "return_6m_pct": _num(idx.get("HY")),
            "return_1y_pct": _num(idx.get("Y")),
            "return_ytd_pct": _num(idx.get("SY")),
            "profile": _clean_text(idx.get("REAPROFILE")),
        },
    }

def fetch_securities_margin_and_fundamentals(
    etf_symbol: str, constituent_symbols: list[str]
) -> tuple[dict[str, Any], dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    """批量获取 ETF 与前十大重仓股的两融数据、最新财报增速指标及最新业绩预告。"""
    session = _session()
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://data.eastmoney.com/"}
    all_codes = list(dict.fromkeys([etf_symbol] + constituent_symbols))
    code_filter_str = ",".join(f'"{c}"' for c in all_codes if c)
    stock_filter_str = ",".join(f'"{c}"' for c in constituent_symbols if c)

    margin_map: dict[str, dict[str, Any]] = {}
    fin_map: dict[str, dict[str, Any]] = {}
    predict_map: dict[str, dict[str, Any]] = {}

    def _job_margin() -> None:
        if not code_filter_str:
            return
        try:
            resp = session.get(
                EASTMONEY_DATACENTER_URL,
                params={
                    "reportName": "RPTA_WEB_RZRQ_GGMX",
                    "columns": "SCODE,SECNAME,DATE,RZYE,RQYE,RZRQYE,RZJME,RZJME3D,RZJME5D,RZJME10D,FIN_BALANCE_GR",
                    "pageSize": str(max(50, len(all_codes) * 4)),
                    "sortColumns": "DATE",
                    "sortTypes": "-1",
                    "filter": f"(SCODE in ({code_filter_str}))",
                },
                headers=headers,
                timeout=8,
            )
            if resp.status_code != 200:
                return
            rows = ((resp.json().get("result") or {}).get("data")) or []
            for row in rows:
                code = str(row.get("SCODE") or "").strip()
                if not code or code in margin_map:
                    continue
                rzye = _num(row.get("RZYE"))
                rqye = _num(row.get("RQYE"))
                j1 = _num(row.get("RZJME"))
                j3 = _num(row.get("RZJME3D"))
                j5 = _num(row.get("RZJME5D"))
                j10 = _num(row.get("RZJME10D"))
                margin_map[code] = {
                    "date": str(row.get("DATE") or "")[:10],
                    "fin_balance_yi": round(rzye / 1e8, 2) if rzye is not None else None,
                    "loan_balance_yi": round(rqye / 1e8, 3) if rqye is not None else None,
                    "fin_net_buy_1d_yi": round(j1 / 1e8, 3) if j1 is not None else None,
                    "fin_net_buy_3d_yi": round(j3 / 1e8, 3) if j3 is not None else None,
                    "fin_net_buy_5d_yi": round(j5 / 1e8, 3) if j5 is not None else None,
                    "fin_net_buy_10d_yi": round(j10 / 1e8, 3) if j10 is not None else None,
                    "fin_change_1d_pct": _round(_num(row.get("FIN_BALANCE_GR")), 2),
                }
        except Exception as exc:
            logging.debug("批量获取两融明细异常: %s", exc)

    def _job_fundamentals() -> None:
        if not stock_filter_str:
            return
        try:
            resp = session.get(
                EASTMONEY_DATACENTER_URL,
                params={
                    "reportName": "RPT_LICO_FN_CPD",
                    "columns": (
                        "SECURITY_CODE,SECURITY_NAME_ABBR,REPORTDATE,DATATYPE,QDATE,"
                        "BASIC_EPS,TOTAL_OPERATE_INCOME,PARENT_NETPROFIT,WEIGHTAVG_ROE,"
                        "YSTZ,SJLTZ,XSMLL,YSHZ,SJLHZ,NOTICE_DATE"
                    ),
                    "pageSize": "50",
                    "sortColumns": "REPORTDATE,NOTICE_DATE",
                    "sortTypes": "-1,-1",
                    "filter": f"(SECURITY_CODE in ({stock_filter_str}))",
                },
                headers=headers,
                timeout=8,
            )
            if resp.status_code != 200:
                return
            rows = ((resp.json().get("result") or {}).get("data")) or []
            for row in rows:
                code = str(row.get("SECURITY_CODE") or "").strip()
                if not code or code in fin_map:
                    continue
                fin_map[code] = {
                    "report_period": _clean_text(row.get("QDATE") or row.get("DATATYPE")),
                    "report_date": str(row.get("REPORTDATE") or "")[:10],
                    "notice_date": str(row.get("NOTICE_DATE") or "")[:10],
                    "rev_yoy_pct": _round(_num(row.get("YSTZ")), 2),
                    "rev_qoq_pct": _round(_num(row.get("YSHZ")), 2),
                    "profit_yoy_pct": _round(_num(row.get("SJLTZ")), 2),
                    "profit_qoq_pct": _round(_num(row.get("SJLHZ")), 2),
                    "roe_pct": _round(_num(row.get("WEIGHTAVG_ROE")), 2),
                    "gross_margin_pct": _round(_num(row.get("XSMLL")), 2),
                    "basic_eps": _round(_num(row.get("BASIC_EPS")), 3),
                }
        except Exception as exc:
            logging.debug("批量获取重仓股财报指标异常: %s", exc)

    def _job_predictions() -> None:
        if not stock_filter_str:
            return
        try:
            resp = session.get(
                EASTMONEY_DATACENTER_URL,
                params={
                    "reportName": "RPT_PUBLIC_OP_PREDICT",
                    "columns": "ALL",
                    "pageSize": "50",
                    "sortColumns": "REPORTDATE,NOTICE_DATE",
                    "sortTypes": "-1,-1",
                    "filter": f"(SECURITY_CODE in ({stock_filter_str}))",
                },
                headers=headers,
                timeout=8,
            )
            if resp.status_code != 200:
                return
            rows = ((resp.json().get("result") or {}).get("data")) or []
            for row in rows:
                code = str(row.get("SECURITY_CODE") or "").strip()
                if not code or code in predict_map:
                    continue
                rpt_dt = str(row.get("REPORTDATE") or "")[:10]
                if rpt_dt < "2026-06-30":
                    continue
                low_v = _round(_num(row.get("INCREASEL")), 2)
                high_v = _round(_num(row.get("INCREASET")), 2)
                mid_v = (
                    round((low_v + high_v) / 2.0, 2)
                    if low_v is not None and high_v is not None
                    else (low_v if low_v is not None else high_v)
                )
                p_type = _clean_text(row.get("FORECASTTYPE"))
                n_dt = str(row.get("NOTICE_DATE") or "")[:10]
                q_label = (
                    f"{rpt_dt[:4]}Q3"
                    if "-09-30" in rpt_dt
                    else (f"{rpt_dt[:4]}Q2" if "-06-30" in rpt_dt else rpt_dt)
                )
                range_s = (
                    f"{low_v:+.1f}%~{high_v:+.1f}%"
                    if low_v is not None and high_v is not None and low_v != high_v
                    else (f"{mid_v:+.1f}%" if mid_v is not None else "")
                )
                predict_map[code] = {
                    "report_date": rpt_dt,
                    "period_label": q_label,
                    "predict_type": p_type,
                    "yoy_low_pct": low_v,
                    "yoy_high_pct": high_v,
                    "yoy_mid_pct": mid_v,
                    "notice_date": n_dt,
                    "summary": f"{q_label}{p_type}({range_s}, {n_dt[5:]}公告)" if p_type else None,
                }
        except Exception as exc:
            logging.debug("批量获取重仓股业绩预告异常: %s", exc)

    with ThreadPoolExecutor(max_workers=3) as pool:
        futs = [pool.submit(_job_margin), pool.submit(_job_fundamentals), pool.submit(_job_predictions)]
        for f in as_completed(futs):
            try:
                f.result()
            except Exception:
                continue

    etf_margin = margin_map.get(etf_symbol) or {"available": False}
    if etf_symbol in margin_map:
        etf_margin["available"] = True
    return etf_margin, margin_map, {
        c: {"fin": fin_map.get(c) or {}, "predict": predict_map.get(c) or {}}
        for c in constituent_symbols
    }

def fetch_constituents_analysis(symbol: str) -> dict[str, Any]:
    """获取前十大重仓股清单，并批量拉取实时行情、日K均线状态、基本面财务增速/业绩预告与两融资金数据。"""
    session = _session()
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://fund.eastmoney.com/"}
    url = f"{FUND_MOB_BASE}/FundMNInverstPosition"
    try:
        resp = session.get(
            url,
            params={
                "FCODE": symbol,
                "deviceid": "Wap",
                "plat": "Wap",
                "product": "EFund",
                "version": "2.0.0",
            },
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        payload = resp.json() or {}
        raw_stocks = ((payload.get("Datas") or {}).get("fundStocks")) or []
        asof_date = payload.get("Expansion")
    except Exception as exc:
        logging.warning("获取 %s 重仓股失败: %s", symbol, exc)
        return {"available": False, "error": str(exc), "constituents": []}

    if not raw_stocks:
        return {"available": False, "reason": "未披露重仓股", "constituents": []}

    items: list[dict[str, Any]] = []
    t_codes: list[str] = []
    c_symbols: list[str] = []
    for row in raw_stocks:
        code = str(row.get("GPDM") or "").strip()
        if not code:
            continue
        secid, t_code, pure = symbol_to_secid(code)
        t_codes.append(t_code)
        c_symbols.append(pure)
        items.append(
            {
                "symbol": pure,
                "secid": secid,
                "t_code": t_code,
                "name": _clean_text(row.get("GPJC")),
                "weight_pct": _num(row.get("JZBL")) or 0.0,
                "change_type": _clean_text(row.get("PCTNVCHGTYPE")),
                "weight_change_pct": _num(row.get("PCTNVCHG")),
                "industry": _clean_text(row.get("INDEXNAME")),
            }
        )

    quote_map = fetch_tencent_quotes(t_codes)
    etf_margin, margin_map, fund_pred_map = fetch_securities_margin_and_fundamentals(symbol, c_symbols)

    # 并发获取前十大重仓股最近 65 根日K以计算 5日/20日涨跌及 MA20/MA60 广度
    kline_stats: dict[str, dict[str, Any]] = {}

    def _fetch_stock_ma(item: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        tc = item["t_code"]
        rows = fetch_stock_daily_rows(tc, limit=65)
        closes = [_num(x[2]) for x in rows if isinstance(x, list) and len(x) >= 3 and _num(x[2]) is not None]
        q = quote_map.get(item["symbol"])
        cur = (q.current_price if q and q.current_price else (closes[-1] if closes else None))
        if cur is not None and closes:
            closes[-1] = cur
        ma20 = mean(closes[-20:]) if len(closes) >= 20 else None
        ma60 = mean(closes[-60:]) if len(closes) >= 60 else None
        return item["symbol"], {
            "return_5d_pct": _period_return(closes, 5),
            "return_20d_pct": _period_return(closes, 20),
            "above_ma20": bool(cur >= ma20) if cur is not None and ma20 is not None else None,
            "above_ma60": bool(cur >= ma60) if cur is not None and ma60 is not None else None,
        }

    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = [pool.submit(_fetch_stock_ma, it) for it in items]
        for fut in as_completed(futures):
            try:
                sym, st = fut.result()
                kline_stats[sym] = st
            except Exception:
                continue

    total_weight = 0.0
    weighted_change_sum = 0.0
    up_count = down_count = flat_count = 0
    up_weight = 0.0
    ma20_up_weight = 0.0
    ma60_up_weight = 0.0
    industry_weights: dict[str, float] = {}

    # 基本面与两融加权汇总统计变量
    rev_w_sum = 0.0
    rev_w_total = 0.0
    prof_w_sum = 0.0
    prof_w_total = 0.0
    roe_w_sum = 0.0
    roe_w_total = 0.0
    prof_yoy_list: list[float] = []
    prof_pos_count = 0
    latest_pred_notes: list[str] = []

    top10_fin_bal_yi = 0.0
    top10_fin_1d_yi = 0.0
    top10_fin_5d_yi = 0.0
    top10_fin_10d_yi = 0.0
    fin_inflow_1d_cnt = 0
    fin_inflow_5d_cnt = 0

    for it in items:
        sym_c = it["symbol"]
        q = quote_map.get(sym_c)
        w = it["weight_pct"]
        total_weight += w
        chg = q.change_percent if q else None
        it["current_price"] = q.current_price if q else None
        it["change_pct"] = chg
        it["amount_yi"] = round(q.amount / 1e8, 2) if q and q.amount else None
        it["turnover_rate_pct"] = q.turnover_rate if q else None
        it["total_mv_yi"] = round(q.total_market_value / 1e8, 2) if q and q.total_market_value else None
        it["pe_ttm"] = q.pe_ttm if q else None
        it["pe_dynamic"] = q.pe_dynamic if q else None
        it["pb"] = q.pb if q else None

        st = kline_stats.get(sym_c, {})
        it["return_5d_pct"] = st.get("return_5d_pct")
        it["return_20d_pct"] = st.get("return_20d_pct")
        it["above_ma20"] = st.get("above_ma20")
        it["above_ma60"] = st.get("above_ma60")

        # 合并财务增速与业绩预告
        fp = fund_pred_map.get(sym_c) or {}
        fin = fp.get("fin") or {}
        pred = fp.get("predict") or {}
        rev_yoy = fin.get("rev_yoy_pct")
        prof_yoy = fin.get("profit_yoy_pct")
        roe_v = fin.get("roe_pct")
        pe_for_peg = it["pe_ttm"] or it["pe_dynamic"]
        peg = (
            round(pe_for_peg / prof_yoy, 2)
            if pe_for_peg is not None and pe_for_peg > 0 and prof_yoy is not None and prof_yoy > 0
            else None
        )
        it["report_period"] = fin.get("report_period")
        it["rev_yoy_pct"] = rev_yoy
        it["profit_yoy_pct"] = prof_yoy
        it["roe_pct"] = roe_v
        it["gross_margin_pct"] = fin.get("gross_margin_pct")
        it["peg"] = peg

        # 若业绩预告的报告期比正式财报期更新，则展示最新预告
        pred_rpt = pred.get("report_date") or ""
        fin_rpt = fin.get("report_date") or ""
        if pred and pred_rpt > fin_rpt:
            it["latest_earnings_forecast"] = pred.get("summary")
            latest_pred_notes.append(f"{it['name']}({sym_c}): {pred.get('summary')}")
        else:
            it["latest_earnings_forecast"] = None

        if rev_yoy is not None:
            rev_w_sum += w * rev_yoy
            rev_w_total += w
        if prof_yoy is not None:
            prof_w_sum += w * prof_yoy
            prof_w_total += w
            prof_yoy_list.append(prof_yoy)
            if prof_yoy > 0:
                prof_pos_count += 1
        if roe_v is not None:
            roe_w_sum += w * roe_v
            roe_w_total += w

        # 合并两融数据
        mg = margin_map.get(sym_c) or {}
        it["fin_balance_yi"] = mg.get("fin_balance_yi")
        it["fin_net_buy_1d_yi"] = mg.get("fin_net_buy_1d_yi")
        it["fin_net_buy_5d_yi"] = mg.get("fin_net_buy_5d_yi")
        it["fin_net_buy_10d_yi"] = mg.get("fin_net_buy_10d_yi")
        if mg.get("fin_balance_yi") is not None:
            top10_fin_bal_yi += mg["fin_balance_yi"]
        if mg.get("fin_net_buy_1d_yi") is not None:
            top10_fin_1d_yi += mg["fin_net_buy_1d_yi"]
            if mg["fin_net_buy_1d_yi"] > 0:
                fin_inflow_1d_cnt += 1
        if mg.get("fin_net_buy_5d_yi") is not None:
            top10_fin_5d_yi += mg["fin_net_buy_5d_yi"]
            if mg["fin_net_buy_5d_yi"] > 0:
                fin_inflow_5d_cnt += 1
        if mg.get("fin_net_buy_10d_yi") is not None:
            top10_fin_10d_yi += mg["fin_net_buy_10d_yi"]

        if chg is not None:
            contrib = round(w * chg / 100.0, 4)
            it["contribution_pct"] = contrib
            weighted_change_sum += w * chg
            if chg > 0:
                up_count += 1
                up_weight += w
            elif chg < 0:
                down_count += 1
            else:
                flat_count += 1
        else:
            it["contribution_pct"] = None
        if st.get("above_ma20"):
            ma20_up_weight += w
        if st.get("above_ma60"):
            ma60_up_weight += w
        ind = it.get("industry") or "其他"
        industry_weights[ind] = round(industry_weights.get(ind, 0.0) + w, 2)

    n_valid = up_count + down_count + flat_count
    breadth_up_pct = round(up_count / n_valid * 100.0, 1) if n_valid > 0 else None
    weighted_breadth_up_pct = round(up_weight / total_weight * 100.0, 1) if total_weight > 0 else None
    weighted_change_pct = round(weighted_change_sum / total_weight, 2) if total_weight > 0 else None
    above_ma20_pct = round(ma20_up_weight / total_weight * 100.0, 1) if total_weight > 0 else None
    above_ma60_pct = round(ma60_up_weight / total_weight * 100.0, 1) if total_weight > 0 else None

    sorted_prof = sorted(prof_yoy_list)
    median_prof_yoy = (
        round(sorted_prof[len(sorted_prof) // 2], 2) if sorted_prof else None
    )

    sorted_by_chg = sorted(
        [x for x in items if x.get("change_pct") is not None],
        key=lambda x: x["change_pct"],
        reverse=True,
    )

    return {
        "available": True,
        "report_date": asof_date,
        "count": len(items),
        "total_weight_pct": round(total_weight, 2),
        "up_count": up_count,
        "down_count": down_count,
        "flat_count": flat_count,
        "breadth_up_pct": breadth_up_pct,
        "weighted_breadth_up_pct": weighted_breadth_up_pct,
        "weighted_change_pct": weighted_change_pct,
        "estimated_top10_contribution_pct": round(weighted_change_sum / 100.0, 3),
        "above_ma20_weighted_breadth_pct": above_ma20_pct,
        "above_ma60_weighted_breadth_pct": above_ma60_pct,
        "industry_distribution_pct": dict(
            sorted(industry_weights.items(), key=lambda kv: kv[1], reverse=True)
        ),
        "fundamentals_summary": {
            "weighted_rev_yoy_pct": round(rev_w_sum / rev_w_total, 2) if rev_w_total > 0 else None,
            "weighted_profit_yoy_pct": round(prof_w_sum / prof_w_total, 2) if prof_w_total > 0 else None,
            "median_profit_yoy_pct": median_prof_yoy,
            "weighted_roe_pct": round(roe_w_sum / roe_w_total, 2) if roe_w_total > 0 else None,
            "profit_positive_growth_count": prof_pos_count,
            "latest_earnings_forecasts": latest_pred_notes,
        },
        "margin_summary": {
            "etf_margin": etf_margin,
            "top10_total_fin_balance_yi": round(top10_fin_bal_yi, 2),
            "top10_fin_net_buy_1d_yi": round(top10_fin_1d_yi, 2),
            "top10_fin_net_buy_5d_yi": round(top10_fin_5d_yi, 2),
            "top10_fin_net_buy_10d_yi": round(top10_fin_10d_yi, 2),
            "top10_fin_inflow_1d_count": fin_inflow_1d_cnt,
            "top10_fin_inflow_5d_count": fin_inflow_5d_cnt,
        },
        "top_gainers": [
            f"{x['name']}({x['symbol']} {x['change_pct']:+.2f}%, 权重{x['weight_pct']}%)"
            for x in sorted_by_chg[:3]
        ],
        "top_losers": [
            f"{x['name']}({x['symbol']} {x['change_pct']:+.2f}%, 权重{x['weight_pct']}%)"
            for x in sorted_by_chg[-3:]
        ],
        "constituents": items,
    }


if __name__ == '__main__':
    from source_debug import run_source_cli
    run_source_cli('东方财富基金',{'fund':lambda a:fetch_fund_profile_and_valuation(a.symbol),
        'holdings':lambda a:fetch_constituents_analysis(a.symbol)})
