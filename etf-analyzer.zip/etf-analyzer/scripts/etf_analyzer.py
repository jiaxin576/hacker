"""主入口：调度各来源、校验批次、汇总分类MD与JSON。"""
from __future__ import annotations

import argparse
import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
import research_store
import return_accounting
import information_report
from kol_config import add_kol_source_to_config, load_kol_sources
from market_data import fetch_daily_bars, fetch_weekly_bars, resolve_security, update_etf_share_archive
from report_renderer import format_markdown_report, format_kol_markdown_section
from source_common import DEFAULT_KLINE_LIMIT, DEFAULT_KOL_LIMIT, DEFAULT_NEWS_DAYS, DEFAULT_NEWS_LIMIT, DEFAULT_SYMBOLS, DEFAULT_WEEKLY_KLINE_LIMIT, KOL_SOURCES_FILE, market_phase, split_symbol_values, DailyBar, Quote, _session, _num, _round, _pct_change, _clean_text, _strip_html, symbol_to_secid, _parse_dt, SKILL_DIR, SCRIPT_DIR, TENCENT_KLINE_URL, TENCENT_QUOTE_URL
from source_eastmoney_fund import fetch_constituents_analysis, fetch_fund_profile_and_valuation, fetch_securities_margin_and_fundamentals
from source_eastmoney_market import fetch_global_macro_and_commodities, fetch_market_breadth_and_volume, fetch_market_margin_context, _trading_elapsed_minutes
from source_eastmoney_news import build_news_keywords, collect_financial_news, fetch_global_fast_news, fetch_relevant_news, search_eastmoney_news
from source_tencent import fetch_market_and_overseas_context, fetch_tencent_quotes, _parse_tencent_quote_parts, _parse_tencent_daily_rows
from technical_indicators import build_technical_summary, build_weekly_technical_summary, _period_return, _range_and_percentile, _classify_ma_alignment, _ema_series, _macd, _rsi, _atr, _streaks, _pivot_levels, _weekly_range_and_percentile

from source_sse import enrich_with_sse_snapshot
from source_tushare import _fetch_remote_etf_share_history
from source_xueqiu import _extract_xueqiu_uid, _clean_xueqiu_article_html, _load_cached_xueqiu_cookie, _save_cached_xueqiu_cookie, _refresh_xueqiu_cookie_via_playwright, _xueqiu_get_json, _fetch_single_xueqiu_kol
from source_douyin import load_douyin_transcripts
from kol_collection import fetch_kol_columns

def fetch_etf_info(
    raw_symbol: str,
    *,
    market_ctx: list[dict[str, Any]],
    overseas_ctx: dict[str, dict[str, Any]],
    macro_ctx: dict[str, dict[str, Any]] | None = None,
    breadth_vol_ctx: dict[str, Any] | None = None,
    market_margin_ctx: dict[str, Any] | None = None,
    analysis_time: datetime,
    news_days: int = DEFAULT_NEWS_DAYS,
    news_limit: int = DEFAULT_NEWS_LIMIT,
    kline_limit: int = DEFAULT_KLINE_LIMIT,
    extra_keywords: Iterable[str] = (),
) -> dict[str, Any]:
    """获取单只 ETF 的完整客观信息包。"""
    secid, quote = resolve_security(raw_symbol)
    bars = fetch_daily_bars(secid, limit=kline_limit, quote=quote)
    weekly_bars = fetch_weekly_bars(secid, limit=DEFAULT_WEEKLY_KLINE_LIMIT, quote=quote)
    tech = build_technical_summary(quote, bars)
    weekly_tech = build_weekly_technical_summary(quote, weekly_bars)
    cn10y_val = ((macro_ctx or {}).get("cn10y") or {}).get("price")
    profile = fetch_fund_profile_and_valuation(quote.symbol, cn10y_yield=cn10y_val)
    constituents_info = fetch_constituents_analysis(quote.symbol)
    trade_date = (quote.quote_time or "")[:10] or bars[-1].date
    share_flow = update_etf_share_archive(quote, trade_date=trade_date, bars=bars)

    idx_name = ((profile.get("index_valuation") or {}).get("index_name"))
    keywords = build_news_keywords(
        quote.symbol,
        quote.name,
        index_name=idx_name,
        constituents=constituents_info.get("constituents"),
        extra_keywords=extra_keywords,
    )
    news = fetch_relevant_news(
        keywords,
        constituents=constituents_info.get("constituents"),
        cutoff=analysis_time,
        days=news_days,
        limit=news_limit,
    )

    return {
        "symbol": quote.symbol,
        "name": quote.name,
        "secid": secid,
        "analysis_time": analysis_time.isoformat(sep=" ", timespec="seconds"),
        "market_phase": market_phase(analysis_time),
        "quote": quote.to_dict(),
        "fund_profile": profile,
        "technical_summary": tech,
        "weekly_technical_summary": weekly_tech,
        "recent_daily_bars": [b.to_dict() for b in bars[-30:]],
        "price_basis": "vendor_forward_adjusted",
        "return_accounting": return_accounting.account_guard(quote.symbol),
        "recent_weekly_bars": [b.to_dict() for b in weekly_bars[-26:]],
        "constituents_analysis": constituents_info,
        "share_flow": share_flow,
        "market_context": market_ctx,
        "market_breadth_and_volume": breadth_vol_ctx,
        "market_margin_context": market_margin_ctx,
        "overseas_context": overseas_ctx,
        "macro_and_commodities": macro_ctx,
        "news_keywords": keywords,
        "news": news,
    }

def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="ETF 全维客观信息与知名博主专栏采集工具 (etf-analyzer)")
    parser.add_argument(
        "--symbols",
        nargs="+",
        default=list(DEFAULT_SYMBOLS),
        help="ETF 代码，支持一个或多个（空格或逗号分隔），例如: 515070 159338",
    )
    parser.add_argument("--news-days", type=int, default=DEFAULT_NEWS_DAYS, help="东方财富新闻回看天数，默认 3")
    parser.add_argument("--news-limit", type=int, default=DEFAULT_NEWS_LIMIT, help="每只 ETF 最多返回的新闻条数，默认 15")
    parser.add_argument("--kline-limit", type=int, default=DEFAULT_KLINE_LIMIT, help="前复权日K线回看根数，默认 260（约1年）")
    parser.add_argument("--keywords", nargs="*", default=[], help="追加自定义新闻检索关键词")
    parser.add_argument(
        "--kol-users",
        nargs="*",
        default=[],
        help="临时追加要抓取的雪球博主 UID 或主页/专栏 URL（默认自动加载 data/kol_sources.json 中的搬砖小组等博主）",
    )
    parser.add_argument(
        "--kol-limit",
        type=int,
        default=None,
        help=f"每位知名博主抓取的最新专栏/文章篇数（默认使用配置值 {DEFAULT_KOL_LIMIT}）",
    )
    parser.add_argument("--no-kol", action="store_true", help="跳过知名博主最新专栏抓取")
    parser.add_argument("--source-run", help="本次浏览器前置采集批次ID；每次分析必须新建")
    parser.add_argument("--prepare-sources", action="store_true", help="创建采集任务清单，交由Skill Agent自动执行")
    parser.add_argument(
        "--add-kol",
        nargs="+",
        metavar="ARG",
        help="永久添加新博主到 data/kol_sources.json，用法: --add-kol <雪球UID或URL> [博主名称] [风格备注]",
    )
    parser.add_argument("--output-dir", default="outputs", help="JSON 与 Markdown 信息文件保存目录，默认 outputs")
    parser.add_argument("--json-only", action="store_true", help="终端仅输出 JSON 格式数据")
    parser.add_argument("--log-level", default="WARNING", help="日志级别，默认 WARNING")
    args = parser.parse_args(argv)
    args.symbols = split_symbol_values(args.symbols)
    return args

def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.WARNING),
        format="%(asctime)s %(levelname)s - %(message)s",
    )
    if args.add_kol:
        uid_or_url = args.add_kol[0]
        kol_name = args.add_kol[1] if len(args.add_kol) > 1 else ""
        kol_style = args.add_kol[2] if len(args.add_kol) > 2 else "市场观点与复盘"
        added = add_kol_source_to_config(uid_or_url, name=kol_name, style=kol_style)
        logging.warning("已将博主写入配置文件 %s: %s", KOL_SOURCES_FILE, added)

    store = research_store.connect()
    if args.prepare_sources or not args.source_run:
        task = research_store.begin(store, [s.split('.')[-1] for s in args.symbols])
        print(json.dumps(task, ensure_ascii=False, indent=2))
        logging.warning("前置采集待执行：Agent须逐项检查最新页面、转写新视频并记录结果，再以 --source-run %s 继续。尚未运行市场分析。", task['run_id'])
        return
    social_ctx = research_store.context(store, args.source_run)
    run_record = research_store.get_run(store, args.source_run)
    if (datetime.now(timezone.utc) - datetime.fromisoformat(run_record['started_at'])).total_seconds() > 21600:
        raise ValueError("采集批次超过6小时，请重新启动前置采集")
    if store.execute('SELECT 1 FROM analysis_snapshots WHERE run_id=?', (args.source_run,)).fetchone():
        raise ValueError("此批次已经用于分析；每次启动必须重新检查数据源")
    expected = {s['id'] for s in research_store.sources(args.symbols)}
    if expected != {s['id'] for s in social_ctx['sources']}:
        raise ValueError("本次持仓或博主配置已变化，请新建采集批次")
    if social_ctx['pending']:
        print(research_store.markdown(social_ctx))
        raise SystemExit("尚有来源未检查。访问失败也须记录真实原因后才能继续，禁止直接复用缓存。")
    analysis_time = datetime.now()
    collection_errors = []
    def collect(name, function, fallback):
        try:
            return function()
        except Exception as exc:
            collection_errors.append(f'{name}: 获取失败 ({type(exc).__name__}: {exc})')
            return fallback
    market_ctx, overseas_ctx = collect('market/overseas', fetch_market_and_overseas_context, ([], {}))
    macro_ctx = collect('macro', fetch_global_macro_and_commodities, {})
    breadth_vol_ctx = collect('breadth', lambda: fetch_market_breadth_and_volume(analysis_time), {})
    market_margin_ctx = collect('margin', fetch_market_margin_context, {})
    fast_news_ctx = collect('fast_news', lambda: fetch_global_fast_news(limit=12), [])
    calendar_bars = collect('交易日历', lambda: fetch_daily_bars('1.000001', limit=100), [])
    social_ctx['trading_day_comparison'] = research_store.trading_windows(
        store, args.source_run, [b.date for b in calendar_bars])
    if not social_ctx['trading_day_comparison']['available']:
        collection_errors.append(social_ctx['trading_day_comparison']['reason'])
    # The browser preflight already retrieved KOL posts; do not replace these
    # with stale caches or run a second independent authentication flow.
    kol_rows = [dict(id=s.get('author_id'), name=s.get('name'), platform=s['platform'],
                    articles=s['items'], article_count=len(s['items']), note=s['status'])
                for s in social_ctx['sources'] if s['kind'] == 'kol']
    kol_ctx = dict(available=any(s['article_count'] for s in kol_rows), kol_list=kol_rows,
                   config_file=str(KOL_SOURCES_FILE))
    if args.no_kol:
        social_ctx['warnings'].append('--no-kol不跳过强制前置采集；本次仍保留已采集博主数据')
    if args.kol_users:
        social_ctx['warnings'].append('临时--kol-users未纳入当前批次；请先用--add-kol配置后新建批次')

    results: list[dict[str, Any]] = []
    md_sections: list[str] = []

    mkt_line = " | ".join(
        f"{m['名称']} `{m['最新价']}` ({m['涨跌幅_pct']:+.2f}%)"
        for m in market_ctx
        if m.get("涨跌幅_pct") is not None
    )
    ov_line = " | ".join(
        f"{v['name']} `{v['price']}` ({v['change_percent']:+.2f}%)"
        for v in overseas_ctx.values()
        if v.get("change_percent") is not None
    )
    asia_sox_line = " | ".join(
        f"{v['name']} `{v['price']}` (最新 `{v['change_pct']:+.2f}%` / 前日 `{v['prev_change_pct']:+.2f}%` / 5日 `{v['return_5d_pct']:+.2f}%`)"
        for k, v in macro_ctx.items()
        if v.get("category") in ("asia_index", "us_index") and v.get("change_pct") is not None
    )
    rate_fx_line = " | ".join(
        f"{v['name']} `{v['price']}` (最新 `{v['change_pct']:+.2f}%` / 5日 `{v['return_5d_pct']:+.2f}%`)"
        for k, v in macro_ctx.items()
        if v.get("category") == "rate_fx" and v.get("price") is not None
    )
    comm_line = " | ".join(
        f"{v['name']} `{v['price']}` (最新 `{v['change_pct']:+.2f}%` / 前日 `{v['prev_change_pct']:+.2f}%` / 5日 `{v['return_5d_pct']:+.2f}%`)"
        for k, v in macro_ctx.items()
        if v.get("category") == "commodity" and v.get("price") is not None
    )

    bv_lines: list[str] = []
    if breadth_vol_ctx.get("available"):
        bv = breadth_vol_ctx
        breadth_str = (
            f"沪深上涨 `{bv.get('up_count')}` 家 / 下跌 `{bv.get('down_count')}` 家 / 平盘 `{bv.get('flat_count')}` 家（上涨占比 **{bv.get('up_ratio_pct')}%**） | 实时总成交额 `{bv.get('realtime_total_amount_yi')}亿`"
            if bv.get("up_count") is not None
            else ""
        )

        if breadth_str:
            bv_lines.append(f"- **全A市场宽度与实时量能**：{breadth_str}")
        bv_lines.append(
            f"- **全A成交额与历史峰值比例**：**{bv.get('volume_shrinkage_status')}**  \n"
            f"  - 上一完整日({bv.get('last_full_day_date')})成交 `{bv.get('last_full_day_amount_yi')}亿`（占60日峰值 `{bv.get('last_full_vs_60d_peak_pct')}%` / 占120日峰值 **{bv.get('last_full_vs_120d_peak_pct')}%**）  \n"
            f"  - 近5日最低完整日({bv.get('min_5d_full_date')})成交 `{bv.get('min_5d_full_amount_yi')}亿`（占60日峰值 `{bv.get('min_5d_vs_60d_peak_pct')}%` / 占120日峰值 **{bv.get('min_5d_vs_120d_peak_pct')}%**）  \n"
            f"  - 峰值坐标：60日峰值 `{bv.get('peak_60d_amount_yi')}亿` ({bv.get('peak_60d_date')}) | 120日峰值 `{bv.get('peak_120d_amount_yi')}亿` ({bv.get('peak_120d_date')}) | 5日均量 `{bv.get('avg_5d_amount_yi')}亿` / 20日均量 `{bv.get('avg_20d_amount_yi')}亿`"
        )
    if market_margin_ctx.get("available"):
        mm = market_margin_ctx
        bv_lines.append(
            f"- **全A两融杠杆资金（截至 {mm.get('date')}）**：两融总余额 `{mm.get('total_margin_balance_yi')}亿`（融资 `{mm.get('fin_balance_yi')}亿` / 融券 `{mm.get('loan_balance_yi')}亿`，占流通市值 `{mm.get('fin_ratio_of_float_mv_pct')}%`）  \n"
            f"  - **杠杆资金流向**：**{mm.get('status_summary')}**（近20日累计 `{mm.get('net_buy_20d_yi'):+.2f}亿`，20日余额变化 `{mm.get('fin_change_20d_pct'):+.2f}%`）"
        )

    fast_news_md = ""
    if fast_news_ctx:
        fn_items = [
            f"  {i}. `[{fn['time']}]` **{fn['title']}**"
            + (f" — {fn['summary'][:120]}" if fn.get("summary") and fn["summary"] != fn["title"] else "")
            for i, fn in enumerate(fast_news_ctx[:10], 1)
        ]
        fast_news_md = "- **7×24小时全球宏观与产业硬核快讯**：\n" + "\n".join(fn_items) + "\n"

    header_md = (
        f"# ETF 客观市场信息采集报告\n\n"
        f"- **采集时间**：{analysis_time:%Y-%m-%d %H:%M:%S}（{market_phase(analysis_time)}）\n"
        f"- **A股市场基准**：{mkt_line or '暂无'}\n"
        + ("\n".join(bv_lines) + "\n" if bv_lines else "")
        + f"- **亚太与费城半导体**：{asia_sox_line or '暂无'}\n"
        f"- **港美股与AI全链条风向标（含CoreWeave/美光/阿斯麦/台积电）**：{ov_line or '暂无'}\n"
        f"- **全球宏观利率与汇率**：{rate_fx_line or '暂无'}\n"
        f"- **全球能源与大宗商品底座**：{comm_line or '暂无'}\n"
        + fast_news_md
    )

    for sym in args.symbols:
        try:
            data = fetch_etf_info(
                sym,
                market_ctx=market_ctx,
                overseas_ctx=overseas_ctx,
                macro_ctx=macro_ctx,
                breadth_vol_ctx=breadth_vol_ctx,
                market_margin_ctx=market_margin_ctx,
                analysis_time=analysis_time,
                news_days=args.news_days,
                news_limit=args.news_limit,
                kline_limit=args.kline_limit,
                extra_keywords=args.keywords,
            )
            results.append(data)
            data['official_fund_evidence'] = next((s for s in social_ctx['sources']
                if s['id'] == f"official:fund:{data['symbol']}"), {})
            data['business_driver_evidence'] = next((s for s in social_ctx['sources']
                if s['id'] == f"research:drivers:{data['symbol']}"), {})
            md_sections.append(format_markdown_report(data, include_news=False))
        except Exception as exc:
            logging.exception("获取 %s 信息失败", sym)
            md_sections.append(f"## {sym} 信息获取失败\n\n错误信息：`{exc}`")

    financial_news = collect('financial_news', lambda: collect_financial_news(
        args.symbols, results, cutoff=analysis_time, days=args.news_days, limit=args.news_limit),
        {'available':False, 'by_etf':{}})
    for symbol, group in financial_news.get('by_etf', {}).items():
        if group.get('needs_web_supplement'):
            collection_errors.append(f'{symbol}/财经新闻：{group.get("reason")}')
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = "_".join(s.split(".")[-1] for s in args.symbols)
    ts_str = f"{analysis_time:%Y%m%d_%H%M%S}"
    md_path = out_dir / f"etf_info_{stem}_{ts_str}.md"
    json_path = out_dir / f"etf_info_{stem}_{ts_str}.json"

    objective_warnings = list(collection_errors)
    if any(s.split('.')[-1] == '515180' for s in args.symbols):
        objective_warnings.append('515180: 账户显示成本0.280/收益408.57%未经过成交与分红流水对账，不作为真实账户收益率；除息日与现金到账日分别处理')
    for symbol in args.symbols:
        entry = next((e for e in results if e['symbol'] == symbol.split('.')[-1]), None)
        if entry is None:
            objective_warnings.append(f'{symbol}: 客观数据整包获取失败')
            continue
        objective_warnings.extend(research_store.missing_fields(entry, symbol))
        for field in ('quote', 'fund_profile', 'technical_summary', 'weekly_technical_summary',
                      'constituents_analysis', 'share_flow', 'news'):
            val = entry.get(field)
            if not val or (isinstance(val, dict) and (val.get('available') is False or val.get('error'))):
                objective_warnings.append(f'{symbol}/{field}: 缺失或采集失败')
    for key, val in [('market_context', market_ctx), ('overseas_context', overseas_ctx),
                     ('macro_and_commodities', macro_ctx), ('market_breadth_and_volume', breadth_vol_ctx),
                     ('market_margin_context', market_margin_ctx), ('global_fast_news', fast_news_ctx)]:
        if not val or (isinstance(val, dict) and val.get('available') is False):
            objective_warnings.append(f'{key}: 缺失或不可用')
    social_ctx['warnings'].extend(objective_warnings)
    json_payload = {
        "collected_at": analysis_time.isoformat(sep=" ", timespec="seconds"),
        "market_phase": market_phase(analysis_time),
        "market_context": market_ctx,
        "market_breadth_and_volume": breadth_vol_ctx,
        "market_margin_context": market_margin_ctx,
        "overseas_context": overseas_ctx,
        "macro_and_commodities": macro_ctx,
        "global_fast_news": fast_news_ctx,
        "financial_news": financial_news,
        "kol_columns": kol_ctx,
        "research_sources": social_ctx,
        "data_warnings": social_ctx['warnings'],
        "etfs": results,
    }
    objective_md = (header_md.replace(fast_news_md, '') if fast_news_md else header_md)
    objective_md += '\n\n' + '\n\n---\n\n'.join(md_sections)
    organized, export_paths = information_report.export(
        json_payload, out_dir, f'etf_info_{stem}_{ts_str}', objective_markdown=objective_md)
    json_payload['organized_information'] = organized
    json_payload['classified_files'] = export_paths
    full_md = information_report.combined_markdown(json_payload,organized,objective_md)
    md_path.write_text(full_md, encoding="utf-8")
    json_path.write_text(json.dumps(json_payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    research_store.save_analysis(store, args.source_run, json_payload)

    if args.json_only:
        print(json.dumps(json_payload, ensure_ascii=False, indent=2, default=str))
    else:
        print(full_md)
        print(f"\n[数据已保存]\n- Markdown 汇总: {md_path.resolve()}\n- JSON 原始数据: {json_path.resolve()}")


if __name__=="__main__":main()
