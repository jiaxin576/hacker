import copy
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import research_store as rs


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = rs.connect(Path(self.tmp.name) / 'test.sqlite3')
        self.run = rs.begin(self.db)
        self.t = datetime.now(timezone.utc)
        self.batch = dict(source_id='eastmoney:etf:515070', checked_at=self.t.isoformat(), status='ok',
                          evidence='https://guba.eastmoney.com/news,sh515070,123.html',
                          coverage=dict(pages=1, truncated=False), items=[dict(
                              id='123', symbol='515070', author_id='abc', content='看好长期需求',
                              content_type='post', body_complete=True,
                              url='https://guba.eastmoney.com/news,sh515070,123.html',
                              published_at=(self.t-timedelta(days=1)).isoformat())])

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def ingest(self, batch=None):
        rs.ingest(self.db, self.run['run_id'], batch or self.batch)

    def source(self, ctx):
        return next(s for s in ctx['sources'] if s['id'] == self.batch['source_id'])

    def test_all_required_sources_and_unconfigured(self):
        ctx = rs.context(self.db, self.run['run_id'])
        self.assertEqual(len(ctx['pending']), 18)
        self.assertEqual(len(ctx['sources']), 19)
        self.assertTrue(any('not_configured' in w for w in ctx['warnings']))

    def test_old_content_retained_outside_window(self):
        self.batch['items'][0]['published_at'] = (self.t-timedelta(days=180)).isoformat()
        self.ingest()
        src = self.source(rs.context(self.db, self.run['run_id']))
        self.assertEqual(src['recent_count'], 0)
        self.assertEqual(src['historical_count'], 1)
        self.assertEqual(self.db.execute('SELECT count(*) FROM observations').fetchone()[0], 1)

    def test_revisions_and_first_seen_and_asof(self):
        self.ingest()
        old = self.batch['checked_at']
        self.batch['checked_at'] = rs.now()
        self.batch['items'][0]['content'] = '修订后偏谨慎'
        self.ingest()
        ctx = rs.context(self.db, self.run['run_id'], as_of=old)
        self.assertEqual(self.source(ctx)['items'][0]['content'], '看好长期需求')
        current = self.source(rs.context(self.db, self.run['run_id']))
        self.assertEqual(current['items'][0]['content'], '修订后偏谨慎')
        self.assertEqual(current['items'][0]['first_seen_at'], old)
        self.assertEqual(self.db.execute('SELECT count(*) FROM items').fetchone()[0], 1)
        self.assertEqual(self.db.execute('SELECT count(*) FROM observations').fetchone()[0], 2)

    def test_new_run_cannot_reuse_old_success(self):
        self.ingest()
        other = rs.begin(self.db)
        src = self.source(rs.context(self.db, other['run_id']))
        self.assertEqual(src['status'], 'not_checked')
        self.assertFalse(src['live_checked'])

    def test_reject_empty_ok_title_and_wrong_identity(self):
        for change in ({'items': []}, {'items': [dict(self.batch['items'][0], content_type='title_only')]},
                       {'items': [dict(self.batch['items'][0], symbol='159338')]},
                       {'items': [dict(self.batch['items'][0], published_at='2026-01-01T12:00:00')]},
                       {'items': [dict(self.batch['items'][0], published_at=(self.t+timedelta(days=1)).isoformat())]}):
            bad = copy.deepcopy(self.batch)
            bad.update(change)
            with self.assertRaises(ValueError):
                self.ingest(bad)
        self.assertEqual(self.db.execute('SELECT count(*) FROM observations').fetchone()[0], 0)

    def test_failure_is_recorded_not_no_update(self):
        self.batch.update(status='blocked', reason='HTTP 403；浏览器要求登录', items=[])
        self.ingest()
        src = self.source(rs.context(self.db, self.run['run_id']))
        self.assertEqual(src['status'], 'blocked')
        self.assertEqual(src['recent_count'], 0)

    def test_annotations_append_and_validate_reference(self):
        self.ingest()
        data = dict(observation_id=1, model='test-model', prompt_version='v1',
                    sentiment='uncertain', evidence='看好长期需求')
        rs.annotate(self.db, data)
        rs.annotate(self.db, dict(data, prompt_version='v2'))
        self.assertEqual(self.db.execute('SELECT count(*) FROM annotations').fetchone()[0], 2)
        with self.assertRaises(ValueError):
            rs.annotate(self.db, dict(data, observation_id=999))

    def test_no_future_backfill(self):
        self.ingest()
        past = (self.t-timedelta(days=2)).isoformat()
        self.assertEqual(self.source(rs.context(self.db, self.run['run_id'], as_of=past))['items'], [])

    def test_trading_windows_need_real_dates(self):
        self.assertFalse(rs.trading_windows(self.db, self.run['run_id'], ['2026-10-16'])['available'])
        # Fixture deliberately omits weekends and holidays; function consumes exact input.
        dates = [(self.t-timedelta(days=i)).date().isoformat() for i in range(2, 65)
                 if (self.t-timedelta(days=i)).weekday() < 5]
        r = rs.trading_windows(self.db, self.run['run_id'], dates)
        self.assertTrue(r['available'])
        win = r['sources'][0]['windows']['20']
        self.assertEqual(win['recent']['start_exclusive'], win['previous']['end_inclusive'])

    def test_missing_values_not_zero(self):
        warnings = rs.missing_fields({'fund': {'nav': None, 'profit': 0}})
        self.assertIn('nav', warnings[0])
        self.assertNotIn('profit', warnings[0])

    def test_unknown_publication_is_retained_without_entering_recent_window(self):
        self.batch['status'] = 'partial'
        self.batch['items'][0]['published_at'] = None
        self.ingest()
        source = self.source(rs.context(self.db, self.run['run_id']))
        self.assertEqual(source['recent_count'], 0)
        self.assertEqual(source['undated_count'], 1)
        self.assertEqual(source['undated_items'][0]['content'], '看好长期需求')
        self.assertIsNone(source['undated_items'][0]['published_at'])

    def test_douyin_latest_two_retains_older_dates_and_full_archive(self):
        spec=next(s for s in self.run['sources'] if s['platform']=='douyin')
        records=[]
        for n in (10,20,30):
            records.append(dict(id=str(12345678901234500+n),author_id=spec['author_id'],
                url=f'https://www.douyin.com/video/{12345678901234500+n}',content=f'原始转写{n}',
                published_at=(self.t-timedelta(days=n)).isoformat(),content_type='audio_transcript',
                body_complete=True,media_sha256='fixture',segments=[{'start':0,'end':1,'text':'原话'}]))
        rs.ingest(self.db,self.run['run_id'],dict(source_id=spec['id'],checked_at=rs.now(),status='ok',
            evidence='主页清单证据',coverage={'pages':1},items=records))
        source=next(s for s in rs.context(self.db,self.run['run_id'])['sources'] if s['id']==spec['id'])
        self.assertEqual(len(source['items']),2)
        self.assertEqual(source['items'][0]['content'],'原始转写10')
        self.assertEqual(source['historical_count'],3)

    def test_collection_windows_do_not_return_external_judgments(self):
        self.ingest()
        observation_id = self.db.execute('SELECT id FROM observations').fetchone()[0]
        rs.annotate(self.db, dict(observation_id=observation_id, model='external-agent',
                    prompt_version='test', sentiment='bullish', evidence='外部分析标签'))
        dates = [(self.t-timedelta(days=i)).date().isoformat() for i in range(2, 65)
                 if (self.t-timedelta(days=i)).weekday() < 5]
        result = rs.trading_windows(self.db, self.run['run_id'], dates)
        source = next(s for s in result['sources'] if s['source_id'] == self.batch['source_id'])
        sample = source['since_last_close']
        self.assertIn(observation_id, sample['observation_ids'])
        self.assertNotIn('annotations', sample)
        self.assertNotIn('labeled_count', sample)
        self.assertEqual(self.db.execute('SELECT count(*) FROM annotations').fetchone()[0], 1)


if __name__ == '__main__':
    unittest.main()
