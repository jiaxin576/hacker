"""分类归档原始证据，导出以客观数据为主体的精简中文投研材料。"""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
import hashlib
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

STATUS_ZH = {
    'ok': '已取得', 'no_update': '已检查，未发现更新', 'partial': '部分取得',
    'blocked': '访问受限', 'failed': '采集失败', 'not_configured': '未配置',
    'not_checked': '尚未检查', 'transcribed': '已转写',
    'awaiting_audio': '等待取得音频', 'historical_only': '仅有历史材料',
    'recent_cached_transcripts': '已有近期转写，尚未在线确认更新',
}
PLATFORM_ZH = {'xueqiu': '雪球', 'eastmoney': '东方财富', 'douyin': '抖音',
               'official': '基金管理人、交易所及公司披露', 'research': '经营驱动检索'}
TYPE_ZH = {'post': '主帖或文章', 'reply': '回复', 'audio_transcript': '音频转写',
           'title_only': '仅标题', 'disclosure': '披露原文', 'policy': '政策原文',
           'news': '新闻原文', 'research': '研报原文'}
FUND_FIELDS = {
    'quote': '行情与盘口', 'fund_profile': '基金档案与指数估值',
    'technical_summary': '日线统计指标', 'weekly_technical_summary': '周线统计指标',
    'recent_daily_bars': '日K线', 'recent_weekly_bars': '周K线',
    'daily_bars': '完整日K线', 'weekly_bars': '完整周K线',
    'constituents_analysis': '披露持仓及公司财务、两融', 'share_flow': '份额变化',
    'price_basis': '价格口径', 'return_accounting': '收益与分红记账核查',
}
MARKET_FIELDS = {'market_context': 'A股市场基准', 'market_breadth_and_volume': '市场宽度与成交额',
                 'market_margin_context': '全市场两融', 'overseas_context': '海外市场行情',
                 'macro_and_commodities': '利率、汇率与大宗商品'}


def status_zh(value):
    return STATUS_ZH.get(value, f'未知状态（{value}）' if value else '未知')


def source_name(source):
    platform = PLATFORM_ZH.get(source.get('platform'), source.get('platform', '未知平台'))
    if source.get('kind') == 'kol':
        return f"{platform}／大V／{source.get('name') or '未指定作者'}"
    if source.get('kind') == 'etf_comments':
        return f"{platform}／股吧与讨论区／{source.get('symbol', '')}"
    return f"{platform}／{source.get('symbol', '')}"


def financial_news_section(payload):
    section = {'说明': '东方财富财经报道与快讯独立归档；报道中的陈述及机构意见待核验，不自动计入基金客观事实。',
               '新闻列表': [], '按ETF索引': {}, '采集状态': {
                   s: {k:deepcopy(v) for k,v in group.items() if k!='items'}
                   for s,group in (payload.get('financial_news') or {}).get('by_etf',{}).items()}}
    by_key = {}
    def add(item, symbols=(), category='相关财经新闻'):
        url = item.get('url') or ''
        if url:
            parsed = urlsplit(url)
            query = [(k,v) for k,v in parse_qsl(parsed.query) if not k.startswith('utm_') and k not in ('spm','from')]
            key = urlunsplit((parsed.scheme,parsed.netloc,parsed.path,urlencode(query),''))
        else:
            key = json.dumps([item.get('id'),item.get('time'),item.get('title')], ensure_ascii=False)
        if key not in by_key:
            entry = {'新闻编号': hashlib.sha256(key.encode()).hexdigest()[:16], '标题': item.get('title'),
                '发布时间': item.get('published_at') or item.get('time'), '采集时间': item.get('fetched_at'),
                '发布平台': '东方财富' if ('eastmoney.com' in url or item.get('platform')=='eastmoney') else item.get('platform') or '见原始记录',
                '原始媒体': item.get('original_source') or item.get('source') or '未取得',
                '原链接': url or None, '内容类别': item.get('material_type') or category,
                '关联ETF': [], '正文完整': item.get('body_complete',False),
                '原始披露链接': item.get('origin_url'), '核验状态': item.get('verification_status') or '待核验',
                '原始记录': deepcopy(item)}
            by_key[key] = entry
            section['新闻列表'].append(entry)
        entry = by_key[key]
        for symbol in symbols:
            if symbol not in entry['关联ETF']:
                entry['关联ETF'].append(symbol)
            ids = section['按ETF索引'].setdefault(symbol, [])
            if entry['新闻编号'] not in ids:
                ids.append(entry['新闻编号'])
    for row in payload.get('etfs', []):
        for item in row.get('news', []):
            add(item, [row['symbol']])
    bundle = payload.get('financial_news') or {}
    for symbol, group in bundle.get('by_etf', {}).items():
        for item in group.get('items', []):
            add(item, [symbol])
    for item in bundle.get('supplement_items', []):
        add(item,item.get('related_etfs',[]))
    for item in payload.get('global_fast_news', []):
        add(item,item.get('related_etfs',[]),'全球宏观与产业快讯')
    return section


def classify(payload):
    """按来源角色与文献类型分类；文章中的数字不会自动成为客观字段。"""
    objective = {'说明': '供应商数据与披露记录；是否核验、日期和口径沿用原记录。',
                 '基金数据': {}, '市场环境数据': {}, '披露与政策原文': []}
    subjective = {'说明': '作者原话、视频转写与评论，均非采集器结论。', '平台': {}}
    references = {'说明': '新闻、研报与其他背景材料尚需逐条核验；不得自动转成客观事实。', '材料': []}
    quality = {'来源状态': [], '警告': list(payload.get('data_warnings', []))}
    for row in payload.get('etfs', []):
        symbol = row.get('symbol')
        if not symbol:
            continue
        objective['基金数据'][symbol] = {'名称': row.get('name') or (row.get('quote') or {}).get('name'),
            '采集时间': row.get('analysis_time'),
            '数据': {label: deepcopy(row[key]) for key, label in FUND_FIELDS.items() if key in row},
            '字段对应': {label: key for key, label in FUND_FIELDS.items() if key in row}}
        if row.get('official_fund_evidence'):
            objective['基金数据'][symbol]['披露来源'] = deepcopy(row['official_fund_evidence'])
    for key, label in MARKET_FIELDS.items():
        if key in payload:
            objective['市场环境数据'][label] = deepcopy(payload[key])
    seen_sources = set()
    for source in (payload.get('research_sources') or {}).get('sources', []):
        src = deepcopy(source)
        src.update(来源名称=source_name(source), 状态说明=status_zh(source.get('status')))
        src['items'] = deepcopy(source.get('items', [])) + deepcopy(source.get('undated_items', []))
        seen_sources.add(source.get('id'))
        quality['来源状态'].append({k: deepcopy(src.get(k)) for k in
            ('id', '来源名称', 'status', '状态说明', 'live_checked', 'attempt', 'recent_count', 'historical_count')})
        if source.get('kind') in ('kol', 'etf_comments'):
            platform = source.get('platform', 'unknown')
            group = subjective['平台'].setdefault(platform, {'平台名称': PLATFORM_ZH.get(platform, platform),
                                                            '大V文章与视频': [], '股吧与讨论区': []})
            role = '大V文章与视频' if source['kind'] == 'kol' else '股吧与讨论区'
            group[role].append(src)
        else:
            for item in src.get('items', []):
                material = {'来源名称': src['来源名称'], '来源状态': src['状态说明'], '原始记录': deepcopy(item)}
                if item.get('content_type') in ('disclosure', 'policy'):
                    objective['披露与政策原文'].append(material)
                else:
                    references['材料'].append(material)
    # Compatibility with packages containing only archived KOL data; never relabel as live.
    for kol in (payload.get('kol_columns') or {}).get('kol_list', []):
        platform = kol.get('platform', 'xueqiu')
        if not kol.get('id') or kol.get('configured') is False:
            continue  # 未配置来源的唯一状态记录已在来源清单中，不能再生成“未知作者”。
        if f"{platform}:kol:{kol.get('id')}" in seen_sources:
            continue
        group = subjective['平台'].setdefault(platform, {'平台名称': PLATFORM_ZH.get(platform, platform),
                                                        '大V文章与视频': [], '股吧与讨论区': []})
        group['大V文章与视频'].append({'id': f"{platform}:kol:{kol.get('id')}",
            '来源名称': f"{PLATFORM_ZH.get(platform, platform)}／大V／{kol.get('name') or '未知作者'}",
            '状态说明': status_zh(kol.get('status')), 'live_checked': kol.get('live_checked', False),
            'items': deepcopy(kol.get('articles', [])), '原始来源记录': deepcopy(kol)})
    return {'客观数据': objective, '主观数据': subjective, '财经新闻': financial_news_section(payload),
            '新闻研报与背景材料': references, '采集质量': quality}


def _cell(value):
    if value is None:
        return '未取得'
    if value is True:
        return '是'
    if value is False:
        return '否'
    return str(value).replace('|', '\\|').replace('\n', ' ')


def _quote(value):
    return '\n'.join('> ' + line for line in str(value or '（无正文）').splitlines())


def subjective_markdown(section):
    lines = ['# 主观资料：大V原文、视频转写与股吧评论', '', section['说明'], '']
    for platform in ('xueqiu', 'eastmoney', 'douyin', *sorted(set(section['平台']) - {'xueqiu','eastmoney','douyin'})):
        group = section['平台'].get(platform)
        if not group:
            continue
        lines += [f"## {group['平台名称']}", '']
        for role in ('大V文章与视频', '股吧与讨论区'):
            lines += [f'### {role}', '']
            if not group[role]:
                lines += ['本批未配置或未取得该类来源。', '']
            for source in group[role]:
                lines += [f"#### {source['来源名称']}", '',
                    f"- 采集状态：{source['状态说明']}；本批是否检查：{_cell(source.get('live_checked'))}",
                    f"- 采样说明：{(source.get('attempt') or {}).get('reason') or '见原始记录'}", '']
                if not source.get('items'):
                    lines += ['未取得可交付正文，不能推断作者未更新或市场观点中性。', '']
                for item in source.get('items', []):
                    context = item.get('market_context') or {}
                    lines += [f"##### {item.get('title') or '无标题记录'}", '',
                        f"- 作者：{item.get('author') or '未取得'}；作者编号：{item.get('author_id') or '未取得'}",
                        f"- 发布时间：{item.get('published_at') or '未知'}；观察时间：{item.get('observed_at') or item.get('collected_at') or '见批次记录'}",
                        f"- 复盘交易日：{', '.join(context.get('review_dates') or []) or '未知'}；日期依据：{context.get('date_evidence') or '未明确'}",
                        f"- 类型：{TYPE_ZH.get(item.get('content_type'), '未知')}；正文完整：{_cell(item.get('body_complete'))}",
                        f"- [原始链接]({item.get('url') or source.get('url') or ''})；父帖编号：{item.get('parent_id') or '无或未取得'}", '']
                    if item.get('content_type') == 'audio_transcript':
                        lines += [f"- 识别模型：{item.get('asr_model') or '未知'}；人工核对：{_cell(item.get('human_verified'))}；音频哈希：{item.get('media_sha256') or '未取得'}", '']
                    lines += [_quote(item.get('content')), '']
                    if item.get('translation_zh'):
                        lines += ['中文译文（与原文分开保留）：', '', _quote(item['translation_zh']), '']
    return '\n'.join(lines) + '\n'


def quality_markdown(quality):
    lines = ['# 采集质量与来源索引', '', '| 来源 | 本次状态 | 本批检查 | 窗口内记录数 |', '|---|---|---|---:|']
    for source in quality['来源状态']:
        lines.append('| ' + ' | '.join(_cell(source.get(k)) for k in ('来源名称','状态说明','live_checked','recent_count')) + ' |')
    lines += ['', '## 缺失与警告', '', *['- ' + str(w) for w in quality['警告']]]
    return '\n'.join(lines) + '\n'


def materials_markdown(section):
    lines = ['# 新闻研报与背景材料', '', section['说明'], '']
    for group in section['材料']:
        lines += [f"## {group.get('来源名称') or group.get('类别') or '背景材料'}", '']
        records = group.get('原始记录', {})
        for item in records if isinstance(records, list) else [records]:
            lines += [f"### {item.get('title') or '无标题记录'}", '',
                f"- 日期：{item.get('published_at') or item.get('time') or '未取得'}；关联ETF：{item.get('symbol') or group.get('关联ETF') or '见原文'}",
                f"- [原始链接]({item.get('url') or ''})", '',
                _quote(item.get('content') or item.get('summary')), '']
            if item.get('translation_zh'):
                lines += ['中文译文（另存）：', '', _quote(item['translation_zh']), '']
    return '\n'.join(lines) + '\n'


def financial_news_markdown(section):
    lines = ['# 东方财富相关财经新闻', '', section['说明'], '',
             '相同链接去重并关联多只ETF；不同链接的同事件报道保留来源链，不能直接当成独立验证。', '']
    for symbol, group in section['采集状态'].items():
        lines += [f"- {symbol}：{status_zh(group.get('status'))}；{group.get('reason') or '见原始采集记录'}"]
    if not section['新闻列表']:
        lines += ['', '本材料包未取得可交付新闻，仍需网页补采；不能据此认定没有相关新闻。']
    for item in section['新闻列表']:
        lines += ['', f"## {item['标题'] or '无标题新闻'}", '',
            f"- 发布时间：{item['发布时间'] or '未取得'}；采集时间：{item['采集时间'] or '见批次记录'}",
            f"- 平台：{item['发布平台']}；原始媒体：{item['原始媒体']}；类别：{item['内容类别']}",
            f"- 检索关联ETF：{'、'.join(item['关联ETF']) or '市场环境快讯'}；正文完整：{_cell(item['正文完整'])}；核验状态：{item['核验状态']}",
            f"- [报道原链接]({item['原链接']})" if item['原链接'] else '- 原链接未取得，须补采核对。', '',
            _quote(item['原始记录'].get('content') or item['原始记录'].get('summary'))]
    return '\n'.join(lines) + '\n'


def _nested(text):
    """移除子报告封面，把内部标题降一级以组成一份文档。"""
    lines=str(text or '').splitlines()
    if lines and lines[0].startswith('# '):lines=lines[1:]
    result=[]
    for line in lines:
        if line.startswith('#'):
            depth=len(line)-len(line.lstrip('#'))
            if depth<=6 and line[depth:depth+1]==' ':
                line='#'*min(6,depth+1)+line[depth:]
        result.append(line)
    return '\n'.join(result).strip()


def legacy_combined_markdown(payload,organized,objective_markdown):
    lines=['# 四只ETF信息采集汇总', '',
        f"- 行情包采集时间：{payload.get('collected_at') or '见各条记录'}；各来源更新时点以原记录为准。",
        '- 本文分类整理客观数据、财经新闻和作者原话；采集缺项不能视为中性或无更新。', '',
        '## 目录', '',
        '1. [采集概况与缺失项](#一采集概况与缺失项)',
        '2. [四只ETF客观数据](#二四只etf客观数据)',
        '3. [东方财富相关财经新闻](#三东方财富相关财经新闻)',
        '4. [主观资料：大V与讨论区](#四主观资料大v与讨论区)',
        '5. [其他新闻研报与背景材料](#五其他新闻研报与背景材料)',
        '6. [来源索引](#六来源索引)', '',
        '## 一、采集概况与缺失项', '', _nested(quality_markdown(organized['采集质量'])), '',
        '## 二、四只ETF客观数据', '', _nested(objective_markdown or '客观数据见附属JSON。'), '',
        '## 三、东方财富相关财经新闻', '', _nested(financial_news_markdown(organized['财经新闻'])), '',
        '## 四、主观资料：大V与讨论区', '', _nested(subjective_markdown(organized['主观数据'])), '',
        '## 五、其他新闻研报与背景材料', '', _nested(materials_markdown(organized['新闻研报与背景材料'])), '',
        '## 六、来源索引', '', '| 来源 | 入口 | 采集状态 |', '|---|---|---|']
    for source in (payload.get('research_sources') or {}).get('sources',[]):
        url=source.get('url')
        lines.append(f"| {_cell(source_name(source))} | {'[原始入口]('+url+')' if url else '见各条证据或未配置'} | {status_zh(source.get('status'))} |")
    lines+=['', '原始JSON、音频转写分段与网页证据另存，用于复现；本文不承诺完整采集已通过验收。','']
    return '\n'.join(lines)


def combined_markdown(payload, organized, objective_markdown=None):
    from research_brief import combined_markdown as render_brief
    return render_brief(payload, organized, objective_markdown)


def export(payload, output_dir, stem='ETF资料', objective_markdown=None):
    """新增分类导出；不改写调用方输入或旧快照，保持原始JSON字段兼容。"""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    organized = classify(payload)
    import research_brief as brief
    paths = {}
    for label in ('客观数据', '主观数据', '财经新闻', '新闻研报与背景材料', '采集质量'):
        path = output_dir / f'{stem}_{label}.json'
        path.write_text(json.dumps(organized[label], ensure_ascii=False, indent=2, default=str), encoding='utf-8')
        paths[label] = str(path)
    subjective_path = output_dir / f'{stem}_主观资料.md'
    subjective_path.write_text(brief.subjective_markdown(organized['主观数据']), encoding='utf-8')
    paths['主观资料报告'] = str(subjective_path)
    quality_path = output_dir / f'{stem}_采集质量.md'
    quality_path.write_text(brief.quality_markdown(payload, organized), encoding='utf-8')
    paths['采集质量报告'] = str(quality_path)
    material_path = output_dir / f'{stem}_新闻研报与背景材料.md'
    material_path.write_text(brief.events_markdown(brief.deduplicate_events(organized['新闻研报与背景材料']['材料'])), encoding='utf-8')
    paths['新闻研报背景报告'] = str(material_path)
    news_path = output_dir / f'{stem}_财经新闻.md'
    events = brief.event_records(organized)
    news_path.write_text(brief.events_markdown(events), encoding='utf-8')
    paths['财经新闻报告'] = str(news_path)
    objective_path = output_dir / f'{stem}_客观数据.md'
    objective_path.write_text(brief.objective_markdown(payload), encoding='utf-8')
    paths['客观数据报告'] = str(objective_path)
    for label, data in [('事件', events), ('原始采集', payload)]:
        path = output_dir / f'{stem}_{label}.json'
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
        paths[label] = str(path)
    combined_path = output_dir / f'{stem}_汇总报告.md'
    combined_path.write_text(combined_markdown(payload,organized,objective_markdown),encoding='utf-8')
    paths['汇总报告'] = str(combined_path)
    index = output_dir / f'{stem}_分类索引.md'
    lines = ['# ETF采集资料分类索引', '', '本文件只整理已采材料，不代表重新在线检查或完整性验收通过。', '',
             '客观数据、作者观点和待核验新闻研报分别归档；同一原文不重复计为独立证据。', '']
    lines += [f'- [{label}]({Path(path).name})' for label, path in paths.items()]
    index.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    paths['分类索引'] = str(index)
    return organized, paths


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True, help='已有采集JSON，不触发联网')
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--stem', default='ETF资料')
    args = parser.parse_args()
    payload = json.loads(args.input.read_text(encoding='utf-8-sig'))
    import etf_analyzer
    sections = []
    for row in payload.get('etfs', []):
        try:
            sections.append(etf_analyzer.format_markdown_report(row, include_news=False))
        except (KeyError, TypeError, ValueError):
            sections.append(f"## {row.get('symbol', '未知ETF')}\n\n部分字段缺失，已取得值见客观数据JSON。")
    _, paths = export(payload, args.output_dir, args.stem, objective_markdown='\n\n'.join(sections))
    print(json.dumps({'状态': '分类导出完成', '说明': '仅整理输入快照，未重新检查网页', '文件': paths}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
