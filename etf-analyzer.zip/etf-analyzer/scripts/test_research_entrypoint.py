import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import etf_analyzer as analyzer
import research_store as rs


class EntryTests(unittest.TestCase):
    def test_pending_blocks_network_and_failures_survive_report(self):
        with tempfile.TemporaryDirectory() as folder:
            db = rs.connect(Path(folder) / 'test.sqlite3')
            run = rs.begin(db, ['515180'])
            args = ['--source-run', run['run_id'], '--symbols', '515180', '--output-dir', folder]
            with patch.object(rs, 'connect', return_value=db), patch.object(analyzer, 'fetch_market_and_overseas_context') as fetch:
                with contextlib.redirect_stdout(io.StringIO()), self.assertRaises(SystemExit):
                    analyzer.main(args)
                fetch.assert_not_called()
            for source in run['sources']:
                if source.get('configured') is False:
                    continue
                rs.ingest(db, run['run_id'], dict(source_id=source['id'], checked_at=rs.now(),
                    status='failed', reason='isolated test failure', evidence='test fixture',
                    coverage={'pages': 0}, items=[]))
            methods = ['fetch_market_and_overseas_context', 'fetch_global_macro_and_commodities',
                       'fetch_market_breadth_and_volume', 'fetch_market_margin_context',
                       'fetch_global_fast_news', 'fetch_daily_bars', 'fetch_etf_info', 'collect_financial_news']
            with contextlib.ExitStack() as stack:
                stack.enter_context(patch.object(rs, 'connect', return_value=db))
                for method in methods:
                    stack.enter_context(patch.object(analyzer, method, side_effect=RuntimeError('test outage')))
                stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
                stack.enter_context(patch.object(analyzer.logging, 'exception'))
                analyzer.main(args)
                with self.assertRaises(ValueError):
                    analyzer.main(args)
            payload = json.loads(next(Path(folder).glob('etf_info_*.json')).read_text(encoding='utf-8'))
            self.assertTrue(payload['data_warnings'])
            self.assertFalse(payload['research_sources']['trading_day_comparison']['available'])
            self.assertEqual(db.execute('SELECT count(*) FROM analysis_snapshots').fetchone()[0], 1)
            db.close()


if __name__ == '__main__':
    unittest.main()
