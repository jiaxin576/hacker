"""东方财富独立调试入口；采集实现按基金、市场、K线、新闻分文件。"""
from datetime import datetime
from source_eastmoney_fund import fetch_fund_profile_and_valuation,fetch_constituents_analysis
from source_eastmoney_market import fetch_market_margin_context,fetch_market_breadth_and_volume,fetch_global_macro_and_commodities
from source_eastmoney_news import fetch_relevant_news,fetch_global_fast_news,fetch_news_article
from source_eastmoney_kline import fetch_eastmoney_bars
from source_eastmoney_comments import fetch_comments
from source_common import symbol_to_secid


if __name__=='__main__':
    from source_debug import run_source_cli
    run_source_cli('东方财富',{
        'fund':lambda a:fetch_fund_profile_and_valuation(a.symbol),
        'holdings':lambda a:fetch_constituents_analysis(a.symbol),
        'news':lambda a:fetch_relevant_news([a.keyword],cutoff=datetime.now(),days=a.days,limit=a.limit),
        'article':lambda a:fetch_news_article(a.url),
        'comments':lambda a:fetch_comments(a.symbol,limit=a.limit),
        'fast-news':lambda a:fetch_global_fast_news(a.limit),
        'margin':lambda a:fetch_market_margin_context(),
        'macro':lambda a:fetch_global_macro_and_commodities(),
        'breadth':lambda a:fetch_market_breadth_and_volume(datetime.now()),
        'daily':lambda a:fetch_eastmoney_bars(symbol_to_secid(a.symbol)[0],limit=a.limit),
        'weekly':lambda a:fetch_eastmoney_bars(symbol_to_secid(a.symbol)[0],period='week',limit=a.limit)})
