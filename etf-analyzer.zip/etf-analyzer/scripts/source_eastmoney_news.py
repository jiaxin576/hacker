"""东方财富：财经新闻检索与全球快讯。"""
from __future__ import annotations

import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable
from urllib.parse import urlencode
import requests
from source_common import DEFAULT_NEWS_DAYS, DEFAULT_NEWS_LIMIT, EASTMONEY_FAST_NEWS_URL, EASTMONEY_SEARCH_URL, ETF_SOFT_AD_RE, REQUEST_TIMEOUT, THEME_PRESETS, _clean_text, _parse_dt, _session, _strip_html


def fetch_news_article(url):
    """读取财经原文，保留平台与原始媒体；不把机构意见升级为事实。"""
    from urllib.parse import urlparse
    from bs4 import BeautifulSoup
    import requests
    parsed=urlparse(url or '')
    if parsed.scheme!='https' or not ((parsed.hostname or '')=='eastmoney.com' or (parsed.hostname or '').endswith('.eastmoney.com')):
        raise ValueError('需要东方财富公开原文HTTPS链接')
    response=requests.get(url,headers={'User-Agent':'Mozilla/5.0'},timeout=18);response.raise_for_status()
    response.encoding=response.apparent_encoding
    soup=BeautifulSoup(response.text,'html.parser');body=soup.select_one('#ContentBody')
    for node in soup(['script','style']):node.decompose()
    text=soup.get_text('\n',strip=True)
    content=body.get_text('\n',strip=True) if body else text
    return {'url':url,'platform':'eastmoney','fetched_at':datetime.now().astimezone().isoformat(),
            'content':content,'body_complete':bool(body and content),'available':bool(content),
            'note':'原始媒体、发布时间及原始披露链接需进一步核对；无正文容器时仅保存页面文本'}


def fetch_global_fast_news(limit: int = 15) -> list[dict[str, Any]]:
    """获取东方财富 7×24 小时全球宏观、海外市场与核心产业硬核快讯（自动过滤ETF营销软文）。"""
    session = _session()
    merged: dict[str, dict[str, Any]] = {}
    columns = (("101", "焦点要闻"), ("105", "国际宏观"), ("102", "7×24快讯"))
    priority_re = re.compile(
        r"(美联储|CPI|非农|加息|降息|美债|国债|央行|汇率|熔断|暴跌|救市|外资|IEA|原油|黄金|厄尔尼诺|"
        r"台积电|英伟达|Anthropic|OpenAI|微软|苹果|高通|阿斯麦|CoreWeave|存储|HBM|DDR|长鑫|寒武纪|海光|"
        r"中际旭创|新易盛|光模块|算力|半导体|芯片|宁德时代|储能|电网|核电|电价|煤炭|红利)",
        re.I,
    )
    for col_id, col_name in columns:
        try:
            r = session.get(
                EASTMONEY_FAST_NEWS_URL,
                params={
                    "client": "web",
                    "biz": "web_724",
                    "fastColumn": col_id,
                    "sortEnd": "",
                    "pageSize": "25",
                    "req_trace": "1",
                },
                headers={"Referer": "https://www.eastmoney.com/"},
                timeout=6,
            )
            rows = ((r.json().get("data") or {}).get("fastNewsList")) or []
            for row in rows:
                code = str(row.get("code") or "")
                title = _clean_text(row.get("title"))
                summary = _clean_text(row.get("summary"))
                text = f"{title} {summary}".strip()
                if not text or ETF_SOFT_AD_RE.search(text):
                    continue
                show_time = _clean_text(row.get("showTime"))
                is_key = bool(priority_re.search(text))
                key = code or f"{show_time}_{title[:30]}"
                if key not in merged:
                    merged[key] = {
                        "id": code or None,
                        "url": row.get('url') or row.get('uniqueUrl') or None,
                        "platform": "eastmoney",
                        "source": row.get('mediaName') or "东方财富快讯",
                        "fetched_at": datetime.now().astimezone().isoformat(timespec='seconds'),
                        "time": show_time,
                        "category": col_name,
                        "title": title or summary[:80],
                        "summary": summary[:280],
                        "is_priority": is_key,
                    }
        except Exception:
            continue

    items = list(merged.values())
    items.sort(key=lambda x: (1 if x["is_priority"] else 0, x["time"]), reverse=True)
    return items[:limit]

def build_news_keywords(
    symbol: str,
    fund_name: str,
    *,
    index_name: str | None = None,
    constituents: list[dict[str, Any]] | None = None,
    extra_keywords: Iterable[str] = (),
) -> list[str]:
    """根据基金名称、跟踪指数、前十大重仓股与预置主题词构建新闻检索关键词。"""
    clean_name = re.sub(r"ETF.*$", "ETF", fund_name) if "ETF" in fund_name else fund_name
    keywords: list[str] = [symbol, clean_name]
    if index_name:
        idx_short = re.sub(r"(主题|指数|证券|收益率|\(.*?\))", "", index_name).strip()
        if idx_short and len(idx_short) >= 2:
            keywords.append(idx_short)

    if constituents:
        top_names = [c["name"] for c in constituents[:5] if c.get("name")]
        if len(top_names) >= 2:
            keywords.append(f"{top_names[0]} {top_names[1]}")
        for n in top_names[:3]:
            keywords.append(n)

    combined_text = f"{fund_name} {index_name or ''}".lower()
    matched = False
    for preset in THEME_PRESETS.values():
        if any(t.lower() in combined_text for t in preset["triggers"]):
            keywords.extend(preset["keywords"])
            matched = True
    if not matched:
        keywords.extend((f"{clean_name}", "A股 ETF 资金", "央行 宏观政策"))

    keywords.extend(_clean_text(x) for x in extra_keywords if _clean_text(x))
    return [k for k in dict.fromkeys(keywords) if k][:14]

def fetch_relevant_news(
    keywords: Iterable[str],
    *,
    constituents: list[dict[str, Any]] | None = None,
    cutoff: datetime,
    days: int = DEFAULT_NEWS_DAYS,
    limit: int = DEFAULT_NEWS_LIMIT,
) -> list[dict[str, Any]]:
    """按主题词与重仓股检索东方财富新闻，去重、过滤时间并按相关性排序。"""
    session = _session()
    keyword_list = list(keywords)
    start = cutoff - timedelta(days=days)
    merged: dict[str, dict[str, Any]] = {}
    stock_names = [c["name"] for c in (constituents or []) if c.get("name")]

    for kw in keyword_list:
        try:
            rows = search_eastmoney_news(kw, session=session, page_size=8)
        except Exception as exc:
            logging.debug("东方财富新闻检索跳过 (%s): %s", kw, exc)
            continue
        for row in rows:
            published = _parse_dt(row.get("date"))
            if published is None or published < start or published > cutoff + timedelta(minutes=10):
                continue
            title = _strip_html(row.get("title"))
            summary = _strip_html(row.get("content"))
            url = _clean_text(row.get("url")).replace("http://", "https://", 1)
            if not title or not url:
                continue
            item = merged.setdefault(
                url,
                {
                    "time": published.isoformat(sep=" ", timespec="seconds"),
                    "title": title,
                    "summary": summary[:450],
                    "source": _clean_text(row.get("mediaName")) or "东方财富",
                    "url": url,
                    "matched_keywords": [],
                    "matched_constituents": [],
                },
            )
            if kw not in item["matched_keywords"]:
                item["matched_keywords"].append(kw)

    items = list(merged.values())
    for item in items:
        text = f"{item['title']} {item['summary']}".lower()
        title_l = item["title"].lower()
        for sn in stock_names:
            if sn.lower() in text and sn not in item["matched_constituents"]:
                item["matched_constituents"].append(sn)
        score = sum(
            3 if kw.lower() in title_l else 1
            for kw in keyword_list
            if any(part.lower() in text for part in kw.split())
        )
        score += len(item["matched_keywords"]) * 2 + len(item["matched_constituents"]) * 4
        if ETF_SOFT_AD_RE.search(item["title"]):
            score = max(1, score - 12)
            item["is_etf_marketing"] = True
        else:
            item["is_etf_marketing"] = False
        item["relevance_score"] = score

    items.sort(key=lambda x: (x["relevance_score"], x["time"]), reverse=True)
    return items[:limit]

def collect_financial_news(symbols, etfs, *, cutoff, days, limit):
    """新闻独立采集；行情整包失败不应使该ETF新闻模块随之被跳过。"""
    rows = {row['symbol']: row for row in etfs}
    names = {'159338': '中证A500ETF', '515070': '人工智能ETF',
             '159611': '电力ETF', '515180': '红利ETF'}
    def one(raw):
        symbol = raw.split('.')[-1]
        row = rows.get(symbol, {})
        keywords = row.get('news_keywords') or build_news_keywords(
            symbol, row.get('name') or names.get(symbol, symbol),
            constituents=(row.get('constituents_analysis') or {}).get('constituents'))
        items = row.get('news') or fetch_relevant_news(keywords,
            constituents=(row.get('constituents_analysis') or {}).get('constituents'),
            cutoff=cutoff, days=days, limit=limit)
        return symbol, {'status': 'partial', 'items': items, 'keywords': keywords,
            'window_days': days, 'fetched_at': datetime.now().astimezone().isoformat(timespec='seconds'),
            'needs_web_supplement': not bool(items),
            'reason': '已取得检索摘要，仍需核验原文、原始媒体及披露链接。' if items else
                      '接口未返回窗口内结果；不能据此认定无新闻，需东方财富网页补采。'}
    result = {}
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = {pool.submit(one, raw): raw.split('.')[-1] for raw in symbols}
        for future in as_completed(futures):
            symbol = futures[future]
            try:
                _, result[symbol] = future.result()
            except Exception as exc:
                result[symbol] = {'status':'failed','items':[], 'needs_web_supplement':True,
                                  'reason':f'财经新闻接口失败，需网页补采：{exc}'}
    return {'provider':'东方财富', 'by_etf':result, 'available':any(r['items'] for r in result.values())}

def search_eastmoney_news(keyword: str, *, session: requests.Session, page_size: int = 8) -> list[dict[str, Any]]:
    search_param = {
        "uid": "",
        "keyword": keyword,
        "type": ["cmsArticleWebOld"],
        "client": "web",
        "clientType": "web",
        "clientVersion": "curr",
        "param": {
            "cmsArticleWebOld": {
                "searchScope": "default",
                "sort": "time",
                "pageIndex": 1,
                "pageSize": page_size,
                "preTag": "",
                "postTag": "",
            }
        },
    }
    url = EASTMONEY_SEARCH_URL + "?" + urlencode(
        {"cb": "callback", "param": json.dumps(search_param, ensure_ascii=False, separators=(",", ":"))}
    )
    resp = session.get(url, headers={"Referer": "https://so.eastmoney.com/"}, timeout=REQUEST_TIMEOUT)
    resp.raise_for_status()
    text = resp.text
    s_idx, e_idx = text.find("{"), text.rfind("}")
    if s_idx < 0 or e_idx < s_idx:
        return []
    payload = json.loads(text[s_idx : e_idx + 1])
    return ((payload.get("result") or {}).get("cmsArticleWebOld")) or []


if __name__ == '__main__':
    from source_debug import run_source_cli
    run_source_cli('东方财富新闻',{'news':lambda a:fetch_relevant_news([a.keyword],cutoff=datetime.now(),days=a.days,limit=a.limit),
        'article':lambda a:fetch_news_article(a.url),'fast-news':lambda a:fetch_global_fast_news(a.limit)})
