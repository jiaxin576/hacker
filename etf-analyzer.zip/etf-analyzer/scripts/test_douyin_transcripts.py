"""Offline checks for source identity and transcript freshness in ETF reports."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from unittest.mock import patch
import source_douyin
import kol_config
import kol_collection

SPEC = importlib.util.spec_from_file_location("etf_under_test", Path(__file__).with_name("etf_analyzer.py"))
etf = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = etf
SPEC.loader.exec_module(etf)


class DouyinTranscriptTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = {"id": "MS4wLjABAAAA82IHtScs-vvmMmHpuc_ekwMpyc813SImU5ktR8mRBlw",
                       "platform": "douyin", "name": "Test author", "max_age_hours": 72}
        self.config = self.root / "sources.json"
        self.config.write_text(json.dumps([self.source]), encoding="utf-8")
        patches = [patch.object(source_douyin, "SKILL_DIR", self.root),
                   patch.object(kol_config, "KOL_SOURCES_FILE", self.config),
                   patch.object(kol_collection, "_load_cached_xueqiu_cookie", side_effect=AssertionError("Unexpected Xueqiu access"))]
        for item in patches:
            item.start()
            self.addCleanup(item.stop)
        self.directory = self.root / "data" / "kol_transcripts" / "douyin" / self.source["id"]
        self.directory.mkdir(parents=True)

    def write_article(self, **changes):
        article = {"id": "7664580569715477787", "author_id": self.source["id"],
                   "platform": "douyin", "content_type": "audio_transcript",
                   "status": "transcribed", "content": "Original speech", "title": "Test",
                   "segments": [{"start": 0, "end": 1, "text": "Original speech"}],
                   "published_at": datetime.now(timezone.utc).isoformat()}
        article.update(changes)
        (self.directory / "sample.json").write_text(json.dumps(article), encoding="utf-8")

    def result(self):
        return etf.fetch_kol_columns()["kol_list"][0]

    def test_douyin_id_preserved_and_does_not_access_xueqiu(self):
        self.assertEqual(etf.load_kol_sources()[0]["id"], self.source["id"])
        self.assertEqual(self.result()["status"], "awaiting_audio")

    def test_old_content_cannot_become_fresh_by_recollection(self):
        old = (datetime.now(timezone.utc) - timedelta(days=90)).isoformat()
        self.write_article(published_at=old, collected_at=datetime.now(timezone.utc).isoformat())
        result = self.result()
        self.assertEqual(result["status"], "historical_only")
        self.assertFalse(result["usable_for_current_analysis"])

    def test_recent_cache_does_not_claim_live_check(self):
        self.write_article()
        result = self.result()
        self.assertTrue(result["usable_for_current_analysis"])
        self.assertFalse(result["live_checked"])

    def test_other_author_rejected(self):
        self.write_article(author_id="another_author")
        self.assertEqual(self.result()["article_count"], 0)

    def test_title_is_not_a_transcript(self):
        self.write_article(content="", segments=[])
        self.assertEqual(self.result()["article_count"], 0)

    def test_unknown_or_future_publication_time_rejected(self):
        for value in ["2026-07-20T20:07:00", (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()]:
            with self.subTest(value=value):
                self.write_article(published_at=value)
                self.assertEqual(self.result()["article_count"], 0)


if __name__ == "__main__":
    unittest.main()
