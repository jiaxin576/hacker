#!/usr/bin/env python3
"""Transcribe downloaded Douyin media locally and archive it for ETF reports."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone, timedelta

SKILL_DIR = Path(__file__).resolve().parent.parent
CHINA_TZ = timezone(timedelta(hours=8))


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                     suffix=".tmp", delete=False) as handle:
        tmp = Path(handle.name)
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
    try:
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def timestamp(seconds: float) -> str:
    return f"{int(seconds // 60):02d}:{seconds % 60:05.2f}"


def srt_timestamp(seconds: float) -> str:
    milliseconds = round(seconds * 1000)
    hours, milliseconds = divmod(milliseconds, 3600000)
    minutes, milliseconds = divmod(milliseconds, 60000)
    whole_seconds, milliseconds = divmod(milliseconds, 1000)
    return f"{hours:02d}:{minutes:02d}:{whole_seconds:02d},{milliseconds:03d}"


def archive(media: Path, metadata: dict, raw: dict, model: str,
            output_dir: Path, cache_dir: Path | None = None) -> dict:
    """Validate metadata and actual media duration before accepting ASR text."""
    author_id = str(metadata["author_id"])
    if not re.fullmatch(r"[A-Za-z0-9_-]{6,160}", author_id):
        raise ValueError("抖音作者编号格式无效")
    video_id = str(metadata["video_id"])
    if not re.fullmatch(r"\d{15,25}", video_id):
        raise ValueError("抖音作品编号格式无效")
    expected_url = f"https://www.douyin.com/video/{video_id}"
    if metadata["url"].split("?", 1)[0] != expected_url:
        raise ValueError("视频链接与作品编号不一致")
    published = datetime.fromisoformat(metadata["published_at"])
    if published.tzinfo is None:
        raise ValueError("发布时间必须包含时区")
    if published > datetime.now(CHINA_TZ):
        raise ValueError("发布时间晚于当前时间")
    if not media.is_file():
        raise ValueError("已下载媒体文件不存在")
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        raise RuntimeError("未找到ffprobe，请使用已配置媒体工具的运行环境")
    probe = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration",
                            "-of", "json", str(media.resolve())],
                           capture_output=True, text=True, check=True, timeout=30)
    duration = float(json.loads(probe.stdout)["format"]["duration"])
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError("媒体时长无效")
    segments = []
    previous_start = -1.0
    for item in raw.get("segments", []):
        start, end = float(item["start"]), float(item["end"])
        if not (math.isfinite(start) and math.isfinite(end)
                and 0 <= start <= end <= duration + 1 and start >= previous_start):
            raise ValueError("音频识别分段时间戳无效")
        previous_start = start
        text = str(item.get("text") or "").strip()
        if text:
            segments.append({"start": start, "end": end, "text": text,
                             "avg_logprob": item.get("avg_logprob"),
                             "no_speech_prob": item.get("no_speech_prob")})
    if not segments:
        raise ValueError("未取得语音转写；不能用标题或简介代替")
    digest = hashlib.sha256()
    with media.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    now = datetime.now(CHINA_TZ).isoformat(timespec="seconds")
    article = {
        "id": video_id, "author_id": author_id,
        "author": metadata["author"], "platform": "douyin",
        "title": metadata["title"], "url": expected_url,
        "published_at": published.isoformat(timespec="seconds"),
        "collected_at": now, "content_type": "audio_transcript",
        "content": "\n".join(s["text"] for s in segments),
        "segments": segments, "duration_seconds": duration,
        "last_segment_end": segments[-1]["end"],
        "asr_engine": "openai-whisper-local", "asr_model": model,
        "language": raw.get("language", "zh"),
        "media_sha256": digest.hexdigest(), "human_verified": False,
        "status": "transcribed", "status_zh": "已转写", "opinion_only": True,
        "note": "本地音频识别原稿，可能有同音字及数字错误；不是已核实的市场事实。",
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    atomic_json(output_dir / "transcript.json", article)
    (output_dir / "transcript.txt").write_text(article["content"] + "\n", encoding="utf-8")
    lines = [f"# {article['title']}", "", f"- 作者：{article['author']}",
             f"- 视频：{expected_url}", f"- 发布时间：{article['published_at']}",
             f"- 音频时长：{duration:.2f}秒", f"- 识别模型：{model}（本地）",
             f"- {article['note']}", "", "## 带时间戳的原始转写", ""]
    lines.extend(f"[{timestamp(s['start'])}–{timestamp(s['end'])}] {s['text']}" for s in segments)
    (output_dir / "transcript.md").write_text("\n\n".join(lines) + "\n", encoding="utf-8")
    subtitles = [f"{index}\n{srt_timestamp(s['start'])} --> {srt_timestamp(s['end'])}\n{s['text']}\n"
                 for index, s in enumerate(segments, 1)]
    (output_dir / "transcript.srt").write_text("\n".join(subtitles), encoding="utf-8")
    root = cache_dir if cache_dir is not None else SKILL_DIR / "data" / "kol_transcripts"
    atomic_json(root / "douyin" / author_id / f"{video_id}.json", article)
    return article


def main() -> None:
    parser = argparse.ArgumentParser(description="本地转写抖音视频音频并归档原始讲话")
    parser.add_argument("--media", required=True, type=Path)
    parser.add_argument("--metadata", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--model", default="medium")
    parser.add_argument("--whisper-json", type=Path,
                        help="导入由同一媒体文件生成的Whisper原始识别JSON")
    args = parser.parse_args()
    metadata = json.loads(args.metadata.read_text(encoding="utf-8-sig"))
    if args.whisper_json:
        raw = json.loads(args.whisper_json.read_text(encoding="utf-8-sig"))
    else:
        import whisper
        model = whisper.load_model(args.model)
        raw = model.transcribe(str(args.media.resolve()), language="zh", task="transcribe",
                               verbose=False)
        atomic_json(args.output_dir / "whisper_raw.json", raw)
    article = archive(args.media, metadata, raw, args.model, args.output_dir)
    print(json.dumps({"状态": article["status_zh"], "作品编号": article["id"],
                      "分段数": len(article["segments"]),
                      "音频时长（秒）": article["duration_seconds"],
                      "输出目录": str(args.output_dir.resolve())}, ensure_ascii=False))


if __name__ == "__main__":
    main()
