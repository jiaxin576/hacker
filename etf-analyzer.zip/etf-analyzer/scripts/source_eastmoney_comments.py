"""东方财富股吧列表独立采集；原帖日期与最后回复日期分开保存。"""
from datetime import datetime
import json
import re
import requests
from urllib.parse import urljoin, urlsplit
from source_common import symbol_to_secid


def parse_comment_list(html,symbol,limit=100):
    match=re.search(r'\barticle_list\s*=\s*',html)
    if not match:return {'available':False,'status':'partial','items':[],
                         'reason':'未取得列表数据，需正常网页检查；不能认定无评论'}
    try: payload=json.JSONDecoder().raw_decode(html[match.end():])[0]
    except (ValueError,TypeError):
        return {'available':False,'status':'failed','items':[], 'reason':'列表JSON无法解析；不认定无评论'}
    if not isinstance(payload,dict):
        return {'available':False,'status':'failed','items':[], 'reason':'列表数据结构异常；不认定无评论'}
    from bs4 import BeautifulSoup
    anchors = {str(a.get('href')) for a in BeautifulSoup(html,'html.parser').find_all('a',href=True)}
    rows=payload.get('re') or [];items=[]
    for row in rows[:limit]:
        pub=row.get('post_publish_time')
        if pub and re.fullmatch(r'\d{4}-\d\d-\d\d \d\d:\d\d:\d\d',pub):pub=pub.replace(' ','T')+'+08:00'
        else:pub=None
        if not row.get('post_id'): continue
        actual_link = row.get('art_unique_url') or next((h for h in sorted(anchors) if re.search(r',%s\.html(?:\?|$)' % row['post_id'],h)),None)
        items.append({'id':str(row['post_id']),'symbol':symbol,'author_id':str(row.get('user_id') or ''),
            'author':row.get('user_nickname'),'title':row.get('post_title'),
            'content':row.get('post_title') or '（仅列表记录，未取得正文）','content_type':'title_only','body_complete':False,
            'published_at':pub,'published_at_raw':row.get('post_publish_time'),'last_reply_at_raw':row.get('post_last_time'),
            'url':urljoin('https://guba.eastmoney.com',actual_link) if actual_link else None,'reply_count':row.get('post_comment_count'),
            'read_count':row.get('post_click_count'),'board_code':row.get('stockbar_code'),
            'author_type':'unknown','note':'列表标题不等于全文；若原链接未返回，须从实际页面链接补采'} )
    return {'available':bool(items),'status':'partial','items':items,
            'reason':'已取得一页列表，正文与回复尚未逐条展开；列表含运营、营销或转载记录，不做情绪推断',
            'coverage':{'pages':1,'returned':len(items),'truncated':True}}


def parse_comment_detail(page, item):
    """读取正文容器；不以整页导航或回复区替代作者主帖。"""
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(page,'html.parser')
    body = soup.select_one('#zw_body') or soup.select_one('.newstext .text')
    if body is None:
        match = re.search(r'\bpost_article\s*=\s*',page)
        if match:
            try:
                raw = json.JSONDecoder().raw_decode(page[match.end():])[0]
                if str(raw.get('post_id')) == str(item['id']) and raw.get('post_content'):
                    body = BeautifulSoup(raw['post_content'],'html.parser')
            except (ValueError,TypeError,AttributeError): pass
    result = dict(item)
    if body is not None:
        for node in body.select('script,style,.advertisement,.ad'): node.decompose()
        text = body.get_text('\n',strip=True)
        if text:
            media = [img for img in body.find_all('img') if not re.search(r'emoji|emoticon|face',str(img),re.I)]
            result.update(content=text, content_type='post',body_complete=not bool(media),
                          unextracted_images=len(media))
    return result


def fetch_comments(symbol,limit=20,detail_limit=10):
    secid,code,pure=symbol_to_secid(symbol)
    url=f'https://guba.eastmoney.com/list,{code}.html'
    response=requests.get(url,headers={'User-Agent':'Mozilla/5.0'},timeout=18);response.raise_for_status()
    response.encoding=response.apparent_encoding
    data=parse_comment_list(response.text,pure,limit)
    checked = 0
    for index, item in enumerate(data.get('items',[])):
        if checked>=detail_limit: break
        # 过滤运营晒持仓和异吧引流；原始列表仍保存，主报告不展开。
        if str(item.get('board_code') or '').lower() in ('yyhd','jjhd'): continue
        if re.search(r'晒.*(?:持仓|操作)|欢迎.*(?:讨论|交流)|推广|开户|领取',item.get('title') or ''): continue
        link = item.get('url')
        if not link or urlsplit(link).hostname != 'guba.eastmoney.com': continue
        checked += 1
        try:
            detail = requests.get(link,headers={'User-Agent':'Mozilla/5.0'},timeout=18)
            detail.raise_for_status(); detail.encoding = detail.apparent_encoding
            data['items'][index] = parse_comment_detail(detail.text,item)
        except requests.RequestException as exc:
            item['detail_error'] = type(exc).__name__
    complete = sum(i.get('body_complete') is True for i in data.get('items',[]))
    data.setdefault('coverage',{}).update(detail_checked=checked,complete_bodies=complete)
    data['reason'] = f'取得{len(data.get("items",[]))}条列表，尝试{checked}条正文，取得{complete}条完整正文；非随机单页样本，不生成多空比例'
    data.update(url=url,fetched_at=datetime.now().astimezone().isoformat())
    return data


if __name__=='__main__':
    from source_debug import run_source_cli
    run_source_cli('东方财富股吧',{'comments':lambda a:fetch_comments(a.symbol,limit=a.limit)})
