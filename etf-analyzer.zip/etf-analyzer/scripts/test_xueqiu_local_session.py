"""本地登录态只用于雪球，Cookie及带Cookie异常不进入输出。"""
import json
from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import MagicMock,patch

from source_xueqiu import fetch_authenticated_discussions
from xueqiu_local_session import scoped_cookies,clone_cookie_profile,browser_profile,existing_debug_endpoint,configured_auth_mode


class LocalSessionTests(unittest.TestCase):
    def test_saved_browser_preference_requires_explicit_scoped_authorization(self):
        source={'id':'xueqiu','local_session':{'enabled':True,'preferred_browser':'chrome','scope':['xueqiu.com']}}
        with patch('xueqiu_local_session.Path.read_text',return_value=json.dumps({'sources':[source]})):
            self.assertEqual(configured_auth_mode(),'public')
        source['local_session']['authorization']='用户明确授权'
        with patch('xueqiu_local_session.Path.read_text',return_value=json.dumps({'sources':[source]})):
            self.assertEqual(configured_auth_mode(),'chrome')

    def test_cookie_scope_excludes_other_sites_and_origin_storage(self):
        cookies=scoped_cookies({'cookies':[
            {'name':'xq_a_token','value':'secret','domain':'.xueqiu.com','path':'/'},
            {'name':'login','value':'other-secret','domain':'.example.com','path':'/'},
            {'name':'fake','value':'bad','domain':'evilxueqiu.com','path':'/'}],
            'origins':[{'origin':'https://example.com','localStorage':[{'name':'secret','value':'hidden'}]}]})
        self.assertEqual(len(cookies),1)
        self.assertEqual(cookies[0]['domain'],'.xueqiu.com')

    def test_cookie_string_keeps_equals_in_value(self):
        rows=scoped_cookies({'cookie_str':'xq_a_token=secret==; u=123'})
        self.assertEqual(rows[0]['value'],'secret==')

    def test_browser_profile_rejects_arbitrary_paths(self):
        with self.assertRaises(RuntimeError):
            browser_profile('chrome','../../other')

    def test_debug_endpoint_uses_only_browser_published_loopback_address(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder)
            (base/'DevToolsActivePort').write_text('9222\n/devtools/browser/test-session\n',encoding='utf-8')
            with patch('xueqiu_local_session.browser_profile',return_value=(base,base/'Default')):
                self.assertEqual(existing_debug_endpoint(),'ws://127.0.0.1:9222/devtools/browser/test-session')
                (base/'DevToolsActivePort').write_text('9222\nhttps://other.example/\n',encoding='utf-8')
                self.assertIsNone(existing_debug_endpoint())

    def test_redirect_is_not_mislabeled_as_expired_cookie(self):
        context=MagicMock();response=MagicMock(status=302)
        response.headers={'location':'https://www.xueqiu.com/statuses/search.json'}
        context.get.return_value=response
        with patch('xueqiu_local_session.local_request_session') as factory:
            factory.return_value.__enter__.return_value=(context,{'方式':'现有Chrome'})
            result=fetch_authenticated_discussions('159338',auth_mode='chrome')
        self.assertIn('重定向',result['reason'])
        self.assertIn('尚未通过正文验收',result['reason'])
        self.assertFalse(result['available'])

    def test_playwright_exceptions_never_leak_cookie_header(self):
        context=MagicMock()
        context.get.side_effect=RuntimeError('Cookie: xq_a_token=do-not-print')
        with patch('xueqiu_local_session.local_request_session') as factory:
            factory.return_value.__enter__.return_value=(context,{'方式':'测试'})
            result=fetch_authenticated_discussions('159338')
        self.assertNotIn('do-not-print',json.dumps(result))
        self.assertEqual(result['status'],'failed')

    def test_authenticated_api_success_counts_bodies_not_http_success(self):
        context=MagicMock();response=MagicMock(status=200)
        response.json.return_value={'list':[{'id':1,'text':'根据财报，营收同比增长20%，仍需核验实际盈利质量。',
            'created_at':1792112400000,'user':{'id':2,'screen_name':'作者甲'}}]}
        context.get.return_value=response
        with patch('xueqiu_local_session.local_request_session') as factory:
            factory.return_value.__enter__.return_value=(context,{'方式':'测试'})
            result=fetch_authenticated_discussions('159338')
        self.assertEqual(len(result['items']),1)
        self.assertEqual(result['status'],'partial')
        self.assertEqual(context.get.call_args.kwargs['max_redirects'],0)

    def test_temporary_browser_clone_contains_only_xueqiu_original_unchanged(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder)/'original';profile=base/'Default';(profile/'Network').mkdir(parents=True)
            (base/'Local State').write_text('{}',encoding='utf-8')
            path=profile/'Network/Cookies'
            with closing(sqlite3.connect(path)) as db:
                db.execute('CREATE TABLE cookies(host_key TEXT, name TEXT)')
                db.executemany('INSERT INTO cookies VALUES (?,?)',[('.xueqiu.com','token'),('.example.com','other')])
                db.commit()
            target=Path(folder)/'clone';target.mkdir()
            with patch('xueqiu_local_session.browser_profile',return_value=(base,profile)):
                clone_cookie_profile('chrome','Default',target)
            with closing(sqlite3.connect(target/'Default/Network/Cookies')) as db:
                self.assertEqual(db.execute('SELECT host_key FROM cookies').fetchall(),[('.xueqiu.com',)])
            with closing(sqlite3.connect(path)) as db:
                self.assertEqual(db.execute('SELECT count(*) FROM cookies').fetchone()[0],2)


if __name__=='__main__': unittest.main()
