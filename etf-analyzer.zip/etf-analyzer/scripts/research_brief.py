"""面向分析智能体的精简投研材料；原始证据由 information_report 单独保存。"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone, timedelta
import hashlib
import json
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode


def cell(value):
    if value is None or value == '': return '未取得'
    return str(value).replace('|', '／').replace('\n', ' ')


def number(value, digits=2, suffix=''):
    if value is None: return '未取得'
    try: return f'{float(value):.{digits}f}{suffix}'
    except (TypeError, ValueError): return cell(value)


def display_date(value):
    if not value: return '未取得'
    try:
        parsed = datetime.fromisoformat(str(value).replace('Z','+00:00'))
        if parsed.tzinfo:
            return parsed.astimezone(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M（北京时间）')
    except ValueError: pass
    return str(value)


def table(headers, rows):
    return ['| ' + ' | '.join(headers) + ' |', '|' + '|'.join(['---']*len(headers)) + '|',
            *['| ' + ' | '.join(cell(v) for v in row) + ' |' for row in rows], '']


def clean_body(text):
    """移除采集工具标记和可识别导航；不补写原文没有的观点。"""
    text = re.sub(r'cite[^]*', '', str(text or ''))
    text = re.sub(r'\bL\d+:\s*', '', text)
    # 雪球页面正文从专栏来源声明后开始，避免把页面摘要重复算作论据。
    marker = re.search(r'来源：雪球App[^\n]*', text)
    if marker: text = text[marker.end():]
    text = re.split(r'(?:相关附件|相关文章|责任编辑[:：]|风险提示：文中提及|广告合作|点击查看全文)', text)[0]
    noise = ('首页','关注','来自','来自雪球','湖南','相关附件','相关文章','登录','注册','分享','举报')
    lines = []
    for line in text.splitlines():
        line = re.sub(r'\s+', ' ', line).strip(' #\t')
        if not line or line in noise or line.startswith(('发布于','来源：','作者：','http://','https://')):
            continue
        if re.search(r'<%|<script|<div|基金详情|从业人员信息公示', line): continue
        if line not in lines: lines.append(line)
    return '\n'.join(lines)


def excerpts(item, budget=260, count=2):
    """可复现的正文要点摘录；不把标题或推测变成作者论据。"""
    text = clean_body(item.get('translation_zh') or item.get('content'))
    title = re.sub(r'\s+', '', str(item.get('title') or ''))
    candidates = []
    for sentence in re.split(r'(?<=[。！？!?；;])|\n+', text):
        sentence = sentence.strip()
        if len(sentence) < 18 or re.sub(r'\s+', '', sentence) == title: continue
        if re.search(r'免责声明|投资有风险|不构成投资建议|特别声明|文章来源|基金吧|手机东方财富|东方财富APP|打开APP|下载APP', sentence): continue
        # 英文原文保存在JSON；报告不能拿未翻译整段充当中文摘要。
        if len(re.findall(r'[\u4e00-\u9fff]', sentence)) < 8: continue
        if sentence not in candidates: candidates.append(sentence)
    selected = candidates[:count]
    result = []
    remaining = budget
    for sentence in selected:
        if remaining <= 0: break
        result.append(sentence if len(sentence) <= remaining else sentence[:remaining]+'…〔摘录截断〕')
        remaining -= len(result[-1])
    return ' '.join(result)


def usable_body(item):
    if item.get('content_type') == 'title_only': return False
    body = clean_body(item.get('content'))
    title = clean_body(item.get('title'))
    return len(body) >= 30 and body != title


def substantive_comment(item):
    if not usable_body(item) or item.get('body_complete') is not True: return False
    text = clean_body(item.get('content'))
    if re.search(r'晒.*(?:持仓|操作)|网格.*晒单|见证奇迹|做[踢tT]|蚊子腿|该卖.*接回',text): return False
    if item.get('supporting_evidence_zh'): return True
    return bool(re.search(r'公告|财报|同比|环比|份额|融资|净申购|净赎回|尾盘放量|煤价|电价|估值',text))


def canonical_url(url):
    p = urlsplit(url or '')
    query = [(k,v) for k,v in parse_qsl(p.query) if k not in ('from','spm') and not k.startswith('utm_')]
    return urlunsplit(('https' if p.netloc else p.scheme, p.netloc.lower().removeprefix('www.'), p.path.rstrip('/'), urlencode(query), ''))


def deduplicate_events(records):
    """相同原文URL或规范化正文只存一次，合并ETF与出处；不同原文不靠标题强并。"""
    events, by_url, by_body = [], {}, {}
    for row in records:
        item = row.get('原始记录') or row
        url = canonical_url(item.get('url'))
        body = re.sub(r'\s+', '', clean_body(item.get('content')))
        digest = hashlib.sha256(body.encode()).hexdigest() if len(body) >= 80 else None
        index = by_url.get(url) if url else None
        if index is None and digest: index = by_body.get(digest)
        symbols = row.get('关联ETF') or item.get('related_etfs') or ([item['symbol']] if item.get('symbol') else [])
        if index is None:
            index = len(events)
            events.append({'事件编号':f'事件{index+1:02}', '关联ETF':[], '来源链':[], '原始记录':dict(item)})
        event = events[index]
        for symbol in symbols:
            if symbol not in event['关联ETF']: event['关联ETF'].append(symbol)
        origin = {'url':item.get('url'), 'id':item.get('id'), '来源':row.get('来源名称') or item.get('source')}
        if origin not in event['来源链']: event['来源链'].append(origin)
        for key,value in item.items():
            if event['原始记录'].get(key) in (None,'',[],{}) and value not in (None,'',[],{}):
                event['原始记录'][key] = value
        if len(str(item.get('content') or '')) > len(str(event['原始记录'].get('content') or '')):
            merged = dict(event['原始记录'])
            merged.update({k:v for k,v in item.items() if v is not None and v != ''})
            event['原始记录'] = merged
        if url: by_url[url] = index
        if digest: by_body[digest] = index
    return events


def objective_markdown(payload):
    lines = ['# 四只ETF客观数据', '', '以下为已取得的数据及确定性统计。估值分位与价格分位分列，未知历史窗口不据以判断贵贱。', '']
    for r in payload.get('etfs', []):
        q, f = r.get('quote') or {}, r.get('fund_profile') or {}
        t, w = r.get('technical_summary') or {}, r.get('weekly_technical_summary') or {}
        v, s, c = f.get('index_valuation') or {}, r.get('share_flow') or {}, r.get('constituents_analysis') or {}
        lines += [f"## {r['symbol']} {r.get('name') or q.get('name') or ''}", '',
                  f"行情时间：{cell(q.get('quote_time'))}；日线样本：{cell(t.get('日线区间'))}；周线样本：{cell(w.get('周线区间'))}。",
                  f"价格口径：{ {'vendor_forward_adjusted':'供应商前复权','qfq':'前复权','unadjusted':'未复权'}.get(r.get('price_basis'),cell(r.get('price_basis')))}；休市行情不代表当前可成交报价。", '']
        lines += table(['基本面与估值','已取得值','日期／口径'], [
            ['管理人／跟踪指数', f"{cell(f.get('fund_company'))}／{cell(v.get('index_name') or f.get('benchmark'))}", f"成立：{cell(f.get('establish_date'))}"],
            ['规模／跟踪误差',f"{number(f.get('report_scale_yi'))}亿元／{number(f.get('tracking_error_pct'),4,'%')}",f"规模报告期：{cell(f.get('report_scale_date'))}；跟踪误差统计区间见原始数据"],
            ['最新价／单位净值',f"{number(q.get('current_price'),3)}／{number(f.get('latest_nav'),4)}",f"净值日：{cell(f.get('nav_date'))}"],
            ['指数PE／PB',f"{number(v.get('pe_ttm'))}／{number(v.get('pb'),3)}",cell(v.get('valuation_date'))],
            ['PE／PB历史分位',f"{number(v.get('pe_percentile_pct'),2,'%')}／{number(v.get('pb_percentile_pct'),2,'%')}",v.get('percentile_window') or v.get('history_window') or '历史窗口未取得，仅保留供应商值'],
            ['指数股息率／ROE',f"{number(v.get('dividend_yield_pct'),2,'%')}／{number(v.get('roe_pct'),2,'%')}",'供应商统计，不能替代未来分红与盈利'],
        ])
        lines += table(['互补技术指标','日线','周线／风险口径'], [
            ['趋势',f"MA20={number(t.get('MA20'),4)}；MA60={number(t.get('MA60'),4)}",f"20周均线={number(w.get('WMA20'),4)}；4周斜率={number(w.get('wma20_slope_4w_pct'),2,'%')}"],
            ['动量',f"RSI14={number(t.get('rsi14'))}；MACD：{cell((t.get('macd') or {}).get('state'))}",'与趋势指标可能相关，不叠加计票'],
            ['阶段收益',f"5日={number(t.get('return_5d_pct'),2,'%')}；20日={number(t.get('return_20d_pct'),2,'%')}",f"13周={number(w.get('return_13w_pct'),2,'%')}"],
            ['波动／回撤',f"ATR20／价={number(t.get('atr20_pct'),2,'%')}",f"近1年最大回撤={number(f.get('max_drawdown_1y_pct'),2,'%')}；供应商统计"],
            ['历史价格分位',number((t.get('range_250d') or {}).get('close_percentile_pct'),2,'%'),'最近250交易日收盘价分位，不是估值分位'],
        ])
        lines += table(['份额与交易条件','数值','有效时点／限制'], [
            ['份额5日／20日变化',f"{number((s.get('change_5d') or {}).get('share_change_pct'),2,'%')}／{number((s.get('change_20d') or {}).get('share_change_pct'),2,'%')}",f"末日{s.get('current_trade_date') or '未知'}；基期{(s.get('change_5d') or {}).get('base_date') or '未知'}／{(s.get('change_20d') or {}).get('base_date') or '未知'}"],
            ['成交额',f"{number(q.get('amount')/1e8 if isinstance(q.get('amount'),(int,float)) else None)}亿元",'行情快照；份额变化不等同可归因净资金流'],
            ['价差／折溢价',f"{number(q.get('spread_pct'),4,'%')}／{number(q.get('premium_pct'),2,'%')}",'沿用上述行情时间；实际下单前重新采集'],
        ])
        lines += [f"持仓报告期：{cell(c.get('report_date'))}；前十大覆盖权重：{number(c.get('total_weight_pct'),2,'%')}。只代表已披露重仓部分。", '']
        stocks = sorted(c.get('constituents') or [],key=lambda x:x.get('weight_pct') or 0,reverse=True)[:3]
        if stocks:
            lines += table(['重点公司','权重','财报期','营收同比','净利同比','ROE'],[
                [a.get('name'),number(a.get('weight_pct'),2,'%'),a.get('report_period'),number(a.get('rev_yoy_pct'),2,'%'),number(a.get('profit_yoy_pct'),2,'%'),number(a.get('roe_pct'),2,'%')] for a in stocks])
        margin = c.get('margin_summary') or {}
        em = margin.get('etf_margin') or {}
        lines += [f"两融：ETF融资余额{number(em.get('fin_balance_yi'))}亿元，5日融资净买入{number(em.get('fin_net_buy_5d_yi'))}亿元（{cell(em.get('date'))}）；披露前十大合计5日融资净买入{number(margin.get('top10_fin_net_buy_5d_yi'))}亿元。", '']
        fs = c.get('fundamentals_summary') or {}
        lines += [f"披露重仓股统计：加权营收同比{number(fs.get('weighted_rev_yoy_pct'),2,'%')}、加权净利同比{number(fs.get('weighted_profit_yoy_pct'),2,'%')}、净利同比中位数{number(fs.get('median_profit_yoy_pct'),2,'%')}。仅覆盖已披露样本，不能代表整个指数的盈利增速。", '']
        for stock in c.get('constituents') or []:
            if stock.get('latest_earnings_forecast'):
                lines += [f"业绩预告（需核对原公告）：{cell(stock.get('name'))}，{str(stock['latest_earnings_forecast'])[:180]}。", '']
        accounting = r.get('return_accounting') or {}
        if accounting.get('require_reconciliation'):
            lines += [f"收益记账核查：{cell(accounting.get('reason'))}。不得把券商摊薄成本和显示浮盈直接当成真实投资收益率。", '']
    ownership = defaultdict(list)
    for r in payload.get('etfs',[]):
        for a in (r.get('constituents_analysis') or {}).get('constituents',[]):
            ownership[a.get('symbol') or a.get('name')].append((r['symbol'],a.get('name'),a.get('weight_pct')))
    overlaps = [entries for entries in ownership.values() if len(entries)>1]
    if overlaps:
        lines += ['## 持仓重合与市场环境', '', '以下重合仅按已披露前十大统计，完整指数的实际重合度可能更高。', '']
        lines += table(['重合公司','相关ETF及披露权重'],[[entries[0][1],'；'.join(f'{a[0]}：{number(a[2],2,"%")}' for a in entries)] for entries in overlaps])
    m = payload.get('market_margin_context') or {}
    breadth = payload.get('market_breadth_and_volume') or {}
    lines += [f"全市场：上涨{cell(breadth.get('up_count'))}家、下跌{cell(breadth.get('down_count'))}家；全A成交额{number(breadth.get('realtime_total_amount_yi'))}亿元。两融数据日{cell(m.get('date'))}，融资余额{number(m.get('fin_balance_yi'))}亿元，5日／20日融资净买入{number(m.get('net_buy_5d_yi'))}／{number(m.get('net_buy_20d_yi'))}亿元。", '']
    overseas = payload.get('overseas_context') or {}
    if overseas:
        labels = {'hsi':'恒生指数','hstech':'恒生科技','nasdaq':'纳斯达克','sp500':'标普500','nvidia':'英伟达','tsmc':'台积电','coreweave':'CoreWeave（算力信用观察）'}
        market_rows=[]
        for key,label in labels.items():
            a=overseas.get(key) or {}
            if isinstance(a,dict) and a:
                market_rows.append([label,a.get('current_price',a.get('price')),number(a.get('change_percent',a.get('change_pct')),2,'%'),a.get('quote_time') or a.get('time') or a.get('date') or '时点未取得'])
        if market_rows: lines += table(['跨市场观察','最新值（原市场计价）','涨跌幅','原市场时点'],market_rows)
    return '\n'.join(lines)


def subjective_markdown(section):
    lines = ['# 主观观点与讨论区', '', '仅摘录已取得的正文，作者陈述尚待客观数据核验。标题、互动数和重复转载不作为独立证据；不统计标题多空比例。', '']
    discussions = defaultdict(list)
    for platform, group in section.get('平台',{}).items():
        for source in group.get('股吧与讨论区',[]): discussions[source.get('symbol') or '未知'].append((group['平台名称'], source))
        for source in group.get('大V文章与视频',[]):
            if source.get('status') == 'not_configured' or not source.get('items'): continue
            selected, seen = [], set()
            for item in sorted(source.get('items',[]),key=lambda i:str(i.get('published_at') or ''),reverse=True):
                key = item.get('url') or item.get('id') or item.get('content')
                if key in seen or not usable_body(item): continue
                seen.add(key)
                summary = item.get('core_view_zh') or excerpts(item,240)
                if summary: selected.append((item,summary))
                if len(selected)>=2: break
            if not selected: continue
            lines += [f"## {group['平台名称']}：{source.get('name') or source.get('来源名称')}", '']
            for item, summary in selected:
                ctx = item.get('market_context') or {}
                dates = '、'.join(ctx.get('review_dates') or [])
                date = display_date(item.get('published_at'))[:10]
                lines += [f"- {cell(item.get('title') or '正文摘录')}（发布{date}" + (f"；复盘{dates}" if dates else '') + f"）：{summary}"]
                evidence = item.get('supporting_evidence_zh')
                if evidence: lines.append(f"  论据（作者陈述）：{str(evidence)[:180]}")
                if item.get('body_complete') is not True: lines.append('  采样局限：原文未完整取得，图片或音频内容不得推断。')
            lines.append('')
    if discussions:
        lines += ['## 讨论区：每只ETF一份采样摘要', '']
        for symbol, sources in discussions.items():
            parts = []
            for platform, source in sources:
                items = source.get('items') or []
                complete = [i for i in items if i.get('content_type') != 'title_only' and i.get('body_complete') is True
                          and i.get('author_type') not in ('marketing','fund_employee')]
                usable = [i for i in complete if substantive_comment(i)]
                digest = source.get('discussion_digest_zh')
                evidence_ids = set(map(str,source.get('digest_evidence_ids') or []))
                valid_ids = {str(i.get('id')) for i in complete}
                if digest and evidence_ids and evidence_ids <= valid_ids:
                    parts.append(f"{platform}：{len(items)}条列表、{len(complete)}条完整正文。{str(digest)[:150]}")
                    continue
                if not usable:
                    parts.append(f"{platform}：{len(items)}条列表、{len(complete)}条完整正文，未提炼出有论据的观点" if items else f'{platform}：未取得帖子正文')
                    continue
                representatives = []
                seen = set()
                for item in usable:
                    excerpt = excerpts(item,110,1)
                    if not excerpt or excerpt in seen: continue
                    seen.add(excerpt)
                    representatives.append(f"{item.get('author') or '作者未取得'}：{excerpt}")
                    if len(representatives)>=2: break
                parts.append(f"{platform}：{len(items)}条列表、{len(complete)}条完整正文，{len(usable)}条含待核验依据；"+'；'.join(representatives))
            lines.append(f"- **{symbol}**：{'；'.join(p.rstrip('。') for p in parts)}。")
        lines += ['', '采样局限：有限非随机样本，未展开的回复、无论据情绪及晒单不支持共识或多空比例判断。无正文时不能推断无更新。']
    return '\n'.join(lines)+'\n'


def event_records(organized):
    records = list(organized['新闻研报与背景材料'].get('材料',[]))
    # 宏观政策原文和转载若已关联同一URL，也只能形成一条事件。
    records += [r for r in organized['客观数据'].get('披露与政策原文',[])
                if (r.get('原始记录') or {}).get('content_type') == 'policy']
    for news in organized['财经新闻'].get('新闻列表',[]):
        item = dict(news['原始记录'])
        item.setdefault('published_at',news.get('发布时间'))
        item.setdefault('source', news.get('原始媒体'))
        records.append({'原始记录':item,'关联ETF':news.get('关联ETF',[])})
    return deduplicate_events(records)


def events_markdown(events):
    lines = ['# 财经新闻与背景事件', '', '同一原文只保留一份，合并关联ETF；报道和机构策略均须与原始披露核验。下列为正文摘录，不自动构成交易信号。', '']
    full = [e for e in events if usable_body(e['原始记录'])]
    mandatory = [e for e in full if e['原始记录'].get('major_change') or re.search(r'分红|派息|业绩|预亏|重大经营',str(e['原始记录'].get('title') or ''))]
    selected = list(full[:8])
    selected += [e for e in mandatory if e not in selected]
    for event in selected:
        item = event['原始记录']
        summary = item.get('event_summary_zh') or excerpts(item,200)
        if not summary: summary = '已取得非中文原文，中文摘要尚待核验；正文见原始证据。'
        categories = {'industry':'海外产业披露','macro':'宏观数据','unclassified':'宏观与背景原文'}
        title = item.get('event_title_zh') or item.get('title') or categories.get(item.get('category'),'背景材料')
        source = item.get('original_source') or item.get('source') or urlsplit(item.get('url') or '').netloc or '来源未取得'
        lines += [f"## {cell(title)}", '',f"- 日期：{display_date(item.get('published_at') or item.get('time') or item.get('published_at_raw'))}；关联ETF：{'、'.join(event['关联ETF']) or '市场环境'}。",
                  f"- 正文要点：{summary}",
                  f"- 来源：[{cell(source)}]({item['url']})；{item.get('verification_status') or '原文已取得，内容尚待逐项核验'}。" if item.get('url') else f"- 来源：{cell(source)}；链接未取得。"]
        facts = item.get('facts') or {}
        mechanism = item.get('transmission_zh') or facts.get('driver')
        if mechanism: lines.append(f'- 待核验传导线索：{str(mechanism)[:140].rstrip("。")}。')
        else: lines.append('- 传导逻辑：本批未核验；检索关联不等于已确定因果影响。')
        impact = item.get('potential_impact_zh')
        if impact: lines.append(f'- 可能影响（归因待核验）：{str(impact)[:140].rstrip("。")}。')
        else: lines.append('- 潜在利多／利空：未作核验判断，留给后续分析智能体交叉验证。')
        if re.search(r'AI生成|AI 生成',str(item.get('content') or '')):
            lines.append('- 可信度限制：原页面注明AI生成，不能替代公司原始公告。')
        lines.append('')
    omitted = len(events)-len(selected)
    if omitted: lines += [f'另有{omitted}条仅标题、缺正文、未译或超出本页预算的记录，留在事件JSON，不以标题补写事实或结论。', '']
    return '\n'.join(lines)


def missing_rows(payload):
    """按当前快照重核字段，消除补采前的过期警告和逐根K线重复提示。"""
    groups = defaultdict(set)
    rows = {r.get('symbol'):r for r in payload.get('etfs',[])}
    labels = {'turnover_rate':'换手率','cn10y_yield_pct':'中国10年国债收益率',
              'erp_vs_cn10y_pct':'股权风险溢价','dividend_spread_vs_cn10y_pct':'股息债息差',
              'macro_and_commodities':'利率汇率与商品','account_return_pct':'真实账户收益率',
              'latest_earnings_forecast':'业绩预告'}
    for warning in payload.get('data_warnings',[]):
        match = re.match(r'(\d{6})([^:]*): 缺失字段 (.*?)(?:（|$)', str(warning))
        if not match: continue
        symbol, path, fields = match.groups()
        obj = rows.get(symbol,{})
        for token in re.findall(r'([^.\[\]]+)|\[(\d+)\]',path):
            key = int(token[1]) if token[1] else token[0]
            try: obj = obj[key]
            except (KeyError,IndexError,TypeError): obj = {}; break
        for field in fields.split(','):
            field = field.strip()
            # ETF本身PE不代表指数估值；新闻另有独立采集结果。
            if field in ('pe_ttm','pe_dynamic','news','items','url','peg'): continue
            value = obj.get(field) if isinstance(obj,dict) else None
            if value is not None and value != [] and value != {}: continue
            period = '周K' if 'weekly_bars' in path else ('日K' if 'daily_bars' in path else '相关字段')
            dates = []
            bars = rows.get(symbol,{}).get('recent_weekly_bars' if period=='周K' else 'recent_daily_bars',[])
            if period != '相关字段': dates = [str(b.get('date')) for b in bars if b.get(field) is None and b.get('date')]
            interval = f'{min(dates)}至{max(dates)}' if dates else '本次快照'
            groups[(symbol,labels.get(field,field))].add(period+'，'+interval)
    # 新增或补采的ETF也要按实际数组验收，不能只沿用旧包警告。
    for symbol,row in rows.items():
        for key,period in [('recent_daily_bars','日K'),('recent_weekly_bars','周K')]:
            dates = [str(b['date']) for b in row.get(key,[]) if b.get('date') and b.get('turnover_rate') is None]
            if dates: groups[(symbol,'换手率')].add(f'{period}，{min(dates)}至{max(dates)}')
    combined = defaultdict(list)
    for (symbol,field),periods in sorted(groups.items()):
        combined[(field,'；'.join(sorted(periods)))].append(symbol)
    return [['、'.join(symbols),field,period,'源返回空字段，真实未披露／不适用尚待核实；禁用该字段信号'] for (field,period),symbols in combined.items()]


def quality_markdown(payload, organized):
    lines = ['# 缺失与采集局限', '', '访问失败、未返回字段、原始披露未取得分别记录；缺失不代表无更新或中性。', '']
    rows = missing_rows(payload)
    if rows: lines += table(['ETF','字段','范围','状态与使用限制'],rows)
    by_failure = defaultdict(list)
    for s in (payload.get('research_sources') or {}).get('sources',[]):
        items = s.get('items',[])+s.get('undated_items',[])
        if s.get('kind') == 'etf_comments':
            if s.get('from_successful_snapshot'):
                by_failure['雪球讨论正文来自本轮此前成功采样；最近一次Chrome连接重试超时，未确认更多更新'].append(s.get('symbol',''))
            if not any(usable_body(i) and i.get('body_complete') is True for i in items):
                if s.get('platform')=='xueqiu':
                    attempted=(s.get('attempt') or {}).get('reason')
                    reason = '雪球讨论：'+str(attempted)[:150] if attempted else '雪球未取得讨论正文；旧记录的“已读列表”不能通过正文验收'
                else: reason = '东方财富只有列表标题；不纳入观点证据'
                by_failure[reason].append(s.get('symbol',''))
        elif s.get('status') not in ('ok','no_update'):
            label = {'kol':'大V','fund_disclosures':'官方披露','business_drivers':'经营驱动'}.get(s.get('kind'),s.get('kind'))
            platform = {'douyin':'抖音','eastmoney':'东方财富','xueqiu':'雪球','official':'基金官方','research':'背景材料'}.get(s.get('platform'),s.get('platform'))
            reason = (s.get('attempt') or {}).get('reason') or {'not_configured':'未指定作者','blocked':'访问受限','failed':'采集失败','partial':'部分取得'}.get(s.get('status'),'待核验')
            # 同类动态披露状态集中，长错误不逐源展开。
            if s.get('kind') == 'fund_disclosures': reason = '仅部分核验，净值／持仓／分红／公告的官方覆盖未全部通过'
            if s.get('kind') == 'business_drivers': reason = '有限原文样本，产业高频数据与原始指引仍需补齐'
            by_failure[f'{platform}／{label}：{str(reason)[:150]}'].append(s.get('symbol') or s.get('name') or '')
    for reason,symbols in by_failure.items():
        scope='、'.join(dict.fromkeys(filter(None,symbols)))
        lines.append('- '+reason+(f'（{scope}）' if scope else '')+'。')
    if not payload.get('macro_and_commodities'):
        lines.append('- 利率、汇率与大宗商品未取得可用数据；跨市场归因缺少该组证据。')
    for warning in dict.fromkeys(str(w) for w in payload.get('data_warnings',[])):
        if '缺失字段' in warning or re.match(r'(?:official|research|xueqiu|eastmoney|douyin):',warning): continue
        if 'macro_and_commodities' in warning: continue
        if 'market_breadth_and_volume' in warning and (payload.get('market_breadth_and_volume') or {}).get('available'): continue
        if re.search(r'/news:',warning) and any(n.get('原始记录',{}).get('content') for n in organized['财经新闻'].get('新闻列表',[])): continue
        if warning.startswith(('本分类材料','财经新闻为','金融康博士已配置')): continue
        package = re.match(r'(\d{6}): 客观数据整包获取失败',warning)
        if package:
            current = next((r for r in payload.get('etfs',[]) if r.get('symbol')==package[1]),{})
            if current.get('quote') and current.get('fund_profile') and current.get('daily_bars') and current.get('weekly_bars'): continue
        if '515180' in warning and '成本' in warning: continue  # 上文收益记账核查已保留。
        lines.append('- '+warning)
    lines += ['- 份额有效时点、估值历史窗口和持仓覆盖存在口径限制，不能把供应商数值当作已核验的原始披露。', '']
    return '\n'.join(lines)


def combined_markdown(payload, organized, _legacy_objective=None):
    objective = objective_markdown(payload)
    # 官方分红和公告另列，不能因篇幅预算静默删去。
    evidence = deduplicate_events([r for r in organized['客观数据'].get('披露与政策原文',[])
        if (r.get('原始记录') or {}).get('content_type') == 'disclosure'
        and (r.get('原始记录') or {}).get('body_complete') is True])
    lines = ['# 四只ETF投研资料汇总', '', f"采集快照：{cell(payload.get('collected_at'))}。本文为已有证据整理，重新导出不代表重新联网。", '',
             '## 一、四只ETF客观数据', '', '\n'.join(objective.splitlines()[1:]),
             '## 二、官方分红、公告及重大披露核验', '']
    if payload.get('report_revision'):
        lines.insert(3,'本次修订：'+str(payload['report_revision'].get('说明') or '见修订输入。'))
    for event in evidence:
        item = event['原始记录']
        facts = item.get('facts') or {}
        if facts.get('cash_per_unit') is not None:
            text = f"每份现金分红{facts['cash_per_unit']}元；登记日{cell(facts.get('record_date'))}，除息日{cell(facts.get('ex_date'))}，发放日{cell(facts.get('payment_date'))}。除息、应收与现金到账分别处理。"
        else: text = item.get('verified_summary_zh') or excerpts(item,350,3)
        if not text: continue
        lines += [f"- {item.get('symbol') or '、'.join(event['关联ETF']) or '相关ETF'}：{text}"]
        publication = display_date(item.get('published_at'))
        if facts.get('published_date_precision') == 'date': publication = publication[:10]+'（仅日期）'
        if item.get('url'): lines.append(f"  [原始披露]({item['url']})；发布日期{publication}。")
    if not evidence: lines.append('本批未取得通过分类的官方披露正文，不能推断无分红、无公告。')
    events = events_markdown(event_records(organized))
    subjective = subjective_markdown(organized['主观数据'])
    quality = quality_markdown(payload,organized)
    for heading, content in [('三、财经新闻与背景事件',events),('四、主观观点与讨论区',subjective),('五、缺失与采集局限',quality)]:
        lines += ['', '## '+heading, '', '\n'.join('#'+x if x.startswith('## ') else x for x in content.splitlines()[1:])]
    lines += ['', '原始作者编号、链接、逐条时间、父帖、识别参数和全文保存在同批JSON。摘要与重复转载不增加独立证据数量。', '']
    return '\n'.join(lines)
