import unittest
from datetime import datetime
from unittest.mock import patch
import etf_analyzer as analyzer
import source_eastmoney_news


class NewsCollectionTests(unittest.TestCase):
    def test_missing_fund_package_still_collects_news_and_empty_is_partial(self):
        with patch.object(source_eastmoney_news,'fetch_relevant_news',return_value=[]) as fetch:
            bundle=analyzer.collect_financial_news(['159338','515070'],[],cutoff=datetime.now(),days=7,limit=5)
        self.assertEqual(fetch.call_count,2)
        self.assertEqual(set(bundle['by_etf']),{'159338','515070'})
        self.assertFalse(bundle['available'])
        self.assertTrue(all(row['needs_web_supplement'] for row in bundle['by_etf'].values()))
        self.assertTrue(all(row['status']=='partial' for row in bundle['by_etf'].values()))

    def test_existing_news_not_fetched_twice(self):
        rows=[{'symbol':'515070','news':[{'title':'原摘要'}]}]
        with patch.object(source_eastmoney_news,'fetch_relevant_news') as fetch:
            bundle=analyzer.collect_financial_news(['515070'],rows,cutoff=datetime.now(),days=3,limit=5)
        fetch.assert_not_called()
        self.assertEqual(bundle['by_etf']['515070']['items'][0]['title'],'原摘要')


if __name__=='__main__':
    unittest.main()
