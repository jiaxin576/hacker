"""验证主客观边界、归档完整性及实际分类导出。"""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import information_report as report


class InformationReportTests(unittest.TestCase):
    def fixture(self):
        return {'etfs': [{'symbol': '515070', 'quote': {'current_price': .915},
                         'news': [{'title': '某机构预计订单翻倍', 'summary': '未经核验的预测'}]}],
            'research_sources': {'sources': [
                {'id': 'xueqiu:kol:1', 'platform': 'xueqiu', 'kind': 'kol', 'name': '作者甲',
                 'status': 'partial', 'live_checked': True,
                 'items': [{'id': 'post1', 'content': '我预计PE为20倍，未来将大涨',
                            'published_at': '2026-10-16T10:21:00+08:00',
                            'market_context': {'review_dates': ['2026-10-15']}}]},
                {'id': 'eastmoney:etf:515070', 'platform': 'eastmoney', 'kind': 'etf_comments',
                 'symbol': '515070', 'status': 'partial', 'items': [],
                 'undated_items': [{'id': 'comment1', 'content': '评论原文，日期未核实', 'published_at': None}]},
                {'id': 'douyin:kol:2', 'platform': 'douyin', 'kind': 'kol', 'name': '金融康博士',
                 'status': 'blocked', 'live_checked': True, 'items': []},
                {'id': 'official:fund:515070', 'platform': 'official', 'kind': 'fund_disclosures',
                 'status': 'partial', 'items': [{'id': 'notice1', 'content_type': 'disclosure', 'content': '净值披露'}]},
                {'id': 'research:drivers:515070', 'platform': 'research', 'kind': 'business_drivers',
                 'status': 'partial', 'items': [{'id': 'research1', 'content_type': 'research', 'content': '研报预期'}]},
            ]}, 'kol_columns': {'kol_list': [{'id': '1', 'platform': 'xueqiu', 'articles': [{'id': 'post1'}]}]}}

    def test_numeric_opinions_and_news_never_become_fund_data(self):
        data = self.fixture()
        original = copy.deepcopy(data)
        result = report.classify(data)
        objective = json.dumps(result['客观数据'], ensure_ascii=False)
        self.assertNotIn('未来将大涨', objective)
        self.assertNotIn('未经核验的预测', objective)
        self.assertNotIn('研报预期', objective)
        self.assertIn('净值披露', objective)
        self.assertEqual(result['客观数据']['基金数据']['515070']['数据']['行情与盘口']['current_price'], .915)
        self.assertEqual(data, original)

    def test_platform_role_missing_dates_and_failures_survive(self):
        result = report.classify(self.fixture())
        groups = result['主观数据']['平台']
        self.assertEqual(len(groups['xueqiu']['大V文章与视频']), 1)  # No duplicate cache copy.
        comment = groups['eastmoney']['股吧与讨论区'][0]['items'][0]
        self.assertIsNone(comment['published_at'])
        self.assertEqual(groups['douyin']['大V文章与视频'][0]['状态说明'], '访问受限')
        self.assertEqual(groups['xueqiu']['大V文章与视频'][0]['items'][0]['market_context']['review_dates'], ['2026-10-15'])

    def test_export_retains_source_text_and_separates_files(self):
        with tempfile.TemporaryDirectory() as folder:
            _, files = report.export(self.fixture(), folder, '测试批次', objective_markdown='基金客观报告')
            self.assertTrue(all(Path(p).is_file() for p in files.values()))
            subjective = Path(files['主观资料报告']).read_text(encoding='utf-8')
            raw = Path(files['主观数据']).read_text(encoding='utf-8')
            objective = Path(files['客观数据报告']).read_text(encoding='utf-8')
            self.assertIn('我预计PE为20倍，未来将大涨', raw)
            self.assertIn('访问受限', raw)
            self.assertNotIn('我预计PE', objective)
            self.assertIn('评论原文，日期未核实', raw)
            self.assertNotIn('评论原文，日期未核实', subjective)

    def test_news_url_dedup_preserves_multiple_etf_links_and_media(self):
        payload=self.fixture()
        news={'url':'https://finance.eastmoney.com/a/123.html','title':'公司公告报道',
              'source':'中国证券报','summary':'报道原文摘要'}
        payload['etfs'][0]['news']=[news]
        payload['financial_news']={'by_etf':{'159338':{'status':'partial','items':[dict(news,url=news['url']+'?utm_source=test')]}}}
        section=report.classify(payload)['财经新闻']
        self.assertEqual(len(section['新闻列表']),1)
        self.assertEqual(set(section['新闻列表'][0]['关联ETF']),{'159338','515070'})
        self.assertEqual(section['新闻列表'][0]['原始媒体'],'中国证券报')
        self.assertEqual(section['新闻列表'][0]['核验状态'],'待核验')


if __name__ == '__main__':
    unittest.main()
