"""公共配置、数据类型、会话工厂与纯转换函数。"""
from __future__ import annotations

import html
import math
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
import requests


SCRIPT_DIR = Path(__file__).resolve().parent

SKILL_DIR = SCRIPT_DIR.parent

DEFAULT_SYMBOLS = ("159338", "515070", "159611", "515180")

EASTMONEY_BASE = "https://push2.eastmoney.com/api/qt"

EASTMONEY_DELAY_BASE = "https://push2delay.eastmoney.com/api/qt"

EASTMONEY_HISTORY_BASES = (
    "https://push2his.eastmoney.com/api/qt",
    "https://33.push2his.eastmoney.com/api/qt",
    "https://17.push2his.eastmoney.com/api/qt",
)

EASTMONEY_SEARCH_URL = "https://search-api-web.eastmoney.com/search/jsonp"

EASTMONEY_FAST_NEWS_URL = "https://np-weblist.eastmoney.com/comm/web/getFastNewsList"

FUND_MOB_BASE = "https://fundmobapi.eastmoney.com/FundMNewApi"

TENCENT_QUOTE_URL = "https://qt.gtimg.cn/q="

TENCENT_KLINE_URL = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"

SSE_SNAPSHOT_URL = "https://yunhq.sse.com.cn:32042/v1/sh1/snap/{symbol}"

REQUEST_TIMEOUT = 12

DEFAULT_NEWS_DAYS = 3

DEFAULT_NEWS_LIMIT = 15

DEFAULT_KLINE_LIMIT = 260

DEFAULT_WEEKLY_KLINE_LIMIT = 130

ETF_SHARE_CHANGE_SUSPECT_PCT = 25.0

EASTMONEY_DATACENTER_URL = "https://datacenter-web.eastmoney.com/api/data/v1/get"

TUSHARE_API_URL = "http://api.tushare.pro"

DEFAULT_TUSHARE_TOKEN = "401b133258e6f9fcac8a50437359abad5d0b2f95a15179a50b956f1c"

THEME_PRESETS: dict[str, dict[str, tuple[str, ...]]] = {
    "宽基A500": {
        "triggers": ("a500", "沪深300", "中证500", "中证1000", "上证50", "创业板", "科创50", "宽基"),
        "keywords": (
            "中证A500 ETF", "A股 核心资产 资金", "宽基ETF 净申购", "央行 降准 降息 货币政策",
            "财政政策 稳增长", "外资 北向 A股", "新质生产力 龙头股",
        ),
    },
    "人工智能": {
        "triggers": ("人工智能", "ai", "算力", "通信", "软件", "云计算", "大数据", "信创"),
        "keywords": (
            "人工智能ETF", "AI算力 大模型", "CPO 光模块", "国产AI芯片 寒武纪 海光",
            "美国科技股 纳斯达克", "英伟达 AI芯片", "存储芯片 HBM", "算力中心 服务器",
        ),
    },
    "半导体": {
        "triggers": ("半导体", "芯片", "集成电路", "科创芯片", "电子"),
        "keywords": (
            "半导体ETF", "国产芯片 自主可控", "晶圆 先进制程", "存储芯片 HBM",
            "费城半导体", "英伟达 AMD 博通", "半导体设备 光刻", "美国芯片 出口管制",
        ),
    },
    "电力公用": {
        "triggers": ("电力", "绿电", "公用事业", "能源", "电网", "特高压", "核电", "水电"),
        "keywords": (
            "电力ETF", "新型电力系统 电网投资", "特高压 算力电力", "水电 核电 火电 电价",
            "长江电力 中国核电", "绿电 碳中和", "用电量 迎峰度夏 迎峰度冬",
        ),
    },
    "红利高股息": {
        "triggers": ("红利", "高股息", "央企", "国企", "价值", "低波"),
        "keywords": (
            "红利ETF", "高股息 分红", "央企市值管理 国企改革", "险资 长期资金 举牌",
            "银行 煤炭 航运 股息率", "无风险利率 国债收益率",
        ),
    },
    "机器人": {
        "triggers": ("机器人", "智能制造", "自动化", "机床"),
        "keywords": ("机器人ETF", "人形机器人", "特斯拉 擎天柱", "减速器 丝杠 传感器", "具身智能"),
    },
    "新能源": {
        "triggers": ("新能源", "光伏", "锂电", "电池", "汽车", "储能", "风电"),
        "keywords": ("新能源ETF", "新能源汽车 销量", "锂电池 固态电池", "光伏 储能 逆变器", "碳酸锂"),
    },
    "医药医疗": {
        "triggers": ("医药", "医疗", "创新药", "生物", "中药", "恒生医疗"),
        "keywords": ("医药ETF", "创新药 临床 获批", "医疗器械 集采", "医保谈判 政策", "CXO 出海"),
    },
    "军工航天": {
        "triggers": ("军工", "国防", "航空", "航天", "卫星", "低空"),
        "keywords": ("军工ETF", "商业航天 卫星互联网", "国防军工 订单", "大飞机 低空经济"),
    },
    "金融券商": {
        "triggers": ("证券", "券商", "银行", "金融", "保险"),
        "keywords": ("证券ETF", "券商 并购 业绩", "银行 净息差", "资本市场政策 两融 成交额"),
    },
    "消费周期": {
        "triggers": ("消费", "白酒", "食品", "家电", "有色", "黄金", "煤炭", "化工"),
        "keywords": ("促消费 补贴 社零", "有色金属 黄金 铜价", "大宗商品 涨价"),
    },
}

MARKET_REFERENCES = {
    "上证指数": ("1.000001", "sh000001"),
    "沪深300": ("1.000300", "sh000300"),
    "中证A500": ("1.000510", "sh000510"),
    "中证500": ("1.000905", "sh000905"),
    "创业板指": ("0.399006", "sz399006"),
    "科创50": ("1.000688", "sh000688"),
    "中证红利": ("1.000922", "sh000922"),
}

OVERSEAS_REFERENCES = {
    "hsi": ("hkHSI", "恒生指数"),
    "hstech": ("hkHSTECH", "恒生科技"),
    "nasdaq": ("us.IXIC", "纳斯达克"),
    "sp500": ("us.INX", "标普500"),
    "nvidia": ("usNVDA", "英伟达"),
    "amd": ("usAMD", "AMD"),
    "broadcom": ("usAVGO", "博通"),
    "tsmc": ("usTSM", "台积电"),
    "asml": ("usASML", "阿斯麦"),
    "micron": ("usMU", "美光科技"),
    "coreweave": ("usCRWV", "CoreWeave"),
    "microsoft": ("usMSFT", "微软"),
    "apple": ("usAAPL", "苹果"),
    "tesla": ("usTSLA", "特斯拉"),
}

GLOBAL_MACRO_TARGETS: dict[str, tuple[str, str, str]] = {
    "kospi": ("100.KS11", "韩国KOSPI", "asia_index"),
    "nikkei225": ("100.N225", "日经225", "asia_index"),
    "phlx_sox": ("251.SOX", "费城半导体", "us_index"),
    "us10y": ("171.US10Y", "美债10年收益率(%)", "rate_fx"),
    "cn10y": ("171.CN10Y", "中债10年收益率(%)", "rate_fx"),
    "dxy": ("100.UDI", "美元指数", "rate_fx"),
    "usdcnh": ("133.USDCNH", "离岸人民币(USD/CNH)", "rate_fx"),
    "brent_oil": ("112.B00Y", "布伦特原油", "commodity"),
    "wti_oil": ("102.CL00Y", "NYMEX原油", "commodity"),
    "comex_gold": ("101.GC00Y", "COMEX黄金", "commodity"),
    "palm_oil": ("110.MPM00Y", "棕榈油连续", "commodity"),
}

ETF_SOFT_AD_RE = re.compile(
    r"(ETF|联接).*?(净流入|净申购|备受关注|配置价值|布局机遇|蓄势|吸金|反包|交投活跃|迎布局|一键布局|掘金)"
    r"|(资金抢筹|越跌越买).*?ETF",
    re.I,
)

KOL_SOURCES_FILE = SKILL_DIR / "data" / "kol_sources.json"

XUEQIU_COOKIE_CACHE = SKILL_DIR / "data" / "xueqiu_cookies.json"

DEFAULT_KOL_LIMIT = 2

DEFAULT_KOL_SOURCES: list[dict[str, Any]] = [
    {
        "id": "2817386050",
        "name": "搬砖小组",
        "platform": "xueqiu",
        "url": "https://www.xueqiu.com/u/2817386050",
        "style": "买方投研/全球宏观与产业高频数据日更复盘",
        "enabled": True,
        "max_articles": DEFAULT_KOL_LIMIT,
    }
]

@dataclass
class DailyBar:
    date: str
    open: float | None
    close: float | None
    high: float | None
    low: float | None
    volume: float | None
    amount: float | None
    amplitude_percent: float | None
    change_percent: float | None
    change_amount: float | None
    turnover_rate: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass
class Quote:
    symbol: str
    name: str
    market: int
    secid: str
    collected_at: str
    quote_time: str | None
    current_price: float | None
    change_amount: float | None
    change_percent: float | None
    avg_price: float | None
    volume: float | None
    amount: float | None
    volume_ratio: float | None
    high_price: float | None
    low_price: float | None
    open_price: float | None
    prev_close: float | None
    turnover_rate: float | None
    amplitude_percent: float | None
    upper_limit: float | None = None
    lower_limit: float | None = None
    high_52w: float | None = None
    low_52w: float | None = None
    iopv: float | None = None
    nav: float | None = None
    premium_pct: float | None = None
    total_market_value: float | None = None
    float_market_value: float | None = None
    total_shares: float | None = None
    outer_volume: float | None = None
    inner_volume: float | None = None
    active_buy_ratio: float | None = None
    bid1_price: float | None = None
    ask1_price: float | None = None
    bid1_volume: float | None = None
    ask1_volume: float | None = None
    spread_pct: float | None = None
    depth_imbalance: float | None = None
    bids: list[dict[str, float]] | None = None
    asks: list[dict[str, float]] | None = None
    pe_ttm: float | None = None
    pe_dynamic: float | None = None
    pb: float | None = None
    source: str = "Tencent/Eastmoney"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

def _session() -> requests.Session:
    session = requests.Session()
    session.verify = False
    session.headers.update(
        {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125 Safari/537.36"
            )
        }
    )
    return session

def _num(value: Any) -> float | None:
    if value in (None, "", "-", "--") or isinstance(value, bool):
        return None
    if isinstance(value, str):
        cleaned = value.strip().replace(",", "").replace("%", "")
        if not cleaned or cleaned in ("-", "--"):
            return None
        value = cleaned
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None

def _round(value: float | None, digits: int = 4) -> float | None:
    return round(value, digits) if value is not None and math.isfinite(value) else None

def _pct_change(current: float | None, base: float | None, digits: int = 2) -> float | None:
    if current is None or base in (None, 0):
        return None
    return round((current / base - 1.0) * 100.0, digits)

def _clean_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()

def _strip_html(value: Any) -> str:
    return _clean_text(html.unescape(re.sub(r"<[^>]+>", " ", str(value or ""))))

def split_symbol_values(values: Iterable[str]) -> list[str]:
    """解析空格、逗号分隔和误粘连的多个六位证券代码。"""
    result: list[str] = []
    for value in values:
        for item in re.split(r"[,;，；\s]+", str(value)):
            item = item.strip()
            if not item:
                continue
            item_clean = re.sub(r"^(?:sh|sz|bj)", "", item, flags=re.I)
            if item_clean.isdigit() and len(item_clean) > 6 and len(item_clean) % 6 == 0:
                result.extend(item_clean[i : i + 6] for i in range(0, len(item_clean), 6))
            else:
                result.append(item)
    if not result:
        raise ValueError("请提供至少一个 6 位 ETF 代码，例如 515070 或 159338")
    return list(dict.fromkeys(result))

def symbol_to_secid(raw: str) -> tuple[str, str, str]:
    """返回 (secid, tencent_code, pure_symbol)。"""
    text = raw.strip()
    if re.fullmatch(r"[01]\.\d{6}", text):
        market, sym = text.split(".", 1)
        prefix = "sh" if market == "1" else "sz"
        return text, f"{prefix}{sym}", sym
    m = re.fullmatch(r"(sh|sz|bj)(\d{6})", text, flags=re.I)
    if m:
        prefix, sym = m.group(1).lower(), m.group(2)
        market = "1" if prefix == "sh" else "0"
        return f"{market}.{sym}", f"{prefix}{sym}", sym
    sym = re.sub(r"\D", "", text)
    if len(sym) != 6:
        raise ValueError(f"无效的证券代码: {raw}（应为6位数字，如 515070、159338）")
    if sym.startswith(("5", "6", "9")):
        return f"1.{sym}", f"sh{sym}", sym
    if sym.startswith(("4", "8")):
        return f"0.{sym}", f"bj{sym}", sym
    return f"0.{sym}", f"sz{sym}", sym

def _parse_dt(value: Any) -> datetime | None:
    text = _clean_text(value).replace("T", " ").removesuffix("Z")
    if not text:
        return None
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None

def market_phase(value: datetime) -> str:
    if value.weekday() >= 5:
        return "周末自然休市时段"
    clock = value.strftime("%H:%M")
    if clock < "09:30":
        return "盘前时段"
    if "09:30" <= clock <= "11:30" or "13:00" <= clock <= "15:00":
        return "盘中连续竞价时段"
    if "11:30" < clock < "13:00":
        return "午间休市时段"
    return "盘后已收盘时段"
