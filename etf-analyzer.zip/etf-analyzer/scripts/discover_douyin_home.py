"""兼容旧命令；抖音实现位于source_douyin.py。"""
from source_douyin import parse_homepage, fetch_homepage, acquire, main

if __name__=="__main__":main()
