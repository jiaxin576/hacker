"""管理人、交易所与公司原始披露页面；独立保存原文，不推断投资观点。"""
from datetime import datetime
import hashlib
from io import BytesIO
from urllib.parse import urlparse
import requests


def fetch_official_page(url):
    allowed=('gtfund.com','efunds.com.cn','gffunds.com.cn','chinaamc.com','chinaamc.com.cn','sse.com.cn','szse.cn','cninfo.com.cn')
    parsed=urlparse(url or '')
    if parsed.scheme!='https' or not any(parsed.hostname==d or (parsed.hostname or '').endswith('.'+d) for d in allowed):
        raise ValueError('需要基金管理人、交易所或公司披露的HTTPS原始链接')
    r=requests.get(url,headers={'User-Agent':'Mozilla/5.0'},timeout=18);r.raise_for_status()
    if r.content[:4]==b'%PDF':
        from pypdf import PdfReader
        text='\n'.join(p.extract_text() or '' for p in PdfReader(BytesIO(r.content)).pages)
    else:
        from bs4 import BeautifulSoup
        r.encoding=r.apparent_encoding;soup=BeautifulSoup(r.text,'html.parser')
        for node in soup(['script','style']):node.decompose()
        text=soup.get_text('\n',strip=True)
    return {'url':url,'fetched_at':datetime.now().astimezone().isoformat(),'content':text,
            'sha256':hashlib.sha256(r.content).hexdigest(),'body_complete':False,
            'available':bool(text),'note':'原始页面文本，动态模块与披露字段仍需逐项核验'}


if __name__=='__main__':
    from source_debug import run_source_cli
    run_source_cli('官方披露',{'page':lambda a:fetch_official_page(a.url)})
