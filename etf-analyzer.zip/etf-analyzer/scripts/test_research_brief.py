"""报告降噪必须保留证据边界、关键披露和真实缺口。"""
import copy
import json
import unittest
from unittest.mock import MagicMock, patch

from information_report import classify, combined_markdown
from research_brief import deduplicate_events, missing_rows, subjective_markdown, events_markdown
from source_xueqiu import parse_discussion_page, parse_discussion_payload, fetch_discussions
from source_eastmoney_comments import parse_comment_detail, parse_comment_list


class ResearchBriefTests(unittest.TestCase):
    def test_320_headlines_and_audit_metadata_do_not_enter_brief(self):
        items=[{'id':str(i),'title':'晒一下我的操作记录','content':'晒一下我的操作记录',
                'content_type':'title_only','author_id':'audit-id','url':'https://test/'+str(i)} for i in range(320)]
        payload={'etfs':[], 'research_sources':{'sources':[{'id':'eastmoney:etf:515070','platform':'eastmoney',
                 'kind':'etf_comments','symbol':'515070','status':'partial','items':items}]}}
        original=copy.deepcopy(payload)
        organized=classify(payload)
        brief=subjective_markdown(organized['主观数据'])
        self.assertIn('320条列表、0条完整正文',brief)
        self.assertNotIn('晒一下',brief)
        self.assertNotIn('audit-id',brief)
        self.assertLess(len(brief),700)
        self.assertEqual(payload,original)
        self.assertEqual(len(organized['主观数据']['平台']['eastmoney']['股吧与讨论区'][0]['items']),320)

    def test_same_document_merges_etfs_and_keeps_date_from_short_version(self):
        body='宏观数据正文，保留有效事实。'*15
        rows=[{'原始记录':{'url':'https://www.test/a?utm_source=x','symbol':'159338','content':body,'published_at':'2026-10-14'}},
              {'原始记录':{'url':'https://test/a','symbol':'515070','content':body+'补充说明','published_at':None}},
              {'原始记录':{'url':'https://mirror/a','symbol':'159611','content':body}}]
        result=deduplicate_events(rows)
        self.assertEqual(len(result),1)
        self.assertEqual(set(result[0]['关联ETF']),{'159338','515070','159611'})
        self.assertEqual(result[0]['原始记录']['published_at'],'2026-10-14')

    def test_missing_bars_aggregate_and_recovered_field_not_reported(self):
        bars=[{'date':'2026-10-15','turnover_rate':None},{'date':'2026-10-16','turnover_rate':None}]
        p={'etfs':[{'symbol':'515070','quote':{'nav':1},'recent_daily_bars':bars}],
           'data_warnings':['515070.recent_daily_bars[0]: 缺失字段 turnover_rate（待核实）',
                            '515070.recent_daily_bars[1]: 缺失字段 turnover_rate（待核实）',
                            '515070.quote: 缺失字段 nav（待核实）']}
        rows=missing_rows(p)
        self.assertEqual(len(rows),1)
        self.assertIn('2026-10-15至2026-10-16',rows[0][2])
        self.assertNotIn('nav',str(rows))

    def test_dividend_dates_survive_and_homepage_navigation_is_excluded(self):
        p={'etfs':[],'research_sources':{'sources':[{'id':'official:fund:515180','platform':'official',
           'kind':'fund_disclosures','symbol':'515180','items':[
             {'content_type':'disclosure','body_complete':False,'content':'无关产品推荐'*50},
             {'content_type':'disclosure','body_complete':True,'symbol':'515180', 'facts':{
              'cash_per_unit':.061,'record_date':'2026-10-15','ex_date':'2026-10-16','payment_date':'2026-10-21'},
              'content':'分红公告原文'*20,'url':'https://official/test.pdf'}]}]}}
        text=combined_markdown(p,classify(p))
        self.assertNotIn('无关产品推荐',text)
        for value in ('.061','2026-10-15','2026-10-16','2026-10-21'): self.assertIn(value,text)

    def test_critical_event_not_silently_dropped_by_budget(self):
        rows=[{'原始记录':{'id':i,'title':'新闻'+str(i),'content':('已有新闻正文证据足够用于核验。'+str(i))*4}} for i in range(10)]
        rows[-1]['原始记录']['title']='重大经营业绩预亏公告'
        text=events_markdown(deduplicate_events(rows))
        self.assertIn('重大经营业绩预亏公告',text)

    def test_no_title_only_body_or_nonrandom_sentiment_conclusions(self):
        text=events_markdown([{'关联ETF':['515070'],'原始记录':{'title':'利好标题','content':'利好标题','content_type':'title_only'}}])
        self.assertNotIn('## 利好标题',text)


class SourceBodyTests(unittest.TestCase):
    def test_xueqiu_quote_shell_is_not_discussion(self):
        self.assertEqual(parse_discussion_page('<html><body>行情 MA20 讨论 热门 最新</body></html>'),[])

    def test_xueqiu_structured_body_and_timestamp(self):
        payload={'list':[{'id':1,'created_at':1792112400000,'text':'<p>财报营收增长20%，估值仍需结合现金流核实。</p>',
                         'user':{'id':2,'screen_name':'作者甲'}}]}
        items=parse_discussion_page('<script type="application/json">'+json.dumps(payload)+'</script>')
        self.assertEqual(len(items),1)
        self.assertTrue(items[0]['published_at'].endswith('+08:00'))
        self.assertNotIn('<p>',items[0]['content'])
        self.assertEqual(parse_discussion_payload({'list':[{'id':1,'title':'只有标题'}]}),[])

    def test_xueqiu_login_error_has_explicit_blocked_status(self):
        session=MagicMock()
        page=MagicMock(status_code=200,ok=True,text='<p>行情</p>')
        api=MagicMock(status_code=400,ok=False)
        api.json.return_value={'error_code':'400016','error_description':'请重新登录'}
        session.get.side_effect=[page,api]
        with patch('source_xueqiu.requests.Session') as factory:
            factory.return_value.__enter__.return_value=session
            data=fetch_discussions('159338')
        self.assertEqual(data['status'],'blocked')
        self.assertFalse(data['available'])
        self.assertEqual(data['items'],[])

    def test_eastmoney_follows_observed_link_and_reads_only_post(self):
        payload={'re':[{'post_id':1,'post_title':'有正文标题'}]}
        page='<a href="/news,sz159338,1.html">详情</a><script>article_list='+json.dumps(payload)+'</script>'
        item=parse_comment_list(page,'159338')['items'][0]
        self.assertEqual(item['url'],'https://guba.eastmoney.com/news,sz159338,1.html')
        detailed=parse_comment_detail('<nav>无关导航</nav><div id="zw_body">'+('公司财报营收增长20%，需要核验。'*4)+'</div><footer>推广</footer>',item)
        self.assertTrue(detailed['body_complete'])
        self.assertNotIn('无关导航',detailed['content'])
        self.assertNotIn('推广',detailed['content'])

    def test_short_complete_post_and_missing_image_are_separate(self):
        item={'id':'1','title':'垃圾','content':'垃圾','content_type':'title_only','body_complete':False}
        short=parse_comment_detail('<div id="zw_body">垃圾</div>',item)
        self.assertTrue(short['body_complete'])
        self.assertEqual(short['content_type'],'post')
        image=parse_comment_detail('<div id="zw_body">财报见图<img src="report.png"></div>',item)
        self.assertFalse(image['body_complete'])
        self.assertEqual(image['unextracted_images'],1)

    def test_later_shorter_duplicate_supplies_missing_publication_date(self):
        rows=[{'原始记录':{'url':'https://test/a','content':'正文更长，不能丢失。'*20}},
              {'原始记录':{'url':'https://test/a','content':'片段','published_at':'2026-10-14'}}]
        event=deduplicate_events(rows)[0]
        self.assertEqual(event['原始记录']['published_at'],'2026-10-14')
        self.assertGreater(len(event['原始记录']['content']),100)


if __name__=='__main__': unittest.main()
