import json
import unittest
from source_eastmoney_comments import parse_comment_list


class CommentParsingTests(unittest.TestCase):
    def test_publication_and_reply_dates_stay_separate_and_title_is_not_body(self):
        html='<script>var article_list='+json.dumps({'re':[{'post_id':1,'post_title':'列表标题',
            'post_publish_time':'2026-10-12 09:00:00','post_last_time':'2026-10-18 11:00:00'}]})+';</script>'
        row=parse_comment_list(html,'515070')['items'][0]
        self.assertEqual(row['published_at'],'2026-10-12T09:00:00+08:00')
        self.assertEqual(row['last_reply_at_raw'],'2026-10-18 11:00:00')
        self.assertEqual(row['content_type'],'title_only')
        self.assertFalse(row['body_complete'])
    def test_empty_page_is_not_successful_no_update(self):
        data=parse_comment_list('','515070')
        self.assertFalse(data['available'])
        self.assertNotEqual(data['status'],'no_update')


if __name__=='__main__':unittest.main()
