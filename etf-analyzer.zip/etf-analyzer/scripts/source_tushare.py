"""Tushare：ETF历史份额。"""
from __future__ import annotations

import logging
from source_common import DEFAULT_TUSHARE_TOKEN, TUSHARE_API_URL, _num, _session


def _fetch_remote_etf_share_history(symbol: str, market: int, limit: int = 35) -> dict[str, float]:
    """从 Tushare fund_share（主源）或上交所官方接口获取最近 N 个交易日的真实场内份额序列（单位：份）。"""
    session = _session()
    ts_code = f"{symbol}.{'SH' if market == 1 else 'SZ'}"
    share_map: dict[str, float] = {}
    try:
        resp = session.post(
            TUSHARE_API_URL,
            json={
                "api_name": "fund_share",
                "token": DEFAULT_TUSHARE_TOKEN,
                "params": {"ts_code": ts_code},
                "fields": "ts_code,trade_date,fd_share",
            },
            timeout=6,
        )
        if resp.status_code == 200:
            data = (resp.json() or {}).get("data") or {}
            fields = data.get("fields") or []
            items = data.get("items") or []
            if "trade_date" in fields and "fd_share" in fields:
                idx_dt = fields.index("trade_date")
                idx_sh = fields.index("fd_share")
                for row in items[:limit]:
                    raw_dt = str(row[idx_dt] or "").strip()
                    sh_wan = _num(row[idx_sh])
                    if len(raw_dt) == 8 and sh_wan and sh_wan > 0:
                        dt_fmt = f"{raw_dt[:4]}-{raw_dt[4:6]}-{raw_dt[6:8]}"
                        share_map[dt_fmt] = round(sh_wan * 10000.0, 2)
    except Exception as exc:
        logging.debug("Tushare 获取 %s 历史份额异常: %s", symbol, exc)

    return share_map


if __name__ == '__main__':
    from source_debug import run_source_cli
    from source_common import symbol_to_secid
    run_source_cli('Tushare份额', {'shares':lambda a:_fetch_remote_etf_share_history(a.symbol,int(symbol_to_secid(a.symbol)[0][0]),limit=a.limit)})
