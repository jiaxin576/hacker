"""大V身份及采集配置。"""
from __future__ import annotations

import json
import logging
from typing import Any, Iterable
from source_common import DEFAULT_KOL_LIMIT, DEFAULT_KOL_SOURCES, KOL_SOURCES_FILE
from source_xueqiu import _extract_xueqiu_uid


def load_kol_sources(extra_users: Iterable[str] = (), limit_override: int | None = None) -> list[dict[str, Any]]:
    """加载知名博主配置列表（data/kol_sources.json），并合并命令行临时指定的博主。"""
    KOL_SOURCES_FILE.parent.mkdir(parents=True, exist_ok=True)
    sources: list[dict[str, Any]] = []
    if KOL_SOURCES_FILE.exists():
        try:
            loaded = json.loads(KOL_SOURCES_FILE.read_text(encoding="utf-8"))
            if isinstance(loaded, list):
                sources = [s for s in loaded if isinstance(s, dict) and s.get("enabled", True)]
        except Exception as exc:
            logging.warning("读取 %s 失败，使用默认博主配置: %s", KOL_SOURCES_FILE, exc)
    if not sources:
        sources = [dict(item) for item in DEFAULT_KOL_SOURCES]
        try:
            KOL_SOURCES_FILE.write_text(json.dumps(sources, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    by_id: dict[tuple[str, str], dict[str, Any]] = {}
    for s in sources:
        platform = s.get("platform", "xueqiu")
        raw_id = str(s.get("id") or s.get("url") or "")
        uid = _extract_xueqiu_uid(raw_id) if platform == "xueqiu" else raw_id
        if not uid:
            continue
        entry = dict(s)
        entry["id"] = uid
        entry.setdefault("name", f"{platform}博主_{uid}")
        entry.setdefault("platform", "xueqiu")
        entry.setdefault("url", f"https://www.douyin.com/user/{uid}" if platform == "douyin"
                         else f"https://www.xueqiu.com/u/{uid}")
        entry.setdefault("style", "市场观察与复盘")
        entry["max_articles"] = int(limit_override or entry.get("max_articles") or DEFAULT_KOL_LIMIT)
        by_id[(platform, uid)] = entry

    for raw_u in extra_users or ():
        for part in str(raw_u).replace(",", " ").split():
            uid = _extract_xueqiu_uid(part)
            if not uid:
                continue
            key = ("xueqiu", uid)
            if key in by_id:
                if limit_override:
                    by_id[key]["max_articles"] = int(limit_override)
            else:
                by_id[key] = {
                    "id": uid,
                    "name": f"雪球博主_{uid}",
                    "platform": "xueqiu",
                    "url": f"https://www.xueqiu.com/u/{uid}",
                    "style": "自定义关注博主",
                    "enabled": True,
                    "max_articles": int(limit_override or DEFAULT_KOL_LIMIT),
                }
    return list(by_id.values())

def add_kol_source_to_config(raw_uid_or_url: str, name: str = "", style: str = "市场观点与复盘") -> dict[str, Any]:
    """将新博主持久化写入 data/kol_sources.json。"""
    uid = _extract_xueqiu_uid(raw_uid_or_url)
    if not uid:
        raise ValueError(f"无法从 {raw_uid_or_url!r} 解析出有效的博主 ID")
    KOL_SOURCES_FILE.parent.mkdir(parents=True, exist_ok=True)
    existing: list[dict[str, Any]] = []
    if KOL_SOURCES_FILE.exists():
        try:
            existing = json.loads(KOL_SOURCES_FILE.read_text(encoding="utf-8"))
            if not isinstance(existing, list):
                existing = []
        except Exception:
            existing = []
    if not existing:
        existing = [dict(item) for item in DEFAULT_KOL_SOURCES]

    target: dict[str, Any] | None = None
    for item in existing:
        if item.get("platform", "xueqiu") == "xueqiu" and _extract_xueqiu_uid(item.get("id") or "") == uid:
            target = item
            break
    if target is None:
        target = {
            "id": uid,
            "name": name or f"雪球博主_{uid}",
            "platform": "xueqiu",
            "url": f"https://www.xueqiu.com/u/{uid}",
            "style": style or "市场观点与复盘",
            "enabled": True,
            "max_articles": DEFAULT_KOL_LIMIT,
        }
        existing.append(target)
    else:
        if name:
            target["name"] = name
        if style:
            target["style"] = style
        target["enabled"] = True

    KOL_SOURCES_FILE.write_text(json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8")
    return target
