"""ETF客观数据与历史兼容报告渲染。"""
from __future__ import annotations

from typing import Any, Iterable


def format_kol_markdown_section(kol_ctx: dict[str, Any] | None) -> str:
    """将知名博主最新专栏格式化为 Markdown 章节。"""
    if not kol_ctx or not kol_ctx.get("kol_list"):
        return ""
    lines: list[str] = []
    lines.append("## 主观参考：知名博主专栏与视频转写（交叉验证源）")
    lines.append("")
    lines.append(
        f"> 配置文件：`{kol_ctx.get('config_file')}`（可通过编辑该 JSON 或使用 `--add-kol <雪球UID或链接> \"博主名\" \"风格\"` 随时追加新博主）"
    )
    for kol in kol_ctx.get("kol_list", []):
        lines.append("")
        style_str = f" | **风格定位**：{kol['style']}" if kol.get("style") else ""
        lines.append(f"### 博主：{kol.get('name')}（UID: `{kol.get('id')}`{style_str}）")
        if kol.get("note"):
            lines.append(f"> {kol['note']}")
        articles = kol.get("articles") or []
        if not articles:
            lines.append(f"- 暂无最新文章（{kol.get('error') or '无数据'}）")
            continue
        for idx, art in enumerate(articles, 1):
            view_str = f" | 阅读 `{art['view_count']}`" if art.get("view_count") else ""
            lines.append(
                f"\n#### [{idx}] 《{art.get('title')}》 — 发布于 `{art.get('published_at')}`{view_str} ([原文链接]({art.get('url')}))"
            )
            lines.append("")
            if art.get("content_type") == "audio_transcript":
                age_label = "历史材料，保留原始发布日期" if art.get("freshness") == "historical" else "近期已归档材料，未核实今天是否有更新"
                lines.append(f"> {age_label}；音频转写（{art.get('asr_model')}），未经人工逐字校对。作者观点需与客观数据验证。\n")
            lines.append(art.get("content") or art.get("summary") or "（无正文）")
    return "\n".join(lines) + "\n"

def format_markdown_report(data: dict[str, Any], *, include_news: bool = True) -> str:
    """将单只 ETF 采集到的全量客观信息格式化为 Markdown 报告。"""
    q = data["quote"]
    prof = data["fund_profile"]
    idx_val = prof.get("index_valuation") or {}
    tech = data["technical_summary"]
    w_tech = data.get("weekly_technical_summary") or {}
    comp = data["constituents_analysis"]
    flow = data["share_flow"]
    news = data["news"]
    price_label = "未复权" if data.get('price_basis') == 'unadjusted' else '供应商前复权'

    lines: list[str] = []
    lines.append(f"## {q['name']}（{q['symbol']}）客观信息汇总")
    lines.append("")
    lines.append(f"- **采集时间**：{data['analysis_time']}（{data['market_phase']}） | **数据源**：{q.get('source')}")
    lines.append(
        f"- **实时行情**：最新价 **{q['current_price']}** | 涨跌幅 **{q['change_percent']:+.2f}%** ({q['change_amount']:+.4f}) "
        f"| 今开 {q['open_price']} | 最高 {q['high_price']} | 最低 {q['low_price']} | 昨收 {q['prev_close']}"
        if q.get("change_percent") is not None and q.get("change_amount") is not None
        else f"- **实时行情**：最新价 **{q.get('current_price')}**"
    )
    amt_yi = round(q["amount"] / 1e8, 2) if q.get("amount") else None
    mv_yi = round(q["total_market_value"] / 1e8, 2) if q.get("total_market_value") else None
    sh_yi = flow.get("shares_yi") or (round(q["total_shares"] / 1e8, 2) if q.get("total_shares") else None)
    lines.append(
        f"- **量能与折溢价**：分时均价(VWAP) `{q.get('avg_price')}` | 实时IOPV `{q.get('iopv')}` | 最新单位净值(NAV) `{q.get('nav') or prof.get('latest_nav')}` "
        f"| 折溢价率 `{q.get('premium_pct')}%` | 成交额 `{amt_yi}亿` | 换手率 `{q.get('turnover_rate')}%` | 量比 `{q.get('volume_ratio')}` | 振幅 `{q.get('amplitude_percent')}%`"
    )
    lines.append(
        f"- **盘口与资金流**：买一 `{q.get('bid1_price')}` ({q.get('bid1_volume')}手) / 卖一 `{q.get('ask1_price')}` ({q.get('ask1_volume')}手) "
        f"| 盘口失衡度 `{q.get('depth_imbalance')}` | 外盘主动买占比 `{round(q['active_buy_ratio'] * 100, 1) if q.get('active_buy_ratio') is not None else None}%`"
    )

    c1 = flow.get("change_1d") or {}
    c5 = flow.get("change_5d") or {}
    c20 = flow.get("change_20d") or {}
    s1_str = (
        f"较前日({c1.get('base_date')}) `{c1['share_change_pct']:+.2f}%` ({c1['net_shares_yi']:+.2f}亿份 / 约 `{c1['net_amount_yi']:+.2f}亿`)"
        if c1.get("share_change_pct") is not None and c1.get("net_amount_yi") is not None
        else "暂无单日对比"
    )
    s5_str = (
        f"近5日 `{c5['share_change_pct']:+.2f}%` ({c5['net_shares_yi']:+.2f}亿份 / 约 `{c5['net_amount_yi']:+.2f}亿`，{c5.get('inflow_days', 0)}日净申购/{c5.get('outflow_days', 0)}日净赎回)"
        if c5.get("share_change_pct") is not None and c5.get("net_amount_yi") is not None
        else "暂无5日对比"
    )
    s20_str = (
        f"近20日 `{c20['share_change_pct']:+.2f}%` ({c20['net_shares_yi']:+.2f}亿份 / 约 `{c20['net_amount_yi']:+.2f}亿`)"
        if c20.get("share_change_pct") is not None and c20.get("net_amount_yi") is not None
        else "暂无20日对比"
    )
    lines.append(
        f"- **场内规模与近1/5/20日份额申赎趋势**：场内总市值 `{mv_yi}亿` | 场内总份额 `{sh_yi}亿份`（20日份额分位 `{flow.get('share_percentile_20d_pct')}%`）  \n"
        f"  - **份额变化统计**：**{flow.get('trend_5d_20d_summary') or flow.get('status', '未知')}**（单日状态：{flow.get('status', '未知')}）  \n"
        f"  - **1D / 5D / 20D 明细**：{s1_str} | {s5_str} | {s20_str}"
    )

    etf_mg = ((comp.get("margin_summary") or {}).get("etf_margin")) or {}
    if etf_mg.get("available"):
        lines.append(
            f"- **ETF自身两融数据（{etf_mg.get('date')}）**：融资余额 `{etf_mg.get('fin_balance_yi')}亿`（单日增幅 `{etf_mg.get('fin_change_1d_pct')}%`） "
            f"| 融资净买入：1日 `{etf_mg.get('fin_net_buy_1d_yi'):+.3f}亿` / 3日 `{etf_mg.get('fin_net_buy_3d_yi'):+.3f}亿` / 5日 `{etf_mg.get('fin_net_buy_5d_yi'):+.3f}亿` / 10日 `{etf_mg.get('fin_net_buy_10d_yi'):+.3f}亿` "
            f"| 融券余额 `{etf_mg.get('loan_balance_yi')}亿`"
        )

    lines.append("\n### 一、基金基本面与跟踪指数估值")
    lines.append(
        f"- **基金档案**：{prof.get('fund_company') or '-'} | 类型：{prof.get('fund_type') or '-'} | 成立日：{prof.get('establish_date') or '-'} "
        f"| 报告期规模：`{prof.get('report_scale_yi')}亿` ({prof.get('report_scale_date')}) | 年化跟踪误差：`{prof.get('tracking_error_pct')}%`"
    )
    lines.append(
        f"- **历史风险收益指标**：近1年夏普 `{prof.get('sharpe_1y')}` (近2年 `{prof.get('sharpe_2y')}` / 近3年 `{prof.get('sharpe_3y')}`) "
        f"| 近1年最大回撤 `{prof.get('max_drawdown_1y_pct')}%` | 近1年年化波动率 `{prof.get('volatility_1y_pct')}%`"
    )
    lines.append(
        f"- **跟踪指数**：**{idx_val.get('index_name')} ({idx_val.get('index_code')})**（估值日期：{idx_val.get('valuation_date')}，区间定位：{idx_val.get('valuation_status')}）"
    )
    lines.append(
        f"  - **PE(TTM)**：`{idx_val.get('pe_ttm')}`（历史分位数 **{idx_val.get('pe_percentile_pct')}%**） | **PB**：`{idx_val.get('pb')}`（历史分位数 **{idx_val.get('pb_percentile_pct')}%**）"
    )
    lines.append(
        f"  - **股息率**：`{idx_val.get('dividend_yield_pct')}%`"
        + (
            f"（较中债10Y `{idx_val.get('cn10y_yield_pct')}%` 溢价 `{idx_val.get('dividend_spread_vs_cn10y_pct'):+.2f}%`）"
            if idx_val.get("dividend_spread_vs_cn10y_pct") is not None
            else ""
        )
        + f" | **ROE**：`{idx_val.get('roe_pct')}%`"
        + (
            f" | **盈利收益率(E/P)**：`{idx_val.get('earnings_yield_ep_pct')}%`（股权风险溢价ERP `{idx_val.get('erp_vs_cn10y_pct'):+.2f}%`）"
            if idx_val.get("erp_vs_cn10y_pct") is not None
            else ""
        )
    )
    lines.append(
        f"  - **指数历史阶段涨跌**：近1周 `{idx_val.get('return_1w_pct')}%` / 近1月 `{idx_val.get('return_1m_pct')}%` / 近3月 `{idx_val.get('return_3m_pct')}%` / 近半年 `{idx_val.get('return_6m_pct')}%` / 近1年 `{idx_val.get('return_1y_pct')}%`"
    )
    if idx_val.get("profile"):
        lines.append(f"  - **指数简介**：{idx_val.get('profile')}")

    lines.append(f"\n### 二、{price_label}日K技术指标与历史价格分位数")
    lines.append(
        f"- **均线数值与偏离**：**{tech.get('ma_alignment')}** | MA5 `{tech.get('MA5')}` ({tech.get('close_vs_ma5_pct')}%) "
        f"| MA10 `{tech.get('MA10')}` ({tech.get('close_vs_ma10_pct')}%) | MA20 `{tech.get('MA20')}` ({tech.get('close_vs_ma20_pct')}%，5日斜率 `{tech.get('ma20_slope_5d_pct')}%`) "
        f"| MA60 `{tech.get('MA60')}` ({tech.get('close_vs_ma60_pct')}%，10日斜率 `{tech.get('ma60_slope_10d_pct')}%`) | MA120 `{tech.get('MA120')}` ({tech.get('close_vs_ma120_pct')}%) | MA250 `{tech.get('MA250')}` ({tech.get('close_vs_ma250_pct')}%)"
    )
    lines.append(
        f"- **阶段历史涨跌**：近3日 `{tech.get('return_3d_pct')}%` | 近5日 `{tech.get('return_5d_pct')}%` | 近10日 `{tech.get('return_10d_pct')}%` "
        f"| 近20日 `{tech.get('return_20d_pct')}%` | 近60日 `{tech.get('return_60d_pct')}%` | 近120日 `{tech.get('return_120d_pct')}%` | 近250日 `{tech.get('return_250d_pct')}%`"
    )
    macd_info = tech.get("macd") or {}
    lines.append(
        f"- **动量与波动指标**：RSI(14) `{tech.get('rsi14')}` | MACD `{macd_info.get('state')}` (DIF `{macd_info.get('dif')}`, DEA `{macd_info.get('dea')}`, Hist `{macd_info.get('histogram')}`) "
        f"| 20日ATR `{tech.get('atr20')}` ({tech.get('atr20_pct')}%) | 20日年化波动率 `{tech.get('annualized_volatility_20d_pct')}%` | 5日/20日均量比 `{tech.get('volume_5d_vs_20d_ratio')}`"
    )
    lines.append("")
    lines.append("| 周期窗口 | 最高价 | 最低价 | 区间位置 | 收盘价历史分位 | 距高点回撤 | 距低点反弹 |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|")
    for label, key in (("近1月(20日)", "range_20d"), ("近3月(60日)", "range_60d"), ("近半年(120日)", "range_120d"), ("近1年(250日)", "range_250d")):
        w = tech.get(key) or {}
        lines.append(
            f"| {label} | {w.get('high')} | {w.get('low')} | {w.get('position_pct')}% | **{w.get('close_percentile_pct')}%** | {w.get('drawdown_from_high_pct')}% | {w.get('rebound_from_low_pct')}% |"
        )
    lines.append("")
    lines.append(
        f"- **技术参考价位**：较低公式参考值 `{tech.get('key_supports')}` | 较高公式参考值 `{tech.get('key_resistances')}` | 经典枢轴点(Pivot) `{tech.get('pivot_levels')}`"
    )

    lines.append(f"\n### 三、{price_label}周K线中长期技术指标与历史价格分位数")
    if w_tech.get("available"):
        wb = w_tech.get("weekly_boll") or {}
        w_macd = w_tech.get("weekly_macd") or {}
        lines.append(
            f"- **周线均线与偏离**：**{w_tech.get('weekly_ma_alignment')}** | WMA5 `{w_tech.get('WMA5')}` ({w_tech.get('close_vs_wma5_pct')}%) "
            f"| WMA10 `{w_tech.get('WMA10')}` ({w_tech.get('close_vs_wma10_pct')}%) | WMA20 `{w_tech.get('WMA20')}` ({w_tech.get('close_vs_wma20_pct')}%，4周斜率 `{w_tech.get('wma20_slope_4w_pct')}%`) "
            f"| WMA30 `{w_tech.get('WMA30')}` ({w_tech.get('close_vs_wma30_pct')}%) | WMA60 `{w_tech.get('WMA60')}` ({w_tech.get('close_vs_wma60_pct')}%，8周斜率 `{w_tech.get('wma60_slope_8w_pct')}%`) | WMA120 `{w_tech.get('WMA120')}` ({w_tech.get('close_vs_wma120_pct')}%)"
        )
        lines.append(
            f"- **周线阶段涨跌**：近1周 `{w_tech.get('return_1w_pct')}%` | 近2周 `{w_tech.get('return_2w_pct')}%` | 近4周 `{w_tech.get('return_4w_pct')}%` "
            f"| 近13周 `{w_tech.get('return_13w_pct')}%` | 近26周 `{w_tech.get('return_26w_pct')}%` | 近52周 `{w_tech.get('return_52w_pct')}%` | 近104周 `{w_tech.get('return_104w_pct')}%`"
        )
        lines.append(
            f"- **周线布林带 BOLL(20,2) 与动量**：中轨 `{wb.get('mid_wma20')}` / 上轨 `{wb.get('upper')}` / 下轨 `{wb.get('lower')}`（布林位置 %B = `{wb.get('percent_b')}%`） "
            f"| 周RSI(14) `{w_tech.get('weekly_rsi14')}` | 周MACD `{w_macd.get('state')}` (DIF `{w_macd.get('dif')}`, DEA `{w_macd.get('dea')}`, Hist `{w_macd.get('histogram')}`) | 14周ATR `{w_tech.get('weekly_atr14')}` ({w_tech.get('weekly_atr14_pct')}%)"
        )
        lines.append("")
        lines.append("| 周线窗口 | 周最高价 | 周最低价 | 周区间中位价 | 距中位偏离 | 周区间位置 | 周收盘历史分位 | 距高点回撤 | 距低点反弹 |")
        lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
        for label, key in (
            ("近1季(13周)", "range_13w"),
            ("近半年(26周)", "range_26w"),
            ("近1年(52周)", "range_52w"),
            ("近2年(104周)", "range_104w"),
        ):
            ww = w_tech.get(key) or {}
            vs_m = f"{ww['vs_mid_pct']:+.2f}%" if ww.get("vs_mid_pct") is not None else "-"
            lines.append(
                f"| {label} | {ww.get('high')} | {ww.get('low')} | {ww.get('mid_price')} | {vs_m} | {ww.get('position_pct')}% | **{ww.get('close_percentile_pct')}%** | {ww.get('drawdown_from_high_pct')}% | {ww.get('rebound_from_low_pct')}% |"
            )
    else:
        lines.append("- 暂无周K线数据。")

    lines.append("\n### 四、前十大重仓成分股行情、基本面财务增速与两融资金")
    if comp.get("available"):
        f_sum = comp.get("fundamentals_summary") or {}
        m_sum = comp.get("margin_summary") or {}
        lines.append(
            f"- **持仓披露期**：{comp.get('report_date')} | **前十合计占净值比**：`{comp.get('total_weight_pct')}%` "
            f"| **今日涨跌分布**：`{comp.get('up_count')}涨 / {comp.get('down_count')}跌 / {comp.get('flat_count')}平` (上涨家数占比 `{comp.get('breadth_up_pct')}%`)"
        )
        lines.append(
            f"- **重仓股加权涨跌幅**：`{comp.get('weighted_change_pct')}%`（对ETF净值直接贡献估算 `{comp.get('estimated_top10_contribution_pct'):+.3f}%`） "
            f"| **高于MA20权重占比**：`{comp.get('above_ma20_weighted_breadth_pct')}%` | **高于MA60权重占比**：`{comp.get('above_ma60_weighted_breadth_pct')}%` | **行业权重分布**：`{comp.get('industry_distribution_pct')}`"
        )
        lines.append(
            f"- **重仓股基本面财务增速汇总**：加权营收同比 **`{f_sum.get('weighted_rev_yoy_pct')}%`** | 加权归母净利同比 **`{f_sum.get('weighted_profit_yoy_pct')}%`**（中位数 **`{f_sum.get('median_profit_yoy_pct')}%`**，正增长 `{f_sum.get('profit_positive_growth_count')}/{comp.get('count')}` 家） | 加权ROE **`{f_sum.get('weighted_roe_pct')}%`**"
        )
        if f_sum.get("latest_earnings_forecasts"):
            lines.append(
                f"  - **最新三季报/业绩预告速递**：{' ； '.join(f_sum['latest_earnings_forecasts'])}"
            )
        lines.append(
            f"- **重仓股两融资金汇总**：前十合计融资余额 `{m_sum.get('top10_total_fin_balance_yi')}亿` "
            f"| 合计1日融资净买 **`{m_sum.get('top10_fin_net_buy_1d_yi'):+.2f}亿`**（`{m_sum.get('top10_fin_inflow_1d_count')}/{comp.get('count')}` 家净流入） "
            f"| 合计5日融资净买 **`{m_sum.get('top10_fin_net_buy_5d_yi'):+.2f}亿`**（`{m_sum.get('top10_fin_inflow_5d_count')}/{comp.get('count')}` 家净流入） "
            f"| 合计10日融资净买 `{m_sum.get('top10_fin_net_buy_10d_yi'):+.2f}亿`"
        )
        lines.append("")
        lines.append(
            "| 代码 | 名称 | 权重 | 行业 | 最新价 | 今日涨跌 | 近20日 | 高于MA20 | PE(TTM)/PB | 营收同比 | 归母净利同比 | ROE | 最新业绩预告 | 融资余额(亿) | 1日/5日融资净买(亿) |"
        )
        lines.append("|---|---|---:|---|---:|---:|---:|---|---:|---:|---:|---:|---|---:|---:|")
        for c in comp.get("constituents", []):
            chg_s = f"{c['change_pct']:+.2f}%" if c.get("change_pct") is not None else "-"
            r20_s = f"{c['return_20d_pct']:+.2f}%" if c.get("return_20d_pct") is not None else "-"
            ma20_s = "是" if c.get("above_ma20") else ("否" if c.get("above_ma20") is False else "-")
            pe_s = f"{c['pe_ttm']:.1f}" if c.get("pe_ttm") is not None else "-"
            pb_s = f"{c['pb']:.2f}" if c.get("pb") is not None else "-"
            rev_s = f"{c['rev_yoy_pct']:+.1f}%" if c.get("rev_yoy_pct") is not None else "-"
            prf_s = f"{c['profit_yoy_pct']:+.1f}%" if c.get("profit_yoy_pct") is not None else "-"
            roe_s = f"{c['roe_pct']:.1f}%" if c.get("roe_pct") is not None else "-"
            pred_s = c.get("latest_earnings_forecast") or (c.get("report_period") or "-")
            fbal_s = f"{c['fin_balance_yi']:.2f}" if c.get("fin_balance_yi") is not None else "-"
            f1_s = f"{c['fin_net_buy_1d_yi']:+.2f}" if c.get("fin_net_buy_1d_yi") is not None else "-"
            f5_s = f"{c['fin_net_buy_5d_yi']:+.2f}" if c.get("fin_net_buy_5d_yi") is not None else "-"
            lines.append(
                f"| {c['symbol']} | {c['name']} | {c['weight_pct']}% | {c.get('industry') or '-'} | {c.get('current_price')} | {chg_s} | {r20_s} | {ma20_s} "
                f"| {pe_s}/{pb_s} | {rev_s} | {prf_s} | {roe_s} | {pred_s} | {fbal_s} | {f1_s} / {f5_s} |"
            )
    else:
        lines.append("- 暂无重仓股明细数据。")

    if not include_news:
        return "\n".join(lines)
    lines.append("\n### 五、东方财富相关新闻资讯候选（待核验背景材料）")
    lines.append(f"- **检索关键词**：`{', '.join(data.get('news_keywords') or [])}`")
    if news:
        for idx, n in enumerate(news[:12], 1):
            c_hit = f" [关联重仓股: {','.join(n['matched_constituents'])}]" if n.get("matched_constituents") else ""
            lines.append(
                f"{idx}. **[{n['time']}] {n['title']}**（来源：{n['source']}，匹配分：{n['relevance_score']}{c_hit}）  \n"
                f"   摘要：{n['summary'][:200]}... [原文链接]({n['url']})"
            )
    else:
        lines.append("- 最近检索窗口内无相关新闻。")

    return "\n".join(lines)
