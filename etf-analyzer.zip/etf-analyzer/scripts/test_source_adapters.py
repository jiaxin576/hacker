"""验证拆分后的数据源边界与跨源回退。"""
from types import SimpleNamespace
from unittest.mock import patch
import unittest
import market_data
import source_tencent


class SourceAdapterTests(unittest.TestCase):
    def test_daily_falls_back_to_tencent_without_changing_bar_identity(self):
        bar=SimpleNamespace(date='2026-10-16',close=1.0)
        with patch.object(market_data,'fetch_eastmoney_bars',return_value=[]) as east,patch.object(market_data,'fetch_tencent_bars',return_value=[bar]) as ten:
            self.assertIs(market_data.fetch_daily_bars('0.159338')[0],bar)
        self.assertEqual(east.call_args.kwargs['period'],'day')
        self.assertEqual(ten.call_args.kwargs['period'],'day')
    def test_no_adjusted_rows_is_not_silently_replaced_by_unadjusted(self):
        response=SimpleNamespace(raise_for_status=lambda:None,json=lambda:{'data':{'sz159338':{'day':[['2026-10-16',1,1,1,1,100]]}}})
        with patch.object(source_tencent,'_session',return_value=SimpleNamespace(get=lambda *a,**k:response)):
            self.assertEqual(source_tencent.fetch_tencent_bars('0.159338'),[])
    def test_both_providers_missing_is_explicit_failure(self):
        with patch.object(market_data,'fetch_eastmoney_bars',return_value=[]),patch.object(market_data,'fetch_tencent_bars',return_value=[]):
            with self.assertRaises(RuntimeError):market_data.fetch_daily_bars('0.159338')
            self.assertEqual(market_data.fetch_weekly_bars('0.159338'),[])


if __name__=='__main__':unittest.main()
