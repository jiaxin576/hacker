import json
from datetime import datetime,timedelta,timezone
import unittest
from urllib.parse import quote
from discover_douyin_home import parse_homepage


class HomeDiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.now=datetime(2026,10,18,16,tzinfo=timezone(timedelta(hours=8)))
        self.author='configured_author'
    def video(self,vid,days=1,author=None,pinned=False):
        return {'aweme_id':str(vid),'author':{'sec_uid':author or self.author,'nickname':'作者'},
                'create_time':int((self.now-timedelta(days=days)).timestamp()),'desc':'作品标题',
                'is_top':pinned,'video':{'play_addr':{'url_list':['https://video.douyinvod.com/media?x=%2F']}}}
    def parse(self,rows,**kwargs):
        html='<script id="RENDER_DATA">'+quote(json.dumps({'aweme_list':rows}))+'</script>'
        return parse_homepage(html,self.author,now=self.now,**kwargs)
    def test_newest_selected_from_homepage_not_pinned_old_or_another_author(self):
        rows=[self.video(12345678901234567,days=60,pinned=True),
              self.video(12345678901234568,days=2),self.video(12345678901234569,days=1),
              self.video(12345678901234570,days=0,author='other_creator')]
        found=self.parse(rows,limit=1)
        self.assertEqual(found['recent'][0]['video_id'],'12345678901234569')
        self.assertEqual(found['not_selected_count'],2)
        self.assertEqual(found['recent'][0]['media_urls'][0],'https://video.douyinvod.com/media?x=%2F')
    def test_links_without_author_or_time_cannot_claim_recent(self):
        result=parse_homepage('<a href="/video/12345678901234567">标题</a>',self.author,now=self.now)
        self.assertEqual(len(result['candidates']),1)
        self.assertEqual(result['recent'],[])
    def test_empty_or_challenge_page_is_not_no_update(self):
        for html in ['', '<script>function challenge(){return 1}</script>']:
            result=parse_homepage(html,self.author,now=self.now)
            self.assertFalse(result['page_has_post_metadata'])
            self.assertFalse(result['coverage_complete'])
    def test_future_date_excluded(self):
        self.assertEqual(self.parse([self.video(12345678901234567,days=-1)])['recent'],[])

    def test_latest_two_are_retained_even_when_older_than_seven_days(self):
        result=self.parse([self.video(12345678901234567,days=30),self.video(12345678901234568,days=15),
                           self.video(12345678901234569,days=60)])
        self.assertEqual([r['video_id'] for r in result['recent']],['12345678901234568','12345678901234567'])
        self.assertTrue(all(r['published_at'] for r in result['recent']))


if __name__=='__main__':unittest.main()
