"""日周线确定性统计，不访问网络。"""
from __future__ import annotations

import math
from statistics import mean, pstdev
from typing import Any, Iterable
from source_common import DailyBar, Quote, _pct_change, _round


def build_technical_summary(quote: Quote, bars: list[DailyBar]) -> dict[str, Any]:
    """计算全维度日线技术指标、均线排列、MACD/RSI/ATR、多窗口价格分位数与支撑压力位。"""
    closes = [float(b.close) for b in bars if b.close is not None]
    if not closes:
        return {}
    latest = bars[-1]
    current = quote.current_price or closes[-1]

    ma_periods = (5, 10, 20, 60, 120, 250)
    mas: dict[str, float | None] = {}
    vs_mas: dict[str, float | None] = {}
    for p in ma_periods:
        val = round(mean(closes[-p:]), 4) if len(closes) >= p else None
        mas[f"MA{p}"] = val
        vs_mas[f"close_vs_ma{p}_pct"] = _pct_change(current, val, digits=2)

    ma20_5d_ago = mean(closes[-25:-5]) if len(closes) >= 25 else None
    ma60_10d_ago = mean(closes[-70:-10]) if len(closes) >= 70 else None
    ma20_slope = _pct_change(mas["MA20"], ma20_5d_ago, digits=2)
    ma60_slope = _pct_change(mas["MA60"], ma60_10d_ago, digits=2)
    ma_alignment = _classify_ma_alignment(current, mas["MA5"], mas["MA10"], mas["MA20"], mas["MA60"])

    returns = {
        "latest_return_pct": quote.change_percent if quote.change_percent is not None else latest.change_percent,
        "return_3d_pct": _period_return(closes, 3),
        "return_5d_pct": _period_return(closes, 5),
        "return_10d_pct": _period_return(closes, 10),
        "return_20d_pct": _period_return(closes, 20),
        "return_60d_pct": _period_return(closes, 60),
        "return_120d_pct": _period_return(closes, 120),
        "return_250d_pct": _period_return(closes, 250),
    }

    windows = {
        "range_20d": _range_and_percentile(bars, closes, current, 20),
        "range_60d": _range_and_percentile(bars, closes, current, 60),
        "range_120d": _range_and_percentile(bars, closes, current, 120),
        "range_250d": _range_and_percentile(bars, closes, current, 250),
    }

    rsi14 = _rsi(closes, 14)
    macd_data = _macd(closes)
    atr20 = _atr(bars, 20)
    atr20_pct = round(atr20 / current * 100.0, 2) if atr20 is not None and current else None

    daily_rets = [
        (closes[i] / closes[i - 1] - 1.0) * 100.0
        for i in range(max(1, len(closes) - 20), len(closes))
        if closes[i - 1] > 0
    ]
    vol_20d = round(pstdev(daily_rets), 2) if len(daily_rets) >= 2 else None
    annual_vol_20d = round(vol_20d * math.sqrt(252), 2) if vol_20d is not None else None
    avg_amp_20d = _round(
        mean([b.amplitude_percent for b in bars[-20:] if b.amplitude_percent is not None])
        if any(b.amplitude_percent is not None for b in bars[-20:])
        else None,
        2,
    )

    vols = [float(b.volume) for b in bars if b.volume is not None]
    vol5 = mean(vols[-5:]) if len(vols) >= 5 else None
    vol20 = mean(vols[-20:]) if len(vols) >= 20 else None
    vol60 = mean(vols[-60:]) if len(vols) >= 60 else None
    latest_vol = float(latest.volume) if latest.volume is not None else None
    vol_5_vs_20 = round(vol5 / vol20, 2) if vol5 and vol20 else None
    vol_20_vs_60 = round(vol20 / vol60, 2) if vol20 and vol60 else None
    latest_vol_vs_20 = round(latest_vol / vol20, 2) if latest_vol and vol20 else None

    up_streak, down_streak = _streaks(closes)
    pivots = _pivot_levels(latest.high, latest.low, latest.close)
    support_levels = sorted(
        {
            round(v, 4)
            for v in (
                pivots.get("s1"),
                pivots.get("s2"),
                mas.get("MA20"),
                mas.get("MA60"),
                windows["range_20d"].get("low"),
                windows["range_60d"].get("low"),
            )
            if v is not None and v <= current * 1.005
        },
        reverse=True,
    )
    resistance_levels = sorted(
        {
            round(v, 4)
            for v in (
                pivots.get("r1"),
                pivots.get("r2"),
                mas.get("MA5"),
                mas.get("MA10"),
                mas.get("MA20"),
                mas.get("MA60"),
                windows["range_20d"].get("high"),
                windows["range_60d"].get("high"),
            )
            if v is not None and v >= current * 0.995
        }
    )

    return {
        "基准价": current,
        "日线区间": f"{bars[0].date} ~ {latest.date} (共{len(bars)}个交易日)",
        **mas,
        **vs_mas,
        "ma5": mas["MA5"],
        "ma10": mas["MA10"],
        "ma20": mas["MA20"],
        "ma60": mas["MA60"],
        "ma120": mas["MA120"],
        "ma250": mas["MA250"],
        "ma20_slope_5d_pct": ma20_slope,
        "ma60_slope_10d_pct": ma60_slope,
        "ma_alignment": ma_alignment,
        **returns,
        **windows,
        "rsi14": rsi14,
        "macd": macd_data,
        "atr20": _round(atr20, 4),
        "atr20_pct": atr20_pct,
        "avg_amplitude_20d_pct": avg_amp_20d,
        "realized_volatility_20d_pct": vol_20d,
        "annualized_volatility_20d_pct": annual_vol_20d,
        "up_streak_days": up_streak,
        "down_streak_days": down_streak,
        "volume_5d_vs_20d_ratio": vol_5_vs_20,
        "volume_20d_vs_60d_ratio": vol_20_vs_60,
        "latest_volume_vs_20d_ratio": latest_vol_vs_20,
        "pivot_levels": pivots,
        "key_supports": support_levels[:4],
        "key_resistances": resistance_levels[:4],
    }

def _period_return(values: list[float], periods: int) -> float | None:
    if len(values) <= periods or values[-periods - 1] == 0:
        return None
    return round((values[-1] / values[-periods - 1] - 1.0) * 100.0, 2)

def _range_and_percentile(
    bars: list[DailyBar], closes: list[float], current: float, lookback: int
) -> dict[str, Any]:
    w_bars = bars[-lookback:]
    w_closes = closes[-lookback:]
    highs = [b.high for b in w_bars if b.high is not None]
    lows = [b.low for b in w_bars if b.low is not None]
    high_v = max(highs) if highs else None
    low_v = min(lows) if lows else None
    pos_pct = (
        round((current - low_v) / (high_v - low_v) * 100.0, 1)
        if high_v is not None and low_v is not None and high_v > low_v
        else 50.0
    )
    pos_pct = max(0.0, min(100.0, pos_pct)) if pos_pct is not None else None
    pctile = (
        round(sum(1 for c in w_closes if c <= current) / len(w_closes) * 100.0, 1)
        if w_closes
        else None
    )
    return {
        "window_days": len(w_closes),
        "high": _round(high_v, 4),
        "low": _round(low_v, 4),
        "position_pct": pos_pct,
        "close_percentile_pct": pctile,
        "drawdown_from_high_pct": _pct_change(current, high_v, digits=2),
        "rebound_from_low_pct": _pct_change(current, low_v, digits=2),
    }

def _classify_ma_alignment(
    close: float | None,
    ma5: float | None,
    ma10: float | None,
    ma20: float | None,
    ma60: float | None,
) -> str:
    if any(x is None for x in (close, ma5, ma10, ma20)):
        return "均线数据不足"
    if ma60 is not None:
        if close >= ma5 >= ma10 >= ma20 >= ma60:
            return "收盘价≥MA5≥MA10≥MA20≥MA60"
        if close <= ma5 <= ma10 <= ma20 <= ma60:
            return "收盘价≤MA5≤MA10≤MA20≤MA60"
        if close < ma20 and ma20 >= ma60:
            return "收盘价<MA20且MA20≥MA60"
        if close >= ma20 and ma20 < ma60:
            return "收盘价≥MA20且MA20<MA60"
    if close >= ma5 >= ma10 >= ma20:
        return "收盘价≥MA5≥MA10≥MA20"
    if close <= ma5 <= ma10 <= ma20:
        return "收盘价≤MA5≤MA10≤MA20"
    return "均线未按上述次序排列"

def _ema_series(values: list[float], period: int) -> list[float | None]:
    if period <= 0 or len(values) < period:
        return [None] * len(values)
    alpha = 2.0 / (period + 1)
    result: list[float | None] = [None] * (period - 1)
    ema = mean(values[:period])
    result.append(ema)
    for v in values[period:]:
        ema = v * alpha + ema * (1.0 - alpha)
        result.append(ema)
    return result

def _macd(closes: list[float]) -> dict[str, Any]:
    ema12 = _ema_series(closes, 12)
    ema26 = _ema_series(closes, 26)
    dif = [f - s if f is not None and s is not None else None for f, s in zip(ema12, ema26)]
    valid_dif = [x for x in dif if x is not None]
    dea_valid = _ema_series(valid_dif, 9)
    it = iter(dea_valid)
    dea = [next(it) if x is not None else None for x in dif]
    hist = [(d - e) * 2.0 if d is not None and e is not None else None for d, e in zip(dif, dea)]
    d_now = dif[-1] if dif else None
    e_now = dea[-1] if dea else None
    h_now = hist[-1] if hist else None
    h_prev = hist[-2] if len(hist) >= 2 else None
    state = "未知"
    if d_now is not None and e_now is not None and h_now is not None:
        if d_now >= e_now:
            state = "DIF≥DEA，柱值较上期不减" if (h_prev is not None and h_now >= h_prev) else "DIF≥DEA，柱值较上期减小或上期缺失"
        else:
            state = "DIF<DEA，柱值较上期不增" if (h_prev is not None and h_now <= h_prev) else "DIF<DEA，柱值较上期增大或上期缺失"
    return {
        "dif": _round(d_now, 4),
        "dea": _round(e_now, 4),
        "histogram": _round(h_now, 4),
        "state": state,
    }

def _rsi(closes: list[float], period: int = 14) -> float | None:
    if len(closes) <= period:
        return None
    changes = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains = [max(c, 0.0) for c in changes]
    losses = [abs(min(c, 0.0)) for c in changes]
    avg_g = mean(gains[:period])
    avg_l = mean(losses[:period])
    for i in range(period, len(changes)):
        avg_g = (avg_g * (period - 1) + gains[i]) / period
        avg_l = (avg_l * (period - 1) + losses[i]) / period
    if avg_l == 0:
        return 100.0
    rs = avg_g / avg_l
    return round(100.0 - 100.0 / (1.0 + rs), 2)

def _atr(bars: list[DailyBar], period: int = 20) -> float | None:
    if len(bars) < 2:
        return None
    trs: list[float] = []
    for i in range(max(1, len(bars) - period), len(bars)):
        cur, prev = bars[i], bars[i - 1]
        if cur.high is None or cur.low is None:
            continue
        cands = [cur.high - cur.low]
        if prev.close is not None:
            cands.extend([abs(cur.high - prev.close), abs(cur.low - prev.close)])
        trs.append(max(cands))
    return mean(trs) if trs else None

def _streaks(closes: list[float]) -> tuple[int, int]:
    up = down = 0
    for i in range(len(closes) - 1, 0, -1):
        diff = closes[i] - closes[i - 1]
        if diff > 0:
            if down > 0:
                break
            up += 1
        elif diff < 0:
            if up > 0:
                break
            down += 1
        else:
            break
    return up, down

def _pivot_levels(high: float | None, low: float | None, close: float | None) -> dict[str, float | None]:
    if high is None or low is None or close is None or high < low:
        return {}
    p = (high + low + close) / 3.0
    return {
        "pivot": round(p, 4),
        "r1": round(2 * p - low, 4),
        "r2": round(p + (high - low), 4),
        "s1": round(2 * p - high, 4),
        "s2": round(p - (high - low), 4),
    }

def _weekly_range_and_percentile(
    bars: list[DailyBar], closes: list[float], current: float, lookback_weeks: int
) -> dict[str, Any]:
    w_bars = bars[-lookback_weeks:]
    w_closes = closes[-lookback_weeks:]
    highs = [b.high for b in w_bars if b.high is not None]
    lows = [b.low for b in w_bars if b.low is not None]
    high_v = max(highs) if highs else None
    low_v = min(lows) if lows else None
    mid_v = round((high_v + low_v) / 2.0, 4) if high_v is not None and low_v is not None else None
    pos_pct = (
        round((current - low_v) / (high_v - low_v) * 100.0, 1)
        if high_v is not None and low_v is not None and high_v > low_v
        else 50.0
    )
    pos_pct = max(0.0, min(100.0, pos_pct)) if pos_pct is not None else None
    pctile = (
        round(sum(1 for c in w_closes if c <= current) / len(w_closes) * 100.0, 1)
        if w_closes
        else None
    )
    return {
        "window_weeks": len(w_closes),
        "high": _round(high_v, 4),
        "low": _round(low_v, 4),
        "mid_price": mid_v,
        "vs_mid_pct": _pct_change(current, mid_v, digits=2),
        "below_mid": bool(current < mid_v) if mid_v is not None else None,
        "position_pct": pos_pct,
        "close_percentile_pct": pctile,
        "drawdown_from_high_pct": _pct_change(current, high_v, digits=2),
        "rebound_from_low_pct": _pct_change(current, low_v, digits=2),
    }

def build_weekly_technical_summary(quote: Quote, weekly_bars: list[DailyBar]) -> dict[str, Any]:
    """计算前复权周K线中长期技术指标、周布林带(BOLL20)与多周期周线价格分位数。"""
    closes = [float(b.close) for b in weekly_bars if b.close is not None]
    if not closes:
        return {"available": False}
    latest = weekly_bars[-1]
    current = quote.current_price or closes[-1]

    wma_periods = (5, 10, 20, 30, 60, 120)
    wmas: dict[str, float | None] = {}
    vs_wmas: dict[str, float | None] = {}
    for p in wma_periods:
        val = round(mean(closes[-p:]), 4) if len(closes) >= p else None
        wmas[f"WMA{p}"] = val
        vs_wmas[f"close_vs_wma{p}_pct"] = _pct_change(current, val, digits=2)

    wma20_4w_ago = mean(closes[-24:-4]) if len(closes) >= 24 else None
    wma60_8w_ago = mean(closes[-68:-8]) if len(closes) >= 68 else None
    wma20_slope = _pct_change(wmas["WMA20"], wma20_4w_ago, digits=2)
    wma60_slope = _pct_change(wmas["WMA60"], wma60_8w_ago, digits=2)
    w_alignment = _classify_ma_alignment(
        current, wmas["WMA5"], wmas["WMA10"], wmas["WMA20"], wmas["WMA60"]
    ).replace("20日线", "20周线")

    # 周线布林带 BOLL(20, 2)
    boll_mid = wmas["WMA20"]
    boll_std = pstdev(closes[-20:]) if len(closes) >= 20 else None
    boll_upper = round(boll_mid + 2.0 * boll_std, 4) if boll_mid is not None and boll_std is not None else None
    boll_lower = round(boll_mid - 2.0 * boll_std, 4) if boll_mid is not None and boll_std is not None else None
    boll_pct_b = (
        round((current - boll_lower) / (boll_upper - boll_lower) * 100.0, 1)
        if boll_upper is not None and boll_lower is not None and boll_upper > boll_lower
        else None
    )
    boll_bw_pct = (
        round((boll_upper - boll_lower) / boll_mid * 100.0, 2)
        if boll_upper is not None and boll_lower is not None and boll_mid
        else None
    )

    returns = {
        "return_1w_pct": latest.change_percent if latest.change_percent is not None else _period_return(closes, 1),
        "return_2w_pct": _period_return(closes, 2),
        "return_4w_pct": _period_return(closes, 4),
        "return_13w_pct": _period_return(closes, 13),
        "return_26w_pct": _period_return(closes, 26),
        "return_52w_pct": _period_return(closes, 52),
        "return_104w_pct": _period_return(closes, 104),
    }

    windows = {
        "range_13w": _weekly_range_and_percentile(weekly_bars, closes, current, 13),
        "range_26w": _weekly_range_and_percentile(weekly_bars, closes, current, 26),
        "range_52w": _weekly_range_and_percentile(weekly_bars, closes, current, 52),
        "range_104w": _weekly_range_and_percentile(weekly_bars, closes, current, 104),
    }

    w_rsi14 = _rsi(closes, 14)
    w_macd = _macd(closes)
    w_atr14 = _atr(weekly_bars, 14)
    w_atr14_pct = round(w_atr14 / current * 100.0, 2) if w_atr14 is not None and current else None
    up_w, down_w = _streaks(closes)

    return {
        "available": True,
        "基准价": current,
        "周线区间": f"{weekly_bars[0].date} ~ {latest.date} (共{len(weekly_bars)}周)",
        **wmas,
        **vs_wmas,
        "wma20_slope_4w_pct": wma20_slope,
        "wma60_slope_8w_pct": wma60_slope,
        "weekly_ma_alignment": w_alignment,
        "weekly_boll": {
            "mid_wma20": boll_mid,
            "upper": boll_upper,
            "lower": boll_lower,
            "percent_b": boll_pct_b,
            "bandwidth_pct": boll_bw_pct,
        },
        **returns,
        **windows,
        "weekly_rsi14": w_rsi14,
        "weekly_macd": w_macd,
        "weekly_atr14": _round(w_atr14, 4),
        "weekly_atr14_pct": w_atr14_pct,
        "up_streak_weeks": up_w,
        "down_streak_weeks": down_w,
    }
