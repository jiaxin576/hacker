"""腾讯财经：行情、日周K与海外市场。"""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable
from source_common import DailyBar, MARKET_REFERENCES, OVERSEAS_REFERENCES, Quote, REQUEST_TIMEOUT, TENCENT_KLINE_URL, TENCENT_QUOTE_URL, _num, _pct_change, _session


def fetch_tencent_quotes(codes: Iterable[str]) -> dict[str, Quote]:
    """批量请求腾讯行情接口 qt.gtimg.cn，支持 ETF、A股股票、指数、美股。"""
    code_list = [c for c in dict.fromkeys(codes) if c]
    if not code_list:
        return {}
    session = _session()
    result: dict[str, Quote] = {}
    for start in range(0, len(code_list), 45):
        batch = code_list[start : start + 45]
        url = TENCENT_QUOTE_URL + ",".join(batch)
        resp = session.get(url, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        text = resp.content.decode("gbk", errors="replace")
        for line in text.split(";"):
            line = line.strip()
            if "=" not in line:
                continue
            key, val = line.split("=", 1)
            t_code = key.strip().removeprefix("v_")
            parts = val.strip().strip('"').split("~")
            if len(parts) < 35 or not parts[1]:
                continue
            quote = _parse_tencent_quote_parts(t_code, parts)
            result[t_code] = quote
            result[quote.symbol] = quote
    return result

def _parse_tencent_quote_parts(t_code: str, parts: list[str]) -> Quote:
    def p(idx: int) -> str:
        return parts[idx].strip() if idx < len(parts) else ""

    is_us = t_code.startswith(("us", "hk"))
    symbol = p(2) or t_code.removeprefix("sh").removeprefix("sz").removeprefix("us").removeprefix("hk")
    name = p(1)
    market = 1 if t_code.startswith("sh") else 0
    secid = f"{market}.{symbol}" if not is_us else t_code

    current_price = _num(p(3))
    prev_close = _num(p(4))
    open_price = _num(p(5))
    volume = _num(p(6))
    outer_vol = _num(p(7))
    inner_vol = _num(p(8))

    bids: list[dict[str, float]] = []
    asks: list[dict[str, float]] = []
    if not is_us:
        for i in range(5):
            bp, bv = _num(p(9 + i * 2)), _num(p(10 + i * 2))
            if bp is not None and bp > 0 and bv is not None:
                bids.append({"price": bp, "volume": bv})
            ap, av = _num(p(19 + i * 2)), _num(p(20 + i * 2))
            if ap is not None and ap > 0 and av is not None:
                asks.append({"price": ap, "volume": av})

    raw_time = p(30)
    if re.fullmatch(r"\d{14}", raw_time):
        quote_time = (
            f"{raw_time[:4]}-{raw_time[4:6]}-{raw_time[6:8]} "
            f"{raw_time[8:10]}:{raw_time[10:12]}:{raw_time[12:14]}"
        )
    else:
        quote_time = raw_time or None

    change_amount = _num(p(31))
    change_percent = _num(p(32))
    high_price = _num(p(33))
    low_price = _num(p(34))

    amount: float | None = None
    p35 = p(35)
    if "/" in p35:
        seg = p35.split("/")
        if len(seg) >= 3:
            amount = _num(seg[2])
    if amount is None:
        amt_wan = _num(p(57)) if not is_us else None
        if amt_wan is None:
            amt_wan = _num(p(37))
        if amt_wan is not None:
            amount = amt_wan * 10000.0 if not is_us else amt_wan

    turnover_rate = _num(p(38))
    pe_ttm = _num(p(39)) if not is_us else None
    amplitude_percent = _num(p(43))
    float_mv_yi = _num(p(44))
    total_mv_yi = _num(p(45))
    pb = _num(p(46)) if not is_us else None
    float_mv = float_mv_yi * 1e8 if float_mv_yi is not None and not is_us else None
    total_mv = total_mv_yi * 1e8 if total_mv_yi is not None and not is_us else None

    upper_limit = _num(p(47)) if not is_us else None
    lower_limit = _num(p(48)) if not is_us else None
    volume_ratio = _num(p(49)) if not is_us else None
    avg_price = _num(p(51)) if not is_us else None
    pe_dynamic = _num(p(52)) if not is_us else None
    high_52w = _num(p(67)) if not is_us else _num(p(48))
    low_52w = _num(p(68)) if not is_us else _num(p(49))
    total_shares = _num(p(72)) if not is_us else None
    premium_pct = _num(p(77)) if not is_us else None
    iopv = _num(p(78)) if not is_us else None
    nav = _num(p(81)) if not is_us else None

    if iopv is not None and current_price is not None and premium_pct is None and iopv > 0:
        premium_pct = _pct_change(current_price, iopv, digits=3)

    active_buy_ratio = None
    if outer_vol is not None and inner_vol is not None and (outer_vol + inner_vol) > 0:
        active_buy_ratio = round(outer_vol / (outer_vol + inner_vol), 4)

    bid1_price = bids[0]["price"] if bids else None
    bid1_vol = bids[0]["volume"] if bids else None
    ask1_price = asks[0]["price"] if asks else None
    ask1_vol = asks[0]["volume"] if asks else None
    spread_pct = None
    if bid1_price and ask1_price and bid1_price > 0:
        spread_pct = round((ask1_price - bid1_price) / ((ask1_price + bid1_price) / 2) * 100, 4)

    depth_imbalance = None
    bid_sum = sum(x["volume"] for x in bids)
    ask_sum = sum(x["volume"] for x in asks)
    if (bid_sum + ask_sum) > 0:
        depth_imbalance = round((bid_sum - ask_sum) / (bid_sum + ask_sum), 4)

    return Quote(
        symbol=symbol,
        name=name,
        market=market,
        secid=secid,
        collected_at=datetime.now().isoformat(timespec="seconds"),
        quote_time=quote_time,
        current_price=current_price,
        change_amount=change_amount,
        change_percent=change_percent,
        avg_price=avg_price,
        volume=volume,
        amount=amount,
        volume_ratio=volume_ratio,
        high_price=high_price,
        low_price=low_price,
        open_price=open_price,
        prev_close=prev_close,
        turnover_rate=turnover_rate,
        amplitude_percent=amplitude_percent,
        upper_limit=upper_limit,
        lower_limit=lower_limit,
        high_52w=high_52w,
        low_52w=low_52w,
        iopv=iopv,
        nav=nav,
        premium_pct=premium_pct,
        total_market_value=total_mv,
        float_market_value=float_mv,
        total_shares=total_shares,
        outer_volume=outer_vol,
        inner_volume=inner_vol,
        active_buy_ratio=active_buy_ratio,
        bid1_price=bid1_price,
        ask1_price=ask1_price,
        bid1_volume=bid1_vol,
        ask1_volume=ask1_vol,
        spread_pct=spread_pct,
        depth_imbalance=depth_imbalance,
        bids=bids,
        asks=asks,
        pe_ttm=pe_ttm,
        pe_dynamic=pe_dynamic,
        pb=pb,
        source="Tencent realtime",
    )

def _parse_tencent_daily_rows(rows: Iterable[Any]) -> list[DailyBar]:
    result: list[DailyBar] = []
    previous_close: float | None = None
    for row in rows:
        if not isinstance(row, list) or len(row) < 6:
            continue
        open_p, close_p, high_p, low_p, vol = (_num(v) for v in row[1:6])
        change = round(close_p - previous_close, 4) if close_p is not None and previous_close is not None else None
        change_pct = _pct_change(close_p, previous_close, digits=2) if previous_close else None
        amplitude = (
            round((high_p - low_p) / previous_close * 100.0, 2)
            if high_p is not None and low_p is not None and previous_close not in (None, 0)
            else None
        )
        avg_p = (open_p + close_p + high_p + low_p) / 4.0 if all(x is not None for x in (open_p, close_p, high_p, low_p)) else close_p
        est_amount = round(vol * 100.0 * avg_p, 2) if vol is not None and avg_p is not None else None
        result.append(
            DailyBar(
                date=str(row[0]),
                open=open_p,
                close=close_p,
                high=high_p,
                low=low_p,
                volume=vol,
                amount=est_amount,
                amplitude_percent=amplitude,
                change_percent=change_pct,
                change_amount=change,
                turnover_rate=None,
            )
        )
        if close_p is not None:
            previous_close = close_p
    return result

def fetch_market_and_overseas_context() -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    """一次批量获取 A 股核心风格基准与海外隔夜市场行情。"""
    a_codes = [tc for _, tc in MARKET_REFERENCES.values()]
    us_codes = [tc for tc, _ in OVERSEAS_REFERENCES.values()]
    quotes = fetch_tencent_quotes(a_codes + us_codes)

    market_ctx: list[dict[str, Any]] = []
    for name, (secid, tc) in MARKET_REFERENCES.items():
        q = quotes.get(tc)
        if q:
            market_ctx.append(
                {
                    "名称": name,
                    "代码": q.symbol,
                    "最新价": q.current_price,
                    "涨跌幅_pct": q.change_percent,
                    "成交额_亿": round(q.amount / 1e8, 2) if q.amount else None,
                    "振幅_pct": q.amplitude_percent,
                }
            )

    overseas_ctx: dict[str, dict[str, Any]] = {}
    for key, (tc, name) in OVERSEAS_REFERENCES.items():
        q = quotes.get(tc)
        if q:
            overseas_ctx[key] = {
                "name": name,
                "symbol": q.symbol,
                "price": q.current_price,
                "change_percent": q.change_percent,
                "quote_time": q.quote_time,
                "high_52w": q.high_52w,
                "low_52w": q.low_52w,
            }
    return market_ctx, overseas_ctx

def fetch_tencent_bars(secid: str, *, period: str = "day", limit: int = 260) -> list[DailyBar]:
    market, symbol = secid.split('.', 1)
    code = ('sh' if market == '1' else 'sz') + symbol
    response = _session().get(TENCENT_KLINE_URL, params={'param': f'{code},{period},,,{limit},qfq'}, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    node = ((response.json().get('data') or {}).get(code)) or {}
    return _parse_tencent_daily_rows(node.get('qfqweek' if period == 'week' else 'qfqday') or [])


def fetch_stock_daily_rows(code: str, limit: int = 65) -> list:
    response = _session().get(TENCENT_KLINE_URL, params={'param': f'{code},day,,,{limit},qfq'}, timeout=6)
    response.raise_for_status()
    node = ((response.json().get('data') or {}).get(code)) or {}
    return node.get('qfqday') or node.get('day') or []



if __name__ == '__main__':
    from source_debug import run_source_cli
    from source_common import symbol_to_secid
    run_source_cli('腾讯财经', {
        'quotes': lambda a: fetch_tencent_quotes([symbol_to_secid(a.symbol)[1]]),
        'daily': lambda a: fetch_tencent_bars(symbol_to_secid(a.symbol)[0], limit=a.limit),
        'weekly': lambda a: fetch_tencent_bars(symbol_to_secid(a.symbol)[0], period='week', limit=a.limit),
        'overseas': lambda a: fetch_market_and_overseas_context()})
