"""仅在用户授权后复用本地雪球Cookie；不导出明文、不触碰其他站点登录态。"""
from contextlib import contextmanager, closing
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import tempfile


class LocalSessionUnavailable(RuntimeError):
    """面向用户的无敏感信息错误，禁止把Playwright原始调用日志写入报告。"""


@contextmanager
def loopback_transport():
    """本地调试连接不经过外部代理；不修改外部网站的代理或系统设置。"""
    original=os.environ.get('NO_PROXY')
    os.environ['NO_PROXY']=(original or '')+',127.0.0.1,localhost'
    try: yield
    finally:
        if original is None: os.environ.pop('NO_PROXY',None)
        else: os.environ['NO_PROXY']=original


@contextmanager
def live_browser_context(browser='chrome'):
    """只复用现有、用户授权的浏览器连接；结束时不关闭用户浏览器。"""
    from playwright.sync_api import sync_playwright,TimeoutError as PlaywrightTimeoutError
    endpoint=existing_debug_endpoint(browser)
    if not endpoint: raise LocalSessionUnavailable('未发现浏览器已发布的本地调试连接')
    with loopback_transport(),sync_playwright() as playwright:
        instance=None;connection_errors=[]
        for attempt in range(2):
            try:
                instance=playwright.chromium.connect_over_cdp(endpoint,timeout=15000)
                break
            except PlaywrightTimeoutError:
                connection_errors.append('TimeoutError')
        if instance is None: raise LocalSessionUnavailable('现有浏览器调试连接连续两次超时，已停止重试')
        for context in instance.contexts:
            cookies=context.cookies(['https://www.xueqiu.com/','https://xueqiu.com/'])
            if cookies:
                yield context,{'方式':f'Playwright现有{browser}页面','雪球Cookie数':len(cookies),'Cookie明文导出':False,
                               '连接尝试次数':len(connection_errors)+1,'先前连接错误类型':connection_errors}
                return
        raise LocalSessionUnavailable('现有浏览器未找到雪球登录态')


def configured_auth_mode():
    """仅在本机配置已有明确授权时采用已选浏览器；不把普通采集请求当Cookie授权。"""
    path=Path(__file__).resolve().parents[1]/'data/source_registry.json'
    try:
        registry=json.loads(path.read_text(encoding='utf-8-sig'))
        for source in registry.get('sources',[]):
            session=source.get('local_session') or {}
            if source.get('id')=='xueqiu' and session.get('enabled') is True and session.get('authorization') and session.get('scope')==['xueqiu.com']:
                browser=session.get('preferred_browser')
                if browser in ('chrome','edge'): return browser
    except (OSError,ValueError): pass
    return 'public'


def scoped_cookies(data):
    """兼容专用cookie_str缓存和Playwright storage_state，只使用雪球域。"""
    if isinstance(data,dict) and data.get('cookie_str'):
        return [{'name':part.split('=',1)[0].strip(),'value':part.split('=',1)[1],
                 'domain':'.xueqiu.com','path':'/','expires':-1,'httpOnly':True,'secure':True,'sameSite':'Lax'}
                for part in data['cookie_str'].split(';') if '=' in part and part.split('=',1)[0].strip()]
    rows = data.get('cookies',[]) if isinstance(data,dict) else data
    cookies=[]
    for row in rows if isinstance(rows,list) else []:
        domain = str(row.get('domain') or '').lower().lstrip('.')
        if domain != 'xueqiu.com' and not domain.endswith('.xueqiu.com'): continue
        if not row.get('name') or not isinstance(row.get('value'),str): continue
        cookie={'path':'/','expires':-1,'httpOnly':False,'secure':True,'sameSite':'Lax'}
        cookie.update({k:v for k,v in row.items() if k in
                       ('name','value','domain','path','expires','httpOnly','secure','sameSite')})
        cookies.append(cookie)
    return cookies


def browser_profile(browser, profile='Default'):
    if browser not in ('chrome','edge'): raise LocalSessionUnavailable('只支持Chrome或Edge本地登录态')
    if profile != 'Default' and not (profile.startswith('Profile ') and profile[8:].isdigit()):
        raise LocalSessionUnavailable('配置目录须为Default或Profile 数字，禁止任意路径')
    base = Path(os.environ['LOCALAPPDATA'])/('Google/Chrome/User Data' if browser=='chrome' else 'Microsoft/Edge/User Data')
    return base,base/profile


def existing_debug_endpoint(browser='chrome'):
    """只读本地浏览器自己发布的调试地址，不扫描端口或修改启动配置。"""
    base,_=browser_profile(browser)
    try: lines=(base/'DevToolsActivePort').read_text(encoding='utf-8').splitlines()
    except OSError: return None
    if len(lines)<2 or not lines[0].isdigit() or not 1<=int(lines[0])<=65535: return None
    if not re.fullmatch(r'/devtools/browser/[A-Za-z0-9-]+',lines[1]): return None
    return 'ws://127.0.0.1:'+lines[0]+lines[1]


def clone_cookie_profile(browser, profile, target):
    """复制Cookie及密钥元信息供官方浏览器正常读取；原浏览器需已退出。"""
    base,source=browser_profile(browser,profile)
    cookie=source/'Network/Cookies'
    if not cookie.is_file() or not (base/'Local State').is_file():
        raise LocalSessionUnavailable('未找到所选浏览器配置的Cookie库')
    # 不解锁、不终止浏览器、不提权。独占锁定时立即要求正常退出。
    try:
        with closing(sqlite3.connect(cookie.as_uri()+'?mode=ro',uri=True,timeout=1)) as src:
            src.execute("SELECT name FROM cookies WHERE host_key='xueqiu.com' OR host_key LIKE '%.xueqiu.com' LIMIT 1").fetchone()
            dest=target/'Default/Network/Cookies';dest.parent.mkdir(parents=True,exist_ok=True)
            with closing(sqlite3.connect(dest)) as db:
                src.backup(db)
        with closing(sqlite3.connect(dest)) as db:
            db.execute("DELETE FROM cookies WHERE NOT (host_key='xueqiu.com' OR host_key LIKE '%.xueqiu.com')")
            db.commit();db.execute('VACUUM')
        shutil.copyfile(base/'Local State',target/'Local State')
    except (PermissionError,sqlite3.OperationalError):
        raise LocalSessionUnavailable('Cookie库被浏览器占用；请保存工作并正常退出所选浏览器后重试') from None


@contextmanager
def local_request_session(mode='cache', cookie_file=None, profile='Default'):
    """yield (Playwright请求上下文, 不含Cookie的元数据)，结束后清理临时配置。"""
    from playwright.sync_api import sync_playwright
    from source_common import XUEQIU_COOKIE_CACHE
    if mode not in ('cache','chrome','edge'): raise LocalSessionUnavailable('本地登录态模式无效')
    with loopback_transport(),sync_playwright() as playwright:
        if mode=='cache':
            try:
                data=json.loads(Path(cookie_file or XUEQIU_COOKIE_CACHE).read_text(encoding='utf-8-sig'))
            except (OSError,ValueError): raise LocalSessionUnavailable('无法读取雪球专用Cookie或storage_state文件') from None
            cookies=scoped_cookies(data)
            if not cookies: raise LocalSessionUnavailable('文件中没有雪球域Cookie')
            context=playwright.request.new_context(storage_state={'cookies':cookies,'origins':[]},
                user_agent='Mozilla/5.0',extra_http_headers={'Referer':'https://xueqiu.com/'})
            try: yield context,{'方式':'Playwright复用雪球专用本地缓存','雪球Cookie数':len(cookies)}
            finally: context.dispose()
        else:
            # 优先复用已有调试连接，避免数据库独占锁；只断开自己的连接，不能关闭用户Chrome。
            live_context=None;live_browser=None;live_count=0
            endpoint=existing_debug_endpoint(mode) if profile=='Default' else None
            if endpoint:
                try:
                    live_browser=playwright.chromium.connect_over_cdp(endpoint,timeout=30000)
                    for candidate in live_browser.contexts:
                        count=len(candidate.cookies(['https://xueqiu.com/','https://www.xueqiu.com/']))
                        if count:
                            live_context,live_count=candidate,count
                            break
                except Exception:
                    pass  # 原始连接日志可能包含调试会话地址，不写入报告。
            if live_context is not None:
                yield live_context.request,{'方式':f'Playwright复用现有{mode}连接','配置':profile,'雪球Cookie数':live_count}
                return  # sync_playwright停止时断开连接，不调用用户browser.close()。
            # 临时目录位于系统Temp，递归清理前验证目标范围。未复制历史、密码库或站点存储。
            temporary=tempfile.TemporaryDirectory(prefix='etf-xueqiu-')
            target=Path(temporary.name).resolve()
            safe_parent=Path(tempfile.gettempdir()).resolve()
            if target.parent != safe_parent or not target.name.startswith('etf-xueqiu-'):
                raise LocalSessionUnavailable('临时配置目录校验失败')
            browser_context=None
            try:
                clone_cookie_profile(mode,profile,target)
                browser_context=playwright.chromium.launch_persistent_context(str(target),
                    channel='chrome' if mode=='chrome' else 'msedge',headless=True,
                    args=['--profile-directory=Default','--no-first-run','--no-default-browser-check'])
                cookies=browser_context.cookies(['https://xueqiu.com/','https://www.xueqiu.com/'])
                if not cookies: raise LocalSessionUnavailable('浏览器未能读取有效雪球Cookie；可能没有登录或会话已过期')
                yield browser_context.request,{'方式':f'Playwright复用{mode}雪球登录态','配置':profile,'雪球Cookie数':len(cookies)}
            finally:
                try:
                    if browser_context is not None: browser_context.close()
                finally:
                    if target.parent == safe_parent and target.name.startswith('etf-xueqiu-'):
                        temporary.cleanup()
