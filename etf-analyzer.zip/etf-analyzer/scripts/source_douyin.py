"""从已配置作者主页发现近期作品；页面受限时明确失败，不回退到固定视频。"""
from __future__ import annotations
import argparse
from datetime import datetime,timedelta,timezone
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
from urllib.parse import unquote,urlparse
import requests

ROOT=Path(__file__).resolve().parents[1]
TZ=timezone(timedelta(hours=8))


class Page(HTMLParser):
    def __init__(self):
        super().__init__();self.scripts=[];self.links=[];self.inside=False;self.parts=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag=='script':self.inside=True;self.parts=[]
        if tag=='a' and attrs.get('href'):self.links.append(attrs['href'])
    def handle_data(self,data):
        if self.inside:self.parts.append(data)
    def handle_endtag(self,tag):
        if tag=='script' and self.inside:
            self.scripts.append(''.join(self.parts));self.inside=False


def _published(value):
    try:
        if isinstance(value,(int,float)) or str(value).isdigit():
            value=float(value)
            return datetime.fromtimestamp(value/1000 if value>1e11 else value,TZ)
        dt=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        return dt.astimezone(TZ) if dt.tzinfo else None
    except (TypeError,ValueError,OSError,OverflowError):return None


def parse_homepage(html,author_id,*,now=None,days=None,limit=2):
    """解析主页公开JSON与作品链接；不执行页面脚本或调用签名接口。"""
    now=now or datetime.now(TZ)
    if now.tzinfo is None:raise ValueError('采集时间必须带时区')
    parser=Page();parser.feed(html);found={};decoder=json.JSONDecoder()
    def walk(node):
        if isinstance(node,list):
            for item in node:walk(item)
        elif isinstance(node,dict):
            vid=str(node.get('aweme_id') or node.get('awemeId') or '')
            if not vid and node.get('video') and ('desc' in node or 'description' in node):
                vid=str(node.get('id') or '')
            if re.fullmatch(r'\d{15,25}',vid):
                author=node.get('author') or node.get('authorInfo') or {}
                owner=author.get('sec_uid') or author.get('secUid') or ''
                pub=_published(node.get('create_time') or node.get('createTime'))
                video=node.get('video') or {};addresses=[]
                for address in [video.get('play_addr'),video.get('playAddr')]:
                    if isinstance(address,dict):addresses.extend(address.get('url_list') or address.get('urlList') or [])
                    elif isinstance(address,str):addresses.append(address)
                row={'video_id':vid,'author_id':owner or None,
                    'author':author.get('nickname') or author.get('nickName'),
                    'title':node.get('desc') or node.get('description') or node.get('title') or '',
                    'url':f'https://www.douyin.com/video/{vid}',
                    'published_at':pub.isoformat() if pub else None,
                    'author_verified':owner==author_id,
                    'is_pinned':bool(node.get('is_top') or node.get('isTop')),
                    'media_urls':[u for u in addresses if isinstance(u,str) and urlparse(u).scheme=='https']}
                if vid not in found or row['author_verified']:found[vid]=row
            for child in node.values():
                if isinstance(child,(dict,list)):walk(child)
    for script in parser.scripts:
        text=script.strip()
        if text.lower().startswith(('%7b','%5b')):text=unquote(text)
        try:walk(json.loads(text));continue
        except (ValueError,TypeError):pass
        # Accept a literal JSON assignment; never evaluate JavaScript/challenges.
        match=re.search(r'(?:window\.)?[A-Za-z_$][\w$]*\s*=\s*([\[{])',text)
        if match:
            try:walk(decoder.raw_decode(text[match.start(1):])[0])
            except ValueError:pass
    for url in parser.links:
        match=re.search(r'(?:^|douyin\.com)/video/(\d{15,25})(?:[/?#]|$)',url)
        if match:
            vid=match.group(1)
            found.setdefault(vid,{'video_id':vid,'url':f'https://www.douyin.com/video/{vid}',
                'title':'','author_id':None,'author_verified':False,'published_at':None,'media_urls':[]})
    eligible=[r for r in found.values() if r['author_verified'] and r['published_at']
              and datetime.fromisoformat(r['published_at'])<=now
              and (days is None or now-timedelta(days=days)<=datetime.fromisoformat(r['published_at']))]
    eligible.sort(key=lambda r:datetime.fromisoformat(r['published_at']),reverse=True)
    return {'candidates':list(found.values()),'recent':eligible[:limit],
            'not_selected_count':max(0,len(eligible)-limit),
            'page_has_post_metadata':bool(found),'coverage_complete':False}


def fetch_homepage(source,session=None):
    session=session or requests.Session()
    urls=list(dict.fromkeys([source['url'],source.get('canonical_url') or source['url']]))
    attempts=[];html=''
    for url in urls:
        parsed=urlparse(url)
        if parsed.scheme!='https' or parsed.hostname not in ('www.douyin.com','douyin.com') or not parsed.path.rstrip('/').endswith('/'+source['id']):
            raise ValueError('主页链接与已配置抖音作者不一致')
        try:
            response=session.get(url,timeout=18,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36','Accept-Language':'zh-CN,zh;q=0.9'})
            attempts.append({'主页':url,'HTTP状态':response.status_code,'响应字节数':len(response.content)})
            if response.status_code in (401,403,429):break
            response.raise_for_status();html=response.text
            if html.strip():break
        except requests.RequestException as exc:attempts.append({'主页':url,'原因':type(exc).__name__})
    return html,attempts,session


def acquire(row,folder,session,*,asr_python=None,model='medium'):
    """仅下载主页元数据实际给出的播放资源；不拿背景音乐充当讲话音轨。"""
    if not row['media_urls']:raise RuntimeError('主页未提供可下载的播放资源，需正常浏览器打开作品后获取')
    host=urlparse(row['media_urls'][0]).hostname or ''
    allowed=('douyinvod.com','bytecdn.cn','byteimg.com','bytedance.com','douyin.com')
    if not any(host==domain or host.endswith('.'+domain) for domain in allowed):
        raise RuntimeError('播放资源域名不在抖音媒体来源范围，需核验原页面')
    if not shutil.which('ffmpeg'):raise RuntimeError('未找到ffmpeg')
    folder.mkdir(parents=True,exist_ok=True);media=folder/'video.mp4'
    with session.get(row['media_urls'][0],stream=True,timeout=(10,30)) as response:
        response.raise_for_status()
        if 'text/' in response.headers.get('Content-Type',''):raise RuntimeError('媒体请求返回网页或验证提示')
        size=0
        with media.open('wb') as out:
            for chunk in response.iter_content(1024*1024):
                size+=len(chunk)
                if size>300*1024*1024:raise RuntimeError('媒体超过本次300MB下载上限')
                out.write(chunk)
    audio=folder/'audio.m4a'
    subprocess.run([shutil.which('ffmpeg'),'-v','error','-y','-i',str(media),'-vn','-c:a','aac',str(audio)],check=True,timeout=120)
    metadata={k:row[k] for k in ('video_id','author_id','author','title','url','published_at')}
    (folder/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    if asr_python:
        subprocess.run([asr_python,str(ROOT/'scripts/transcribe_media.py'),'--media',str(audio),
            '--metadata',str(folder/'metadata.json'),'--output-dir',str(folder),'--model',model],check=True)
    return '已转写' if asr_python else '已下载并提取音轨'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=ROOT/'data/kol_sources.json')
    parser.add_argument('--output-dir',type=Path,required=True)
    parser.add_argument('--homepage-html',type=Path,help='已取得的同一主页HTML；仅离线解析，不冒充在线检查')
    parser.add_argument('--days',type=int,default=None,help='可选日期窗口；默认按真实发布时间取最新作品，不限7天')
    parser.add_argument('--limit',type=int,default=None,help='默认读取作者配置，本作者为最新2条')
    parser.add_argument('--download',action='store_true');parser.add_argument('--transcribe',action='store_true')
    parser.add_argument('--asr-python',default=sys.executable);parser.add_argument('--model',default='medium')
    args=parser.parse_args()
    if (args.days is not None and args.days<=0) or (args.limit is not None and args.limit<=0):parser.error('天数和作品数必须大于0')
    source=next(s for s in json.loads(args.config.read_text(encoding='utf-8-sig')) if s.get('platform')=='douyin' and s.get('enabled',True))
    limit=args.limit if args.limit is not None else int(source.get('max_articles',2))
    args.output_dir.mkdir(parents=True,exist_ok=True)
    if args.homepage_html:html=args.homepage_html.read_text(encoding='utf-8');attempts=[];session=requests.Session()
    else:html,attempts,session=fetch_homepage(source)
    (args.output_dir/'主页响应.html').write_text(html,encoding='utf-8')
    parsed=parse_homepage(html,source['id'],days=args.days,limit=limit)
    results=[]
    for row in parsed['recent']:
        result={k:v for k,v in row.items() if k!='media_urls'}
        result['采集状态']='已发现作品，尚未下载'
        if args.download or args.transcribe:
            try:result['采集状态']=acquire(row,args.output_dir/row['video_id'],session,asr_python=args.asr_python if args.transcribe else None,model=args.model)
            except (requests.RequestException,RuntimeError,subprocess.SubprocessError) as exc:
                result.update(采集状态='采集失败',原因=str(exc))
        results.append(result)
    status='部分取得' if results else '访问受限或元数据不足'
    manifest={'作者':source['name'],'作者编号':source['id'],'主页':source['url'],
        '检查时间':datetime.now(TZ).isoformat(),'是否本次联网':not bool(args.homepage_html),
        '采集状态':status,'主页访问记录':attempts,'日期窗口天数':args.days,'目标作品数':limit,
        '作品清单':results,'未选择的近期作品数':parsed['not_selected_count'],
        '候选作品':[ {k:v for k,v in r.items() if k!='media_urls'} for r in parsed['candidates']],
        '说明':'仅第一页已取得的作品；未证明覆盖全部更新。' if results else
               '没有取得可核验作者及发布时间的近期作品；不代表作者无更新。遇到验证或登录限制需正常浏览器检查，禁止替换成固定视频。'}
    path=args.output_dir/'主页作品采集清单.json'
    path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'采集状态':status,'近期作品数':len(results),'清单文件':str(path.resolve()),'说明':manifest['说明']},ensure_ascii=False,indent=2))
    if not results:raise SystemExit(2)




import json
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable
from source_common import SKILL_DIR



def load_douyin_transcripts(source: dict[str, Any]) -> dict[str, Any]:
    """Load genuine audio transcripts; preserve publication age separately from collection time."""
    author_id = str(source["id"])
    result = {
        "id": author_id, "name": source.get("name"), "platform": "douyin",
        "style": source.get("style", ""), "profile_url": source.get("url"),
        "collection_mode": source.get('collection_mode','homepage_recent_audio_asr'), "article_count": 0, "articles": [],
        "live_checked": False, "usable_for_current_analysis": False,
    }
    if not re.fullmatch(r"[A-Za-z0-9_-]{6,160}", author_id):
        return {**result, "error": "抖音作者ID格式无效"}
    directory = SKILL_DIR / "data" / "kol_transcripts" / "douyin" / author_id
    now = datetime.now(timezone(timedelta(hours=8)))
    max_age = float(source.get("max_age_hours", 72))
    articles = []
    errors = []
    for path in directory.glob("*.json"):
        try:
            article = json.loads(path.read_text(encoding="utf-8"))
            if (article.get("author_id") != author_id
                    or article.get("platform") != "douyin"
                    or article.get("content_type") != "audio_transcript"
                    or article.get("status") != "transcribed"
                    or not str(article.get("content") or "").strip()
                    or not article.get("segments")):
                raise ValueError("非该作者的有效音频转写")
            published = datetime.fromisoformat(article["published_at"])
            if published.tzinfo is None or published > now:
                raise ValueError("发布时间缺少时区或晚于当前时间")
            age_hours = (now - published).total_seconds() / 3600
            article["age_hours"] = round(age_hours, 1)
            article["freshness"] = "recent" if age_hours <= max_age else "historical"
            article["usable_for_current_analysis"] = age_hours <= max_age
            articles.append(article)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            errors.append({"file": path.name, "error": str(exc)})
    articles.sort(key=lambda a: datetime.fromisoformat(a["published_at"]), reverse=True)
    result["articles"] = articles[:int(source.get("max_articles", 2))]
    result["article_count"] = len(result["articles"])
    result["usable_for_current_analysis"] = any(a["usable_for_current_analysis"] for a in result["articles"])
    result["status"] = ("recent_cached_transcripts" if result["usable_for_current_analysis"]
                        else "historical_only" if result["article_count"] else "awaiting_audio")
    result["note"] = "读取已归档音频转写，尚未在线检查作者今天是否更新；需浏览器获取最新音频后导入。"
    if errors:
        result["errors"] = errors
    if not articles:
        result["error"] = "尚无音频转写；不能使用视频标题、简介或平台AI摘要代替正文。"
    return result


if __name__=='__main__':main()
