"""Explicit return bases: never add cash dividends to adjusted prices again."""
from datetime import date
from decimal import Decimal


def holding_period_return(start_value, end_value, dividends, *, basis,
                          start_date, end_date, events_complete=False):
    """One share held throughout (start_date,end_date], cash not reinvested.

    Inputs must use the same basis and share unit; splits need separate handling.
    This is a security-level return, NOT the investor account's return.
    """
    if basis not in ('raw_price', 'unit_nav', 'adjusted_price'):
        raise ValueError('收益口径必须为原始价格、单位净值或明确的复权价格')
    start, end = date.fromisoformat(start_date), date.fromisoformat(end_date)
    if start >= end:
        raise ValueError('收益区间无效')
    a, b = Decimal(str(start_value)), Decimal(str(end_value))
    if a <= 0 or b < 0 or not a.is_finite() or not b.is_finite():
        raise ValueError('价格/单位净值无效')
    if basis == 'adjusted_price':
        if dividends:
            raise ValueError('复权序列不能再次加分红，会重复计算')
        return dict(return_pct=float((b/a-1)*100), basis=basis,
                    cash_dividend_added=False, account_return=False)
    if not events_complete:
        return dict(return_pct=None, basis=basis, reason='区间分红/份额折算未核验完整，禁止输出总收益率')
    cash = Decimal(0)
    seen = set()
    for event in dividends:
        if not event.get('official_verified') or not event.get('source_url'):
            raise ValueError('分红需要官方核验及原始公告链接')
        eid = event['event_id']
        if eid in seen:
            raise ValueError('同一分红事件重复')
        seen.add(eid)
        if event.get('split_ratio', 1) != 1:
            raise ValueError('存在份额折算，需统一份额单位后计算')
        if start < date.fromisoformat(event['ex_date']) <= end:
            amount = Decimal(str(event['cash_per_unit']))
            if not amount.is_finite() or amount < 0:
                raise ValueError('每份分红金额无效')
            cash += amount
    return dict(return_pct=float(((b+cash)/a-1)*100), basis=basis,
                cash_per_unit=float(cash), reinvested=False, account_return=False,
                note='除息日确认股东权益收益；现金到账另按发放日，不代表账户可用现金增加')


def account_guard(symbol):
    return dict(account_return_pct=None, symbol=symbol,
                reason='缺少完整成交、费用、现金分红、份额折算和资金流水，券商摊薄成本不能还原真实收益率',
                broker_cost_is_adjusted_possible=True,
                require_reconciliation=symbol == '515180',
                rule='不把515180显示成本0.280及浮盈408.57%直接作为策略或历史投资回报')
