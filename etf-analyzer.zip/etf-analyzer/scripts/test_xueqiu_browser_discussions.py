"""实际页面采集：新版接口、正文分页、精确时间及配图缺口。"""
import os
import unittest
from unittest.mock import MagicMock,patch

from source_xueqiu import _collect_browser_page, parse_discussion_payload
from xueqiu_local_session import loopback_transport,live_browser_context


def post(index, text=True):
    return {'id':index,'created_at':1792112400000,'text':f'<p>公司营收同比增长20%，仍需结合估值核验。{index}</p>' if text else '',
            'truncated':False,'user':{'id':100+index,'screen_name':f'作者{index}'}}


class BrowserDiscussionTests(unittest.TestCase):
    def test_one_connection_timeout_is_retried_without_closing_user_browser(self):
        from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
        driver=MagicMock();browser=MagicMock();context=MagicMock()
        browser.contexts=[context];context.cookies.return_value=[{'name':'token','value':'not-exported'}]
        driver.chromium.connect_over_cdp.side_effect=[PlaywrightTimeoutError('temporary timeout'),browser]
        manager=MagicMock();manager.__enter__.return_value=driver
        with patch('playwright.sync_api.sync_playwright',return_value=manager),patch('xueqiu_local_session.existing_debug_endpoint',return_value='ws://127.0.0.1:9222/devtools/browser/test'):
            with live_browser_context() as (selected,metadata):
                self.assertIs(selected,context)
                self.assertEqual(metadata['连接尝试次数'],2)
                self.assertNotIn('not-exported',str(metadata))
        browser.close.assert_not_called()

    def test_filters_do_not_stop_second_page_when_first_page_has_image_only_posts(self):
        context=MagicMock();page=context.new_page.return_value
        page.evaluate.side_effect=[{'status':200,'payload':{'list':[post(i,i<9) for i in range(1,11)]}},
                                   {'status':200,'payload':{'list':[post(i) for i in range(11,21)]}}]
        result=_collect_browser_page(context,'515070',20)
        self.assertEqual(result['coverage']['pages'],2)
        self.assertEqual(result['coverage']['list_records'],20)
        self.assertEqual(len(result['items']),18)
        self.assertTrue(result['items'][0]['published_at'].endswith('+08:00'))
        self.assertIn('/query/v1/symbol/search/status.json',page.evaluate.call_args_list[0].args[0])
        self.assertIn("source:'user'",page.evaluate.call_args_list[0].args[0])
        page.close.assert_called_once()
        context.close.assert_not_called()

    def test_quote_shell_and_http_200_without_posts_do_not_pass(self):
        context=MagicMock();context.new_page.return_value.evaluate.return_value={'status':200,'payload':{'list':[]}}
        result=_collect_browser_page(context,'159338')
        self.assertFalse(result['available'])
        self.assertEqual(result['status'],'failed')
        self.assertEqual(result['items'],[])

    def test_graph_not_extracted_is_different_from_complete_text(self):
        row=post(1);row['text']+='<img src="chart.png">'
        item=parse_discussion_payload({'list':[row]})[0]
        self.assertTrue(item['text_complete'])
        self.assertFalse(item['body_complete'])
        self.assertEqual(item['unextracted_images'],1)

    def test_local_debug_proxy_setting_restores_original_environment(self):
        before=os.environ.get('NO_PROXY')
        external_proxy=os.environ.get('HTTP_PROXY')
        with loopback_transport():
            self.assertIn('127.0.0.1',os.environ['NO_PROXY'])
            self.assertEqual(os.environ.get('HTTP_PROXY'),external_proxy)
        self.assertEqual(os.environ.get('NO_PROXY'),before)


if __name__=='__main__': unittest.main()
