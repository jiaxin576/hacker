"""Persistent research inputs and per-analysis collection ledger (stdlib only).

Browser collection is performed by the skill's agent; this module never claims
that reading a cache is a live check. No retention/deletion job is implemented.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import uuid
from information_report import source_name, status_zh
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "data" / "research.sqlite3"
SYMBOLS = ("159338", "515070", "159611", "515180")


def now():
    return datetime.now(timezone.utc).isoformat()


def stamp(value):
    dt = datetime.fromisoformat(value)
    if dt.tzinfo is None:
        raise ValueError("时间必须含时区；不得把最后回复时间当成原帖发布时间")
    return dt.astimezone(timezone.utc).isoformat()


def connect(path=DB):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path, timeout=30)
    db.row_factory = sqlite3.Row
    db.executescript('''
    PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS runs(
      id TEXT PRIMARY KEY, started_at TEXT NOT NULL, sources_json TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS attempts(
      id INTEGER PRIMARY KEY, run_id TEXT NOT NULL, source_id TEXT NOT NULL,
      checked_at TEXT NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS items(
      platform TEXT NOT NULL, item_id TEXT NOT NULL, first_seen_at TEXT NOT NULL,
      PRIMARY KEY(platform,item_id));
    CREATE TABLE IF NOT EXISTS observations(
      id INTEGER PRIMARY KEY, run_id TEXT NOT NULL, source_id TEXT NOT NULL,
      platform TEXT NOT NULL, item_id TEXT NOT NULL, observed_at TEXT NOT NULL,
      published_at TEXT, content_hash TEXT NOT NULL, payload TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS obs_source_time ON observations(source_id,observed_at);
    CREATE TABLE IF NOT EXISTS analysis_snapshots(
      id INTEGER PRIMARY KEY, run_id TEXT NOT NULL, observed_at TEXT NOT NULL,
      payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS annotations(
      id INTEGER PRIMARY KEY, observation_id INTEGER NOT NULL,
      created_at TEXT NOT NULL, model TEXT NOT NULL, prompt_version TEXT NOT NULL,
      payload TEXT NOT NULL);
    ''')
    return db


def sources(symbols=SYMBOLS):
    result = []
    for raw in symbols:
        symbol = raw.split('.')[-1]
        if len(symbol) != 6 or not symbol.isdigit():
            raise ValueError(f"无效ETF代码：{symbol}")
        market = "SZ" if symbol.startswith(("0", "1", "3")) else "SH"
        result.append(dict(id=f'official:fund:{symbol}', platform='official', kind='fund_disclosures',
                           symbol=symbol, priority=1, url=f'https://fund.eastmoney.com/{symbol}.html',
                           note='该页仅用于发现基金管理人原始净值、分红、持仓报告、公告；以原始披露为准',
                           required_fields=['nav', 'dividends', 'holdings', 'announcements'], lookback_days=730))
        result.append(dict(id=f'research:drivers:{symbol}', platform='research', kind='business_drivers',
                           symbol=symbol, priority=2, url=None, lookback_days=60,
                           note='从本次持仓及指数成分股生成检索：公司经营新闻、行业研报、政府宏观政策'))
        for platform, url in (
            ("xueqiu", f"https://www.xueqiu.com/S/{market}{symbol}"),
            ("eastmoney", f"https://guba.eastmoney.com/list,{market.lower()}{symbol}.html"),
        ):
            result.append(dict(id=f"{platform}:etf:{symbol}", platform=platform,
                               kind="etf_comments", symbol=symbol, url=url,
                               priority=3, lookback_trading_days=20, bootstrap_calendar_days=90,
                               max_posts=100, max_pages=5))
    for row in json.loads((ROOT / "data/kol_sources.json").read_text(encoding="utf-8")):
        if row.get("enabled", True):
            result.append(dict(id=f"{row['platform']}:kol:{row['id']}",
                               platform=row['platform'], kind="kol", author_id=str(row['id']),
                               name=row.get('name'), url=row['url'], lookback_days=7,
                               priority=3, latest_only=row.get('latest_only', row['platform']=='douyin'),
                               max_posts=int(row.get('max_articles',2)) if row['platform'] == 'douyin' else 20, max_pages=5))
    if not any(s['platform'] == 'eastmoney' and s['kind'] == 'kol' for s in result):
        result.append(dict(id="eastmoney:kol:unconfigured", platform="eastmoney",
                           kind="kol", url=None, configured=False))
    return sorted(result, key=lambda s: s.get('priority', 3))


def begin(db, symbols=SYMBOLS):
    registry = json.loads((ROOT / 'data/source_registry.json').read_text(encoding='utf-8'))
    run = dict(run_id=uuid.uuid4().hex, started_at=now(), sources=sources(symbols),
               source_registry=registry,
               collection_contract='references/source_contract.md',
               final_validation='Agent须在CLI客观包生成后逐项验收基本面、日线、周线；API缺失须网页补采')
    with db:
        db.execute("INSERT INTO runs VALUES(?,?,?)",
                   (run['run_id'], run['started_at'], json.dumps(run['sources'], ensure_ascii=False)))
    return run


def get_run(db, run_id):
    row = db.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
    if row is None:
        raise ValueError("未知采集批次")
    return dict(row)


def ingest(db, run_id, batch):
    run = get_run(db, run_id)
    spec = next((s for s in json.loads(run['sources_json']) if s['id'] == batch['source_id']), None)
    if spec is None or spec.get('configured') is False:
        raise ValueError("来源未配置或不属于本次分析")
    checked = stamp(batch['checked_at'])
    if checked < run['started_at'] or checked > now():
        raise ValueError("检查时间不属于本次采集，不能复用旧批次完成状态")
    status = batch['status']
    if status not in ('ok', 'no_update', 'partial', 'blocked', 'failed'):
        raise ValueError("未知采集状态")
    if not batch.get('evidence') or not batch.get('coverage'):
        raise ValueError("需要页面证据和采样范围说明")
    records = batch.get('items', [])
    if status == 'ok' and not records:
        raise ValueError("ok必须有正文；没有更新应使用no_update并记录核查范围")
    if status in ('blocked', 'failed', 'no_update') and records:
        raise ValueError("失败/无更新状态不能混入正文，请使用partial")
    clean = []
    for item in records:
        item = dict(item)
        if not str(item.get('id', '')).strip() or not item.get('content', '').strip():
            raise ValueError("正文或帖子ID缺失")
        host = urlparse(item.get('url', '')).hostname or ''
        domains = {'xueqiu': ['xueqiu.com'], 'eastmoney': ['eastmoney.com'], 'douyin': ['douyin.com'],
                   'official': ['sse.com.cn', 'szse.cn', 'cninfo.com.cn', 'efunds.com.cn',
                                'chinaamc.com', 'gffunds.com.cn', 'gtfund.com']} .get(spec['platform'])
        if not host or (domains and not any(host == d or host.endswith('.' + d) for d in domains)):
            raise ValueError("原文链接与平台不符")
        if spec['kind'] == 'kol' and str(item.get('author_id')) != spec['author_id']:
            raise ValueError("博主身份不匹配")
        if spec.get('symbol') and item.get('symbol') != spec['symbol']:
            raise ValueError("ETF代码不匹配")
        pub = stamp(item['published_at']) if item.get('published_at') else None
        if pub and pub > checked:
            raise ValueError("发布时间晚于采集时间")
        if not pub and status == 'ok':
            raise ValueError("缺少可核实发布时间必须标partial")
        if item.get('content_type') not in ('post', 'reply', 'audio_transcript', 'title_only', 'disclosure', 'research', 'policy', 'news'):
            raise ValueError("必须区分正文、回复、转写及标题")
        if (item['content_type'] == 'title_only' or item.get('body_complete') is not True) and status == 'ok':
            raise ValueError("标题或截断正文只能标partial")
        if spec['platform'] == 'douyin':
            if item['content_type'] != 'audio_transcript' or not item.get('segments') or not item.get('media_sha256'):
                raise ValueError("抖音必须提供真实音频转写、分段和音频哈希")
        item['published_at'] = pub
        item['opinion_only'] = spec['platform'] not in ('official',)
        clean.append(item)
    if spec['kind'] == 'fund_disclosures' and status == 'ok':
        present = {i.get('category') for i in clean}
        if not set(spec['required_fields']).issubset(present):
            raise ValueError('净值、分红、持仓和公告须全部核验；否则记partial')
    with db:
        for item in clean:
            key = str(item['id'])
            db.execute("INSERT OR IGNORE INTO items VALUES(?,?,?)", (spec['platform'], key, checked))
            db.execute("INSERT INTO observations(run_id,source_id,platform,item_id,observed_at,published_at,content_hash,payload) VALUES(?,?,?,?,?,?,?,?)",
                       (run_id, spec['id'], spec['platform'], key, checked, item['published_at'],
                        hashlib.sha256(item['content'].encode()).hexdigest(), json.dumps(item, ensure_ascii=False)))
        summary = {k: v for k, v in batch.items() if k != 'items'}
        summary['item_count'] = len(clean)
        db.execute("INSERT INTO attempts(run_id,source_id,checked_at,status,payload) VALUES(?,?,?,?,?)",
                   (run_id, spec['id'], checked, status, json.dumps(summary, ensure_ascii=False)))


def context(db, run_id, days=90, as_of=None):
    run = get_run(db, run_id)
    cutoff = stamp(as_of) if as_of else now()
    lower = (datetime.fromisoformat(cutoff) - timedelta(days=days)).isoformat()
    report = dict(run_id=run_id, as_of=cutoff, window_days=days, sources=[], warnings=[],
                  purpose="投资者情绪、市场预期与风险预警；不得直接形成买卖信号", history_retention="append_only")
    for spec in json.loads(run['sources_json']):
        window_days = (max(days, spec.get('lookback_days', days)) if spec['kind'] == 'fund_disclosures'
                       else spec.get('lookback_days', days))
        source_lower = (datetime.fromisoformat(cutoff) - timedelta(days=window_days)).isoformat()
        attempt = db.execute("SELECT * FROM attempts WHERE run_id=? AND source_id=? AND checked_at<=? ORDER BY id DESC LIMIT 1",
                             (run_id, spec['id'], cutoff)).fetchone()
        status = attempt['status'] if attempt else ('not_configured' if spec.get('configured') is False else 'not_checked')
        # Latest *known* observation per post, not today's revision projected into history.
        rows = db.execute('''SELECT o.*, i.first_seen_at FROM observations o JOIN items i
            ON i.platform=o.platform AND i.item_id=o.item_id
            WHERE o.source_id=? AND o.observed_at<=? AND o.id=(
              SELECT MAX(x.id) FROM observations x WHERE x.source_id=o.source_id
              AND x.platform=o.platform AND x.item_id=o.item_id AND x.observed_at<=?)
            ORDER BY o.published_at DESC''', (spec['id'], cutoff, cutoff)).fetchall()
        recent = []
        undated = []
        for row in rows:
            if not row['published_at'] or (row['published_at'] <= cutoff and
                    (spec.get('latest_only') or source_lower <= row['published_at'])):
                item = json.loads(row['payload'])
                item.update(observation_id=row['id'], first_seen_at=row['first_seen_at'], observed_at=row['observed_at'])
                if row['published_at']:
                    recent.append(item)
                else:
                    undated.append(item)
        if spec.get('latest_only'):
            recent=recent[:spec.get('max_posts',2)]
        summary = dict(spec, status=status, live_checked=bool(attempt),
                       attempt=json.loads(attempt['payload']) if attempt else None,
                       historical_count=len(rows), recent_count=len(recent), items=recent[:100],
                       window_days=window_days,
                       output_truncated=len(recent) > 100)
        summary['undated_items'] = undated[:100]
        summary['undated_count'] = len(undated)
        summary['undated_output_truncated'] = len(undated) > 100
        summary['source_name_zh'] = source_name(spec)
        summary['status_zh'] = status_zh(status)
        report['sources'].append(summary)
        if status not in ('ok', 'no_update'):
            report['warnings'].append(f"{spec['id']}: {status} — " +
                                     ((summary['attempt'] or {}).get('reason') or '本次未完整取得更新'))
        if not recent and status in ('ok', 'no_update'):
            report['warnings'].append(f"{spec['id']}: 最近{window_days}天无可用正文，历史材料不可冒充当前观点")
    report['pending'] = [s['id'] for s in report['sources'] if s['status'] == 'not_checked']
    return report


def markdown(ctx):
    lines = ['## 数据源采集状态与警告', '', f"采集批次：`{ctx['run_id']}`。主观原文与客观数据作为信息源交付，不附投资判断。", '',
             '| 来源 | 本次状态 | 窗口内条数 | 历史帖数 |', '|---|---|---:|---:|']
    for s in ctx['sources']:
        lines.append(f"| {source_name(s)} | {status_zh(s['status'])} | {s['recent_count']} | {s['historical_count']} |")
    lines += ['', *['- 警告：' + w for w in ctx['warnings']]]
    return '\n'.join(lines)


def save_analysis(db, run_id, payload):
    get_run(db, run_id)
    with db:
        db.execute("INSERT INTO analysis_snapshots(run_id,observed_at,payload) VALUES(?,?,?)",
                   (run_id, now(), json.dumps(payload, ensure_ascii=False, default=str)))


def missing_fields(value, path='data'):
    """Report actual missing values, never impute zero or call absence neutral."""
    result = []
    if isinstance(value, dict):
        absent = [k for k, v in value.items() if v is None or v == '' or v == [] or v == {}]
        if absent:
            result.append(f"{path}: 缺失字段 {', '.join(absent)}（可能不适用或未披露，须核实）")
        if value.get('available') is False or value.get('error'):
            result.append(f"{path}: 不可用 — {value.get('error') or '源未提供可用数据'}")
        for key, child in value.items():
            if isinstance(child, (dict, list)) and child:
                result.extend(missing_fields(child, f'{path}.{key}'))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            if isinstance(child, (dict, list)):
                result.extend(missing_fields(child, f'{path}[{index}]'))
    return result


def trading_windows(db, run_id, trading_dates, as_of=None):
    """Compare latest/prior 10 and 20 completed sessions using real benchmark bars.

    Posts between closes belong to the next session. Weekend/after-close posts
    after the last completed session remain separate, not silently discarded.
    """
    cutoff = stamp(as_of) if as_of else now()
    closes = sorted({stamp(d + 'T15:00:00+08:00') for d in trading_dates
                     if stamp(d + 'T15:00:00+08:00') <= cutoff})
    if len(closes) < 41:
        return dict(available=False, reason='不足41个已完成交易日，不能构造前后20交易日比较；不以自然日代替')
    ctx = context(db, run_id, days=36500, as_of=cutoff)
    result = dict(available=True, calendar_source='上证指数实际日K日期；只取已完成收盘',
                  last_close=closes[-1], sources=[])
    for spec in ctx['sources']:
        if spec['kind'] != 'etf_comments':
            continue
        # Query all latest-known versions: avoid report display caps biasing research.
        rows = db.execute('''SELECT o.* FROM observations o WHERE source_id=? AND observed_at<=?
            AND id=(SELECT MAX(x.id) FROM observations x WHERE x.source_id=o.source_id
            AND x.platform=o.platform AND x.item_id=o.item_id AND x.observed_at<=?)''',
                          (spec['id'], cutoff, cutoff)).fetchall()
        def sample(lower, upper):
            selected = [r for r in rows if r['published_at'] and lower < r['published_at'] <= upper]
            authors = set()
            for row in selected:
                item = json.loads(row['payload'])
                if item.get('author_id'):
                    authors.add(item['author_id'])
            return dict(start_exclusive=lower, end_inclusive=upper, sample_count=len(selected),
                        independent_authors=len(authors), observation_ids=[r['id'] for r in selected],
                        caution='仅为已采集样本的时间窗口统计，非全平台全量')
        source = dict(source_id=spec['id'], collection_status=spec['status'], windows={})
        for n in (10, 20):
            source['windows'][str(n)] = dict(recent=sample(closes[-n-1], closes[-1]),
                                            previous=sample(closes[-2*n-1], closes[-n-1]))
        source['since_last_close'] = sample(closes[-1], cutoff)
        result['sources'].append(source)
    return result


def annotate(db, payload):
    for key in ('observation_id', 'model', 'prompt_version', 'sentiment', 'evidence'):
        if not payload.get(key):
            raise ValueError(f'标签缺少{key}')
    if payload['sentiment'] not in ('bullish', 'bearish', 'neutral', 'uncertain'):
        raise ValueError('未知情绪标签')
    if db.execute('SELECT 1 FROM observations WHERE id=?', (payload['observation_id'],)).fetchone() is None:
        raise ValueError('原文观察记录不存在')
    with db:
        cur = db.execute('INSERT INTO annotations(observation_id,created_at,model,prompt_version,payload) VALUES(?,?,?,?,?)',
                        (payload['observation_id'], now(), payload['model'], payload['prompt_version'],
                         json.dumps(payload, ensure_ascii=False)))
    return {'annotation_id': cur.lastrowid}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db', type=Path, default=DB)
    sub = p.add_subparsers(dest='command', required=True)
    start = sub.add_parser('begin')
    start.add_argument('--symbols', nargs='+', default=list(SYMBOLS))
    imp = sub.add_parser('ingest')
    imp.add_argument('--run-id', required=True)
    imp.add_argument('--file', type=Path, required=True)
    view = sub.add_parser('report')
    view.add_argument('--run-id', required=True)
    view.add_argument('--as-of')
    view.add_argument('--days', type=int, default=90)
    label = sub.add_parser('annotate')
    label.add_argument('--file', type=Path, required=True)
    a = p.parse_args()
    with connect(a.db) as db:
        if a.command == 'begin':
            result = begin(db, a.symbols)
        elif a.command == 'ingest':
            ingest(db, a.run_id, json.loads(a.file.read_text(encoding='utf-8-sig')))
            result = context(db, a.run_id)
        elif a.command == 'annotate':
            result = annotate(db, json.loads(a.file.read_text(encoding='utf-8-sig')))
        else:
            result = context(db, a.run_id, days=a.days, as_of=a.as_of)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
