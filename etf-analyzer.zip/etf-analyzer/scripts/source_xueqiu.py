"""雪球：作者文章与公开页面。"""
from __future__ import annotations

import html
import json
import logging
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
import requests
from source_common import DEFAULT_KOL_LIMIT, REQUEST_TIMEOUT, XUEQIU_COOKIE_CACHE, _clean_text


def parse_discussion_payload(payload, limit=20):
    """只接受结构化帖子；行情文字、页面导航和标题不算讨论正文。"""
    rows = payload.get('list') or payload.get('statuses') or []
    if isinstance(rows, dict):
        rows = rows.get('list') or rows.get('statuses') or []
    items = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict) or not row.get('id'):
            continue
        content = _clean_xueqiu_article_html(row.get('text') or '')
        user = row.get('user') or {}
        if not content or not user.get('id'):
            continue
        stamp = row.get('created_at')
        try:
            published = datetime.fromtimestamp(float(stamp)/1000, timezone(timedelta(hours=8))).isoformat() if stamp else None
        except (ValueError, TypeError, OverflowError, OSError):
            published = None
        complete = not bool(row.get('truncated') or row.get('is_truncated'))
        images = re.findall(r'<img\b[^>]*>',row.get('text') or '',re.I)
        missing_images = [image for image in images if not re.search(r'emoji|emoticon|face',image,re.I)]
        items.append({'id':str(row['id']), 'author_id':str(user['id']),
            'author':user.get('screen_name'), 'title':row.get('title') or '',
            'content':content, 'content_type':'post', 'body_complete':complete and not missing_images,
            'text_complete':complete,'unextracted_images':len(missing_images),
            'published_at':published, 'url':f"https://xueqiu.com/{user['id']}/{row['id']}",
            'reply_count':row.get('reply_count')})
        if len(items) >= limit:
            break
    return items


DISCUSSION_QUERY_SCRIPT = """async ({symbol, page}) => {
    const query = new URLSearchParams({symbol, count:'10', page:String(page), source:'user', sort:'time', type:'13', comment:'0', hl:'0'});
    try {
        const response = await fetch('/query/v1/symbol/search/status.json?'+query.toString(),
            {credentials:'include', signal:AbortSignal.timeout(15000)});
        try { return {status:response.status, payload:await response.json()}; }
        catch { return {status:response.status, non_json:true}; }
    } catch(error) { return {network_error:error.name}; }
}"""


def _collect_browser_page(context, symbol, limit=20, detail_limit=6):
    """在用户登录态页面执行与讨论选项卡一致的查询，保留真实时间并展开长帖。"""
    from source_common import symbol_to_secid
    _,code,pure=symbol_to_secid(symbol)
    code=code.upper();page=context.new_page()
    result={'symbol':pure,'url':f'https://www.xueqiu.com/S/{code}','items':[],
        'status':'failed','available':False,'attempts':[],
        'fetched_at':datetime.now(timezone(timedelta(hours=8))).isoformat(),
        'coverage':{'pages':0,'list_records':0,'returned':0,'complete_bodies':0,'truncated':True}}
    try:
        page.goto(result['url'],wait_until='domcontentloaded',timeout=20000)
        try: page.get_by_text('讨论',exact=True).first.click(timeout=5000)
        except Exception: pass  # 下方同源查询仍明确限定source=user，不将报价文字当作讨论。
        seen=set()
        for page_number in range(1,min(5,(limit+9)//10)+1):
            response=page.evaluate(DISCUSSION_QUERY_SCRIPT,{'symbol':code,'page':page_number})
            payload=response.get('payload') or {}
            attempt={'入口':'页面同源讨论查询','路径':'/query/v1/symbol/search/status.json',
                     '页码':page_number,'HTTP状态':response.get('status'),
                     '平台错误码':payload.get('error_code'),'网络错误':response.get('network_error')}
            result['attempts'].append(attempt)
            items=parse_discussion_payload(payload,10)
            raw_count=len(payload.get('list') or [])
            result['coverage']['list_records']+=raw_count
            if not raw_count: break
            result['coverage']['pages']+=1
            for item in items:
                if item['id'] in seen: continue
                seen.add(item['id']);item.update(symbol=pure,opinion_only=True,
                    explicit_symbol_mention=pure in item['content'],
                    association_basis='正文明确提及ETF代码' if pure in item['content'] else '仅讨论页检索关联，不能当作ETF持有人观点')
                result['items'].append(item)
            if len(result['items'])>=limit or raw_count<10: break
        # 第一页中存在的长帖直接展开；第二页长帖另在详情页读取，不假定列表为全文。
        expanded=0
        for item in result['items']:
            if item.get('text_complete') or expanded>=detail_limit: continue
            article=page.locator(f'article.timeline__item:has(a.date-and-source[data-id="{item["id"]}"])')
            if not article.count(): continue
            try:
                article.get_by_text('展开',exact=True).first.click(timeout=3000)
                text=article.locator('.timeline__item__content').inner_text(timeout=5000)
                if len(text)>len(item['content']):
                    item.update(content=text.removesuffix('收起').strip(),text_complete=True,
                                body_complete=not item.get('unextracted_images'))
                    expanded+=1
            except Exception: pass
        result['items']=result['items'][:limit]
        complete=sum(i.get('body_complete') is True for i in result['items'])
        result['coverage'].update(returned=len(result['items']),complete_bodies=complete,expanded_bodies=expanded)
        result.update(available=bool(result['items']),status='partial' if result['items'] else 'failed',
            reason=f'现有浏览器页面取得{len(result["items"])}条正文，其中{complete}条完整；按时间排序的有限样本，图片或回复未全覆盖' if result['items'] else '页面同源查询未取得正文；不能推断登录失效或无更新')
    except Exception as exc:
        result.update(status='partial' if result['items'] else 'failed',
                      available=bool(result['items']),reason=f'页面采集未全部完成（{type(exc).__name__}）；已得正文单独保留')
    finally: page.close()  # 只关闭本函数创建的页，不关闭用户原有页面或浏览器。
    result['checked_at']=datetime.now(timezone(timedelta(hours=8))).isoformat()
    return result


def fetch_browser_discussions(symbols, limit=20, browser='chrome'):
    """一次连接采集多只ETF；HTTP接口受限时以实际登录页面为来源。"""
    from xueqiu_local_session import live_browser_context,LocalSessionUnavailable
    symbols=[symbols] if isinstance(symbols,str) else list(symbols)
    results={}
    try:
        with live_browser_context(browser) as (context,metadata):
            for symbol in symbols:
                result=_collect_browser_page(context,symbol,limit)
                result['local_session']=metadata
                results[symbol]=result
    except Exception as exc:
        reason=str(exc) if isinstance(exc,LocalSessionUnavailable) else f'现有浏览器连接失败（{type(exc).__name__}），未保存敏感调用日志'
        for symbol in symbols:
            results.setdefault(symbol,{'symbol':symbol,'items':[],'available':False,'status':'failed','reason':reason})
    return results


def parse_discussion_page(page, limit=20):
    """解析公开页内已返回的帖子JSON，不把动态空壳误判为取得列表。"""
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(page, 'html.parser')
    for script in soup.find_all('script'):
        raw = script.string or script.get_text()
        candidates = [raw] if script.get('type') == 'application/json' else []
        for match in re.finditer(r'(?:SNB\.data\.(?:statuses|statusesList)|window\.__INITIAL_STATE__)\s*=\s*', raw):
            candidates.append(raw[match.end():])
        for candidate in candidates:
            try:
                obj = json.JSONDecoder().raw_decode(candidate.strip())[0]
            except (ValueError, TypeError):
                continue
            if isinstance(obj, list): obj = {'list':obj}
            if isinstance(obj, dict):
                items = parse_discussion_payload(obj, limit)
                if items: return items
    return []


def fetch_discussions(symbol, limit=20):
    """正常公开HTTP查询讨论正文；登录、验证码或风控响应原样记为受限。"""
    from source_common import symbol_to_secid
    _, code, pure = symbol_to_secid(symbol)
    url = f'https://www.xueqiu.com/S/{code.upper()}'
    attempts, items = [], []
    with requests.Session() as session:
        session.headers.update({'User-Agent':'Mozilla/5.0', 'Referer':url})
        try:
            page = session.get(url, timeout=18)
            attempts.append({'入口':'公开行情页', 'HTTP状态':page.status_code})
            if page.ok: items = parse_discussion_page(page.text, limit)
            if not items:
                response = session.get('https://www.xueqiu.com/query/v1/symbol/search/status.json',
                    params={'symbol':code.upper(), 'count':min(limit,100), 'page':1,
                            'source':'user', 'sort':'time', 'type':13,'comment':0, 'hl':0}, timeout=18)
                attempts.append({'入口':'公开讨论接口', 'HTTP状态':response.status_code})
                try:
                    api_payload = response.json()
                    if isinstance(api_payload,dict) and api_payload.get('error_code'):
                        attempts[-1]['平台错误码'] = str(api_payload['error_code'])
                        attempts[-1]['原因'] = str(api_payload.get('error_description') or '')[:120]
                except ValueError: api_payload = {}
                if response.ok:
                    items = parse_discussion_payload(api_payload, limit)
            blocked = any(a['HTTP状态'] in (401,403,429) or a.get('平台错误码') in ('400016','400012') for a in attempts)
            status = 'partial' if items else ('blocked' if blocked else 'failed')
            reason = ('已取得帖子正文；仅一页非随机样本，回复未展开' if items else
                      ('公开讨论接口提示重新登录；未取得帖子正文' if blocked else '未取得可核实帖子正文；行情页文字不算讨论列表，动态内容尚未取得'))
        except requests.RequestException as exc:
            status, reason = ('partial' if items else 'failed'), f'公开请求未完成（{type(exc).__name__}）；不能认定无讨论'
    return {'url':url, 'symbol':pure, 'available':bool(items), 'status':status, 'items':items,
            'reason':reason, 'attempts':attempts,
            'coverage':{'pages':1, 'returned':len(items), 'truncated':True},
            'fetched_at':datetime.now(timezone(timedelta(hours=8))).isoformat()}


def fetch_authenticated_discussions(symbol, limit=20, auth_mode='cache', cookie_file=None, profile='Default'):
    """复用用户授权的本地Cookie，通过Playwright正常登录态请求讨论。"""
    from source_common import symbol_to_secid
    from xueqiu_local_session import local_request_session, LocalSessionUnavailable
    _,code,pure=symbol_to_secid(symbol)
    result={'url':f'https://www.xueqiu.com/S/{code.upper()}', 'symbol':pure,'items':[],
            'available':False,'status':'blocked','attempts':[],
            'coverage':{'pages':0,'returned':0,'truncated':True},
            'fetched_at':datetime.now(timezone(timedelta(hours=8))).isoformat()}
    try:
        with local_request_session(auth_mode,cookie_file,profile) as (context,metadata):
            result['local_session']=metadata  # 不含Cookie值或存储状态。
            response=context.get('https://www.xueqiu.com/query/v1/symbol/search/status.json',
                params={'symbol':code.upper(),'count':min(limit,100),'page':1,
                        'source':'user','sort':'time','type':13,'comment':0,'hl':0},
                headers={'Referer':result['url']}, timeout=20000,max_redirects=0)
            attempt={'入口':'Playwright登录态讨论接口','HTTP状态':response.status}
            result['attempts'].append(attempt)
            if response.status in (301,302,303,307,308):
                from urllib.parse import urlsplit,urljoin
                target=urlsplit(urljoin('https://www.xueqiu.com/',response.headers.get('location') or ''))
                attempt['重定向域']=target.hostname
                attempt['重定向类别']='讨论接口' if target.path in ('/statuses/search.json','/query/v1/symbol/search/status.json') else '其他路径'
                result['reason']='已读取本地Cookie，但讨论接口返回重定向，尚未通过正文验收；不能直接认定Cookie有效或失效'
                return result
            try: data=response.json()
            except Exception:
                result['reason']='已携带本地登录态，但返回非JSON或验证页面；未取得正文，不自动绕过验证'
                return result
            if not isinstance(data,dict):
                result.update(status='failed',reason='登录态请求返回的数据结构异常')
                return result
            if data.get('error_code'):
                attempt['平台错误码']=str(data['error_code'])
                result['reason']='本地登录态仍未获准读取讨论，需重新登录或完成平台要求的验证'
                return result
            if response.status != 200:
                result['reason']=f'登录态请求未成功（HTTP {response.status}），未取得正文'
                return result
            items=parse_discussion_payload(data,limit)
            result.update(items=items,available=bool(items),status='partial' if items else 'failed',
                reason='已通过本地登录态取得正文；一页非随机样本，回复未展开' if items else '登录态接口未返回可核实正文，不能认定无更新')
            result['coverage'].update(pages=1,returned=len(items),complete_bodies=sum(i.get('body_complete') is True for i in items))
    except LocalSessionUnavailable as exc:
        result['reason']=str(exc)  # 仅本模块定义的固定、无敏感信息错误。
    except Exception as exc:
        # Playwright异常可能附带请求Cookie；禁止将原始异常或调用日志落盘。
        result.update(status='failed',reason=f'本地登录态读取或访问失败（{type(exc).__name__}）；敏感调用日志未保存')
    return result


def fetch_public_page(symbol=None,author_id=None):
    """公开主页或ETF讨论入口，不自动登录、刷新Cookie或绕过验证。"""
    from bs4 import BeautifulSoup
    from source_common import symbol_to_secid
    import requests
    if author_id:
        if not str(author_id).isdigit():raise ValueError('雪球作者编号必须为数字')
        url=f'https://www.xueqiu.com/u/{author_id}'
    else:
        secid,code,pure=symbol_to_secid(symbol)
        url=f'https://www.xueqiu.com/S/{code.upper()}'
    response=requests.get(url,headers={'User-Agent':'Mozilla/5.0'},timeout=18);response.raise_for_status()
    soup=BeautifulSoup(response.text,'html.parser')
    for node in soup(['script','style']):node.decompose()
    text=soup.get_text('\n',strip=True)
    items = parse_discussion_page(response.text)
    return {'url':url,'content':text,'available':bool(items),'items':items,
            'status':'partial' if items else 'failed','body_complete':False,
            'note':'已取得正文' if items else '只取得页面文字，未取得帖子正文；空壳页不代表无更新'}


def _extract_xueqiu_uid(raw: str) -> str:
    """从 UID 字符串、用户主页 URL 或帖子 URL 中提取雪球用户 ID。"""
    text = str(raw or "").strip()
    if text.isdigit():
        return text
    m_user = re.search(r"xueqiu\.com/u/(\d+)", text)
    if m_user:
        return m_user.group(1)
    m_post = re.search(r"xueqiu\.com/(\d{5,})/\d+", text)
    if m_post:
        return m_post.group(1)
    m_num = re.search(r"(\d{6,})", text)
    return m_num.group(1) if m_num else text

def _clean_xueqiu_article_html(raw_html: str) -> str:
    """将雪球专栏/帖子 HTML 正文清洗为保留段落结构的纯文本，并去除底部固定免责声明。"""
    if not raw_html:
        return ""
    text = re.sub(r"(?i)<\s*br\s*/?\s*>", "\n", raw_html)
    text = re.sub(r"(?i)</\s*(p|div|li|blockquote|h[1-6]|tr)\s*>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = html.unescape(text)
    text = text.replace("\xa0", " ").replace("\u200b", "")
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in text.splitlines()]
    cleaned_lines: list[str] = []
    for ln in lines:
        if not ln:
            if cleaned_lines and cleaned_lines[-1] != "":
                cleaned_lines.append("")
            continue
        if (
            ln.startswith("素材来源：")
            or ln.startswith("风险提示：文中提及到上市公司")
            or ln.startswith("本资料所引用的观点")
            or ln.startswith("从业人员信息公示：")
        ):
            continue
        cleaned_lines.append(ln)
    while cleaned_lines and cleaned_lines[-1] == "":
        cleaned_lines.pop()
    return "\n".join(cleaned_lines).strip()

def _load_cached_xueqiu_cookie() -> str | None:
    if not XUEQIU_COOKIE_CACHE.exists():
        return None
    try:
        payload = json.loads(XUEQIU_COOKIE_CACHE.read_text(encoding="utf-8"))
        return payload.get("cookie_str") or None
    except Exception:
        return None

def _save_cached_xueqiu_cookie(cookie_str: str) -> None:
    try:
        XUEQIU_COOKIE_CACHE.parent.mkdir(parents=True, exist_ok=True)
        XUEQIU_COOKIE_CACHE.write_text(
            json.dumps(
                {
                    "updated_at": datetime.now().isoformat(sep=" ", timespec="seconds"),
                    "cookie_str": cookie_str,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    except Exception as exc:
        logging.debug("保存雪球 Cookie 缓存失败: %s", exc)

def _refresh_xueqiu_cookie_via_playwright(seed_uid: str = "2817386050") -> str | None:
    """当无 Cookie 或触发阿里云 WAF 时，使用无头 Chrome 自动完成 JS 挑战并提取最新 Cookie。"""
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        logging.warning("Playwright 未安装或不可用，无法自动刷新雪球 WAF Cookie: %s", exc)
        return None

    chrome_candidates = [
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
    ]
    exec_path = next((p for p in chrome_candidates if Path(p).exists()), None)
    try:
        with sync_playwright() as p:
            launch_kwargs: dict[str, Any] = {
                "headless": True,
                "args": ["--no-sandbox", "--disable-blink-features=AutomationControlled"],
            }
            if exec_path:
                launch_kwargs["executable_path"] = exec_path
            browser = p.chromium.launch(**launch_kwargs)
            ctx = browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                ),
                ignore_https_errors=True,
            )
            page = ctx.new_page()
            page.goto(f"https://www.xueqiu.com/u/{seed_uid}", wait_until="domcontentloaded", timeout=22000)
            page.wait_for_timeout(3200)
            cookies = ctx.cookies()
            browser.close()
        cookie_str = "; ".join(f"{c['name']}={c['value']}" for c in cookies if c.get("name") and c.get("value"))
        if cookie_str and ("xq_a_token" in cookie_str or "acw_sc__v2" in cookie_str):
            _save_cached_xueqiu_cookie(cookie_str)
            return cookie_str
    except Exception as exc:
        logging.warning("Playwright 刷新雪球 WAF Cookie 失败: %s", exc)
    return None

def _xueqiu_get_json(url: str, *, cookie_str: str, referer: str) -> dict[str, Any] | None:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        "Cookie": cookie_str,
        "Referer": referer,
        "Accept": "application/json, text/plain, */*",
        "X-Requested-With": "XMLHttpRequest",
    }
    try:
        resp = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT, verify=False)
        if resp.status_code != 200:
            return None
        text = resp.text.strip()
        if not text.startswith("{"):
            return None
        data = json.loads(text)
        if isinstance(data, dict) and ("_waf_" in text[:200] or data.get("error_code")):
            return None
        return data
    except Exception:
        return None

def _fetch_single_xueqiu_kol(
    source: dict[str, Any],
    *,
    cookie_str: str,
) -> tuple[dict[str, Any] | None, bool]:
    """使用给定 cookie_str 抓取单个雪球博主的最新文章。返回 (结果字典, 是否因WAF需要刷新Cookie)。"""
    uid = str(source["id"])
    max_articles = int(source.get("max_articles") or DEFAULT_KOL_LIMIT)
    referer = f"https://www.xueqiu.com/u/{uid}"

    orig_data = _xueqiu_get_json(
        f"https://www.xueqiu.com/statuses/original/timeline.json?user_id={uid}&page=1",
        cookie_str=cookie_str,
        referer=referer,
    )
    tl_data = _xueqiu_get_json(
        f"https://www.xueqiu.com/v4/statuses/user_timeline.json?user_id={uid}&page=1&type=0",
        cookie_str=cookie_str,
        referer=referer,
    )
    if orig_data is None and tl_data is None:
        return None, True

    candidates: dict[int, dict[str, Any]] = {}
    for row in (orig_data or {}).get("list") or []:
        if isinstance(row, dict) and row.get("id"):
            candidates[int(row["id"])] = row
    for row in (tl_data or {}).get("statuses") or []:
        if isinstance(row, dict) and row.get("id") and int(row["id"]) not in candidates:
            candidates[int(row["id"])] = row

    sorted_posts = sorted(
        candidates.values(),
        key=lambda x: int(x.get("created_at") or 0),
        reverse=True,
    )[:max_articles]

    articles: list[dict[str, Any]] = []
    detected_name = source.get("name") or f"雪球博主_{uid}"
    for post in sorted_posts:
        post_id = post["id"]
        detail = _xueqiu_get_json(
            f"https://www.xueqiu.com/statuses/show.json?id={post_id}",
            cookie_str=cookie_str,
            referer=referer,
        )
        raw_obj = detail if isinstance(detail, dict) and detail.get("id") else post
        user_info = raw_obj.get("user") or {}
        if user_info.get("screen_name"):
            detected_name = user_info["screen_name"]
        created_ms = raw_obj.get("created_at") or post.get("created_at")
        pub_time = (
            datetime.fromtimestamp(int(created_ms) / 1000).strftime("%Y-%m-%d %H:%M:%S")
            if created_ms
            else None
        )
        raw_html = raw_obj.get("text") or raw_obj.get("description") or ""
        content = _clean_xueqiu_article_html(raw_html)
        title = _clean_text(raw_obj.get("title") or post.get("title") or "")
        if not title and content:
            first_line = content.splitlines()[0][:40]
            title = first_line + ("..." if len(content.splitlines()[0]) > 40 else "")
        articles.append(
            {
                "id": post_id,
                "title": title or f"动态_{post_id}",
                "published_at": pub_time,
                "url": f"https://www.xueqiu.com/{uid}/{post_id}",
                "view_count": post.get("view_count") or raw_obj.get("view_count"),
                "reply_count": raw_obj.get("reply_count"),
                "like_count": raw_obj.get("like_count"),
                "summary": content[:260].replace("\n", " ") + ("..." if len(content) > 260 else ""),
                "content": content,
            }
        )

    return {
        "id": uid,
        "name": detected_name,
        "platform": source.get("platform", "xueqiu"),
        "style": source.get("style", ""),
        "profile_url": referer,
        "article_count": len(articles),
        "articles": articles,
    }, False


if __name__ == '__main__':
    from source_debug import run_source_cli
    def configure(parser):
        from xueqiu_local_session import configured_auth_mode
        parser.add_argument('--auth-mode',choices=['public','cache','chrome','edge'],default=configured_auth_mode(),
                            help='用户授权后选择本地Cookie缓存或已登录浏览器；优先复用现有连接')
        parser.add_argument('--cookie-file',type=Path,help='雪球专用Cookie或Playwright storage_state文件；不输出明文')
        parser.add_argument('--profile',default='Default',help='Default或Profile 数字')
        parser.add_argument('--symbols',nargs='+',help='页面模式一次连接采集多只ETF')
    def collect_comments(args):
        if args.auth_mode in ('chrome','edge'):
            data=fetch_browser_discussions(args.symbols or [args.symbol],args.limit,args.auth_mode)
            if args.symbols: return {'by_etf':data,'available':any(d['available'] for d in data.values()),'status':'partial' if any(d['available'] for d in data.values()) else 'failed'}
            return data[args.symbol]
        if args.auth_mode=='public': return fetch_discussions(args.symbol,args.limit)
        return fetch_authenticated_discussions(args.symbol,args.limit,args.auth_mode,args.cookie_file,args.profile)
    run_source_cli('雪球',{'comments':collect_comments,
                         'comments-api':lambda a:fetch_authenticated_discussions(a.symbol,a.limit,'cache' if a.auth_mode=='public' else a.auth_mode,a.cookie_file,a.profile),
                         'page':lambda a:fetch_public_page(symbol=a.symbol,author_id=a.author)},configure=configure)
