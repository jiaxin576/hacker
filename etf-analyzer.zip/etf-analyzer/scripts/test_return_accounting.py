import unittest
from return_accounting import holding_period_return, account_guard


class ReturnTests(unittest.TestCase):
    def setUp(self):
        self.event = dict(event_id='test-dividend', official_verified=True,
                          source_url='https://www.sse.com.cn/test-fixture',
                          ex_date='2026-10-16', cash_per_unit=0.061)
        self.args = dict(basis='unit_nav', start_date='2026-10-15', end_date='2026-10-16', events_complete=True)

    def test_ex_dividend_is_not_economic_loss(self):
        # Synthetic fixture, not a claim about actual 515180 NAV.
        r = holding_period_return(1.5, 1.439, [self.event], **self.args)
        self.assertAlmostEqual(r['return_pct'], 0)
        self.assertEqual(r['cash_per_unit'], .061)

    def test_adjusted_cannot_double_count_dividend(self):
        with self.assertRaises(ValueError):
            holding_period_return(1.5, 1.5, [self.event], **dict(self.args, basis='adjusted_price'))

    def test_missing_event_verification_means_unknown(self):
        r = holding_period_return(1.5, 1.439, [], **dict(self.args, events_complete=False))
        self.assertIsNone(r['return_pct'])

    def test_duplicates_and_split_are_rejected(self):
        for events in ([self.event, self.event], [dict(self.event, split_ratio=2)]):
            with self.assertRaises(ValueError):
                holding_period_return(1.5, 1.439, events, **self.args)

    def test_already_ex_dividend_at_start_not_counted_again(self):
        r = holding_period_return(1.439, 1.439, [self.event], **dict(self.args, start_date='2026-10-16', end_date='2026-10-19'))
        self.assertEqual(r['cash_per_unit'], 0)

    def test_broker_display_not_account_return(self):
        self.assertIsNone(account_guard('515180')['account_return_pct'])


if __name__ == '__main__':
    unittest.main()
