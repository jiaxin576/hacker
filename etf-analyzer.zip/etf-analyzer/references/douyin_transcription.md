# 抖音视频音频转写

用途：获取已配置作者的公开视频音频，转成带时间戳的文字，供ETF分析交叉验证。支持已下载视频或独立音轨。本地识别不需要OpenAI API密钥。

## 金融康博士来源

唯一主采平台为抖音。必须核对下面作者主页与目标作品作者身份；雪球文章、搜索摘要、其他平台搬运和旧转写不能替代本次抖音原视频采集。无法访问抖音则记录 blocked/failed，不改用转载并标成已采集抖音。

- 作者ID：`MS4wLjABAAAA82IHtScs-vvmMmHpuc_ekwMpyc813SImU5ktR8mRBlw`
- 首选主页（用户指定）：https://www.douyin.com/user/MS4wLjABAAAA82IHtScs-vvmMmHpuc_ekwMpyc813SImU5ktR8mRBlw?from_tab_name=main
- 规范主页：https://www.douyin.com/user/MS4wLjABAAAA82IHtScs-vvmMmHpuc_ekwMpyc813SImU5ktR8mRBlw
- 样例：https://www.douyin.com/video/7664580569715477787
- 样例标题：市场到底了吗？现在该怎么办？
- 样例页面发布时间：2026-07-20 20:07（北京时间）。这是历史样例，不代表最新更新。

## 获取当前更新

必须从上面主页发现作品，不依赖用户逐条提供短链接；`historical_example_video_url` 只保留历史样例身份。短链接可辅助单条核查，但不能代替主页近期作品列表。

可先执行主页发现、下载与本地转写工具：

```powershell
py -3.10 .pi/skills/etf-analyzer/scripts/discover_douyin_home.py --output-dir outputs/douyin_本批 --download --transcribe --asr-python C:/Users/Admin/AppData/Local/Programs/Python/Python310/python.exe
```

上例使用本机已有Whisper和CUDA的Python 3.10；其他机器改为实际安装识别依赖的解释器。脚本从 `kol_sources.json` 读取主页，解析该页公开JSON或作品链接，按作者编号与真实发布时间核验，默认取最新2条，不限制7天；时间较旧时明确标历史内容。没有作者或日期的链接只列待核验候选，不冒充最新作品。只有主页实际返回播放资源时才下载并提取讲话音轨；不采用背景音乐地址，不执行验证脚本、不生成接口签名。

主页公开响应缺少作品数据时退出码为2，保存中文 `主页作品采集清单.json` 与原始响应；这是运行失败，不是“没有新视频”。Agent继续一次正常浏览器降级，若浏览器能力不可用或访问验证仍阻挡，必须报告尚未打通，不能宣称实现了无人值守采集。工具也可用 `--homepage-html <已取得的同一主页HTML>` 做离线解析，此模式明确不声称本次联网。

用当前可用浏览器工具打开配置中的作者主页，核实作者，按真实发布时间识别最新2条作品，不把置顶旧视频当最新。每条必须展示视频ID、作者ID、标题、原链接、北京时间发布日期和时分；发布时间未知则明确未知，复盘交易日另列。尚未检查主页时不能声称“今天没有更新”。

用户已打开此作者主页时，优先绑定现有标签页；带 `from_tab_name=main` 与规范主页按同一作者核对。保留用户指定入口，不用7月样例视频作为固定采集目标。浏览器工具超时不证明主页无新作品；空HTTP响应也不证明无更新。普通浏览器降级仍受限时记录中文原因并停止此访问路径；若工具因无法确认网址等原因主动终止，立即停止该UI路径，不尝试通过其他自动化绕过限制。

本次检查应保存作品清单：作品ID、标题、作者ID、发布时间、是否置顶、原链接、采集状态、未转写原因、证据路径。只对实际看到并核实的作品生成记录。主页都无法读取时保留空清单与失败原因，不编造视频条目。

打开目标作品后，优先使用浏览器支持的媒体下载。若播放器使用DASH分离流，视频元素可能是blob且直接下载失败；此时读取该标签页 `pageAssets` 能力的文档，再 `list()`。音轨有时归为 `other`，可通过资源名称 `media-audio` 识别，不能只筛选 `video`。只获取当前目标视频实际观察到的音频资源；不要把推荐视频、背景音乐或平台AI摘要当作目标正文。

优先用资源导出能力；不支持音频时，可用已观察到的公开媒体URL通过常规HTTP下载。媒体URL会过期，应即时取得并下载，不写入配置作为永久地址。不要导出账号Cookie或把签名、认证请求等全部资源记录到报告。遇到登录或验证限制应说明状态，不绕过访问控制。

## 本地转写与归档

依赖：Python、`openai-whisper`、可工作的PyTorch、PATH中的ffmpeg/ffprobe。选用已安装这些依赖的Python解释器。第一次使用某模型时Whisper会下载官方模型权重；有GPU时优先使用GPU。中文财经内容建议medium，base可用于快速初稿。

为已下载音频创建 `metadata.json`：

```json
{
  "video_id": "7664580569715477787",
  "author_id": "MS4wLjABAAAA82IHtScs-vvmMmHpuc_ekwMpyc813SImU5ktR8mRBlw",
  "author": "金融康博士",
  "title": "市场到底了吗？现在该怎么办？",
  "url": "https://www.douyin.com/video/7664580569715477787",
  "published_at": "2026-07-20T20:07:00+08:00"
}
```

在仓库目录执行，路径和视频ID替换为实际值：

```powershell
python .pi/skills/etf-analyzer/scripts/transcribe_media.py --media outputs/douyin_7664580569715477787/audio.m4a --metadata outputs/douyin_7664580569715477787/metadata.json --output-dir outputs/douyin_7664580569715477787 --model medium
```

也可将从同一音频产生的Whisper JSON用 `--whisper-json <path>` 导入，`--model` 必须填写实际识别模型，不能把不同音频的结果混用。

输出：`transcript.txt`、带时间戳的 `transcript.md`、结构化 `transcript.json`，并将结构化转写原子写入 `data/kol_transcripts/douyin/<作者ID>/<视频ID>.json`。保存音频哈希和原始识别结果便于追溯。

## 进入ETF报告

`data/kol_sources.json` 中 `platform: douyin` 的作者会读取各自的转写归档，以平台和作者ID区分来源。默认72小时之外的内容标为 `historical`，`usable_for_current_analysis: false`。读到近期归档也不能自动声称已经在线检查今日更新；`live_checked` 默认为false。

当前没有后台调度。每次启动ETF分析，Agent必须按 [统一采集流程](research_collection.md) 自动检查主页、获取新视频音频并本地识别，入库后再运行ETF信息采集。缓存读取函数仅供兼容，正式分析以当批数据库记录为准。抓取失败需标明原因，可保留历史材料，但不得用旧视频填补当日观点。

转写是作者的原始观点，不是已经核实的市场事实；可能有同音字、断句和数字错误。保留原始识别，不默默修改数字或语义；人工校订另存版本，并核对带时间戳的原音频。不同平台同一观点不得重复计作独立证据。

转写进入“主观数据 → 抖音 → 大V文章与视频 → 金融康博士”，按 [分类交付规范](information_organization.md) 与基金客观数据分开。标题、采集状态、错误原因和转写说明用中文；原始字段与链接照存。
