# 数据源拆分、调试与MD汇总

主脚本 `scripts/etf_analyzer.py` 只负责批次检查、来源调度、ETF信息组合、缺失汇总与最终报告。采集实现不再堆在主脚本中；旧函数名保留兼容导出，便于原有调用迁移。

## 文件职责

| 文件（均位于scripts/） | 职责 | 单独调试示例 |
|---|---|---|
| source_tencent.py | 腾讯行情、日周K、海外行情 | `python source_tencent.py --mode quotes --symbol 515070` |
| source_eastmoney.py | 东方财富调试入口，按模式路由 | `python source_eastmoney.py --mode fund --symbol 159338` |
| source_eastmoney_fund.py | 基金档案、持仓、公司财务与两融 | `python source_eastmoney_fund.py --mode holdings --symbol 515070` |
| source_eastmoney_kline.py | 东方财富历史日周K请求 | `python source_eastmoney_kline.py --mode weekly --symbol 159611 --limit 130` |
| source_eastmoney_market.py | 全A两融、市场宽度、宏观商品 | `python source_eastmoney_market.py --mode margin` |
| source_eastmoney_news.py | 财经新闻、文章原文、7×24快讯 | `python source_eastmoney_news.py --mode news --keyword 海光信息 --days 7` |
| source_eastmoney_comments.py | 股吧列表、实际链接正文、作者与原始日期 | `python source_eastmoney_comments.py --symbol 515070 --limit 20` |
| source_xueqiu.py | 登录页同源讨论正文、动态列表、毫秒时间、图片缺口；独立API诊断 | `python source_xueqiu.py --mode comments --auth-mode chrome --symbols 159338 515070 159611 515180 --limit 20` |
| xueqiu_local_session.py | 用户授权后以Playwright复用本地雪球Cookie，临时配置与敏感日志隔离 | `source_xueqiu.py --auth-mode cache/chrome/edge`，不独立采集 |
| source_douyin.py | 从配置主页发现最新2条、日期校验、下载音轨与转写 | `py -3.10 source_douyin.py --output-dir outputs/douyin_本批 --download --transcribe` |
| source_sse.py | 上交所官方快照核对 | `python source_sse.py --symbol 515180` |
| source_tushare.py | 历史ETF份额接口 | `python source_tushare.py --symbol 515180 --limit 35` |
| source_official.py | 基金管理人、交易所、公司原始页面/PDF | `python source_official.py --url <官方HTTPS链接>` |
| source_common.py | 公共配置、会话工厂、数据类型与转换 | 不独立采集 |
| source_debug.py | 来源CLI参数与调试结果保存 | 由来源模块调用 |
| market_data.py | 日周K跨源回退、快照协调、份额归档 | 不直接发送HTTP请求 |
| technical_indicators.py | 日周线确定性统计 | 纯计算，不联网 |
| kol_config.py / kol_collection.py | 作者身份配置与多平台协调 | 不把缓存读取说成在线检查 |
| research_store.py | 批次、原文、修订、来源状态与历史库 | 沿用begin/ingest/report命令 |
| report_renderer.py | ETF客观数据渲染 | 不采集网络数据 |
| information_report.py | 主客观分类、新闻、质量与完整MD汇总 | `python information_report.py --input <采集包> --output-dir <目录>` |
| research_brief.py | 精简客观表、去重事件、正文观点、讨论摘要、合并缺失 | 由information_report调用；不联网 |
| transcribe_media.py | 已下载音频本地识别、带日期转写归档 | 不负责发现最新视频 |

示例在scripts目录执行；从仓库根目录运行时补上 `.pi/skills/etf-analyzer/scripts/` 前缀。所有独立来源支持 `--help`。除抖音已有专用参数外，通用来源支持 `--output <JSON路径>`，默认结果保存在 `outputs/debug/`，标准输出只打印中文状态与文件路径。需要调试某一接口时直接运行其文件，不必先跑完整采集。

东方财富持仓分析会调用腾讯模块补充重仓股价格；上交所快照调试先取得基础报价再核对官方字段，结果保留提供方身份，不把腾讯数据标作官方数据。

## 主流程与最终文档

1. `etf_analyzer.py --prepare-sources` 创建本批清单。
2. 分来源采集，保存证据，按实际结果入库。接口缺失时按契约网页补采。
3. `etf_analyzer.py --source-run <批次>` 调用各来源实现，汇总客观数据与主观资料。
4. `information_report.py` 生成一份 **`*_汇总报告.md`**；主脚本原有 `etf_info_*.md` 也包含同样完整结构。

汇总MD依次包含：四只ETF客观数据、官方分红与重大公告核验、财经新闻与背景事件、主观观点与每只ETF讨论摘要、合并缺失清单。全文、列表标题和逐条来源元数据只保留JSON和历史库；MD不展开原文。详见[精简交付](information_organization.md)。

仅有原始快照需离线重整时运行 `information_report.py --input ...`，不会自动触发新采集或覆盖原文历史。补采结果先合并后再生成MD。来源失败仍显示缺失，不能以报告文件生成成功代替采集成功。

抖音仍以配置中的金融康博士主页为入口，按真实发布时间取最新2条并标日期。主页无法读取或平台验证阻挡时，保存空清单、访问状态和原因；此时不宣称已取得视频，也不回退到固定历史视频或要求用户逐条给短链接。
