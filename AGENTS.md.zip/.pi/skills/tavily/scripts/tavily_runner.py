#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tavily Unified CLI Runner
统一集成 Tavily 核心能力：tavily-search (语义搜索), tavily-extract (网页正文抽取), tavily-research (深度综合研报)
自动维护 <查询主题>/tavily/ 目录结构与 JSON / Markdown 持久化保存
"""

import os
import sys
import json
import argparse
import subprocess
import re
from pathlib import Path
from urllib.parse import urlparse

def sanitize_name(name: str) -> str:
    """清理文件名或目录名中的非法字符"""
    clean = re.sub(r'[\\/*?:"<>|]', "_", name).strip()
    clean = re.sub(r"\s+", "_", clean)
    return clean or "tavily_output"

def url_to_filename(url: str) -> str:
    """根据 URL 生成安全的文件名"""
    parsed = urlparse(url)
    domain = parsed.netloc.replace(".", "_")
    path_slug = re.sub(r"[^a-zA-Z0-9_\-]", "_", parsed.path.strip("/"))
    if not path_slug:
        path_slug = "index"
    if len(path_slug) > 50:
        path_slug = path_slug[:50]
    return f"{domain}_{path_slug}"

def ensure_dir(path: Path) -> Path:
    """确保目录存在"""
    path.mkdir(parents=True, exist_ok=True)
    return path

def run_tvly_command(cmd_args: list) -> dict:
    """执行底层 tvly 命令并返回解析后的 JSON 字典"""
    full_cmd = ["tvly"] + cmd_args + ["--json"]
    try:
        res = subprocess.run(full_cmd, capture_output=True, text=True, check=False)
        if res.returncode != 0 and not res.stdout:
            sys.stderr.write(f"tvly 执行失败 (code {res.returncode}): {res.stderr}\n")
            return {"error": res.stderr.strip() or f"exit code {res.returncode}"}
        
        # 尝试从 stdout 解析 JSON
        stdout_str = res.stdout.strip()
        if not stdout_str:
            return {"error": "无输出内容", "stderr": res.stderr.strip()}
        
        try:
            return json.loads(stdout_str)
        except json.JSONDecodeError:
            return {"raw_output": stdout_str, "stderr": res.stderr.strip()}
    except FileNotFoundError:
        return {"error": "未检测到 tvly 命令行工具，请确保已安装并在 PATH 中。"}

def handle_search(args):
    """处理 tavily-search"""
    topic = args.topic or sanitize_name(args.query)
    base_dir = Path(args.save_dir) if args.save_dir else Path(f"./{topic}/tavily")
    ensure_dir(base_dir)

    cmd = ["search", args.query, "--depth", args.depth, "--max-results", str(args.max_results)]
    if args.topic_type:
        cmd += ["--topic", args.topic_type]
    if args.time_range:
        cmd += ["--time-range", args.time_range]
    if args.include_domains:
        cmd += ["--include-domains", args.include_domains]
    if args.exclude_domains:
        cmd += ["--exclude-domains", args.exclude_domains]
    if args.include_raw_content:
        cmd += ["--include-raw-content", args.include_raw_content]
    if args.include_answer:
        cmd += ["--include-answer", args.include_answer]

    print(f"[*] 正在执行 tavily-search 检索: '{args.query}' (depth: {args.depth}) ...")
    data = run_tvly_command(cmd)

    # 保存 JSON
    json_path = base_dir / "tavily_search.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    # 导出可读性 Markdown 摘要
    md_path = base_dir / "tavily_search_summary.md"
    results = data.get("results", []) if isinstance(data, dict) else []
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(f"# Tavily 搜索结果汇总: {args.query}\n\n")
        f.write(f"- **检索主题**: {topic}\n")
        f.write(f"- **搜索深度**: {args.depth}\n")
        f.write(f"- **返回条数**: {len(results)}\n\n")
        
        answer = data.get("answer")
        if answer:
            f.write(f"## AI 聚合回答\n\n{answer}\n\n---\n\n")

        f.write("## 网页检索详情\n\n")
        for idx, item in enumerate(results, 1):
            title = item.get("title", "无标题")
            url = item.get("url", "")
            score = item.get("score", 0)
            content = item.get("content", "")
            raw = item.get("raw_content")

            f.write(f"### {idx}. [{title}]({url})\n")
            f.write(f"- **相关度评分**: `{score}`\n")
            f.write(f"- **摘要片段**:\n> {content.strip()}\n\n")
            if raw:
                f.write(f"<details><summary>点击展开完整网页正文 (约 {len(raw)} 字符)</summary>\n\n")
                f.write(f"{raw}\n\n")
                f.write("</details>\n\n")
            f.write("---\n")

    print(f"[+] 检索完成！数据已归档至:")
    print(f"    - JSON: {json_path}")
    print(f"    - Markdown: {md_path}")
    return 0

def handle_extract(args):
    """处理 tavily-extract"""
    topic = args.topic or "web_extract"
    base_dir = Path(args.save_dir) if args.save_dir else Path(f"./{topic}/tavily")
    extracted_dir = ensure_dir(base_dir / "extracted")

    cmd = ["extract"] + args.urls + ["--extract-depth", args.extract_depth, "--format", args.format]
    if args.query:
        cmd += ["--query", args.query]
    if args.chunks_per_source:
        cmd += ["--chunks-per-source", str(args.chunks_per_source)]
    if args.timeout:
        cmd += ["--timeout", str(args.timeout)]

    print(f"[*] 正在执行 tavily-extract 抽取: {len(args.urls)} 个链接 ...")
    data = run_tvly_command(cmd)

    # 保存 JSON
    json_path = base_dir / "tavily_extract.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    # 导出各个页面的独立 Markdown
    results = data.get("results", []) if isinstance(data, dict) else []
    saved_md_files = []
    for item in results:
        url = item.get("url", "")
        title = item.get("title", "")
        raw_content = item.get("raw_content", "")
        slug = url_to_filename(url)
        item_path = extracted_dir / f"{slug}.md"
        with open(item_path, "w", encoding="utf-8") as f:
            f.write(f"# {title or slug}\n\n")
            f.write(f"- **来源 URL**: {url}\n\n")
            f.write("---\n\n")
            f.write(raw_content or "*(未获取到正文)*")
            f.write("\n")
        saved_md_files.append(item_path)

    print(f"[+] 提取完成！数据已归档至:")
    print(f"    - 汇总 JSON: {json_path}")
    print(f"    - 单页 Markdown 目录: {extracted_dir} (共提取 {len(saved_md_files)} 篇)")
    return 0

def handle_research(args):
    """处理 tavily-research"""
    topic = args.topic or sanitize_name(args.query)
    base_dir = Path(args.save_dir) if args.save_dir else Path(f"./{topic}/tavily")
    ensure_dir(base_dir)

    cmd = ["research", "run", args.query, "--model", args.model]
    if args.citation_format:
        cmd += ["--citation-format", args.citation_format]
    if args.timeout:
        cmd += ["--timeout", str(args.timeout)]

    print(f"[*] 正在发起 tavily-research 深度自主调研: '{args.query}' (model: {args.model}) ...")
    print("    深度调研需要综合多源网页信息，通常耗时 30 ~ 90 秒，请耐心等待...")
    data = run_tvly_command(cmd)

    # 保存 JSON
    json_path = base_dir / "tavily_research.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    # 导出清晰 Markdown 调研报告
    report_md_path = base_dir / "tavily_research_report.md"
    report_text = ""
    citations = []

    if isinstance(data, dict):
        report_text = data.get("report") or data.get("content") or data.get("answer") or ""
        citations = data.get("sources") or data.get("citations") or []
        if not report_text and "raw_output" in data:
            report_text = data["raw_output"]

    with open(report_md_path, "w", encoding="utf-8") as f:
        f.write(f"# Tavily 深度研究报告: {args.query}\n\n")
        f.write(f"- **调研主题**: {topic}\n")
        f.write(f"- **使用模型**: {args.model}\n\n")
        f.write("---\n\n")
        f.write(report_text or "*(未能解析研报正文，请查看 JSON 原文)*")
        f.write("\n\n---\n\n")

        if citations:
            f.write("## 参考文献与引文来源 (Citations)\n\n")
            for c_idx, c in enumerate(citations, 1):
                if isinstance(c, dict):
                    c_title = c.get("title") or c.get("name") or "网页来源"
                    c_url = c.get("url") or c.get("link") or ""
                    f.write(f"{c_idx}. [{c_title}]({c_url})\n")
                elif isinstance(c, str):
                    f.write(f"{c_idx}. {c}\n")

    print(f"[+] 深度调研完成！产物已归档至:")
    print(f"    - JSON: {json_path}")
    print(f"    - Markdown 研报: {report_md_path}")
    return 0

def main():
    parser = argparse.ArgumentParser(
        description="Tavily AI 统一检索、网页提取与研报生成工具 (涵盖 tavily-search, tavily-extract, tavily-research)"
    )
    subparsers = parser.add_subparsers(dest="command", help="选择执行的子工具")

    # 1. Search 子命令
    p_search = subparsers.add_parser("search", help="AI 语义搜索 (tavily-search)")
    p_search.add_argument("query", help="搜索查询关键词")
    p_search.add_argument("--topic", help="指定调研主题名称，将自动创建 <主题>/tavily/ 目录")
    p_search.add_argument("--depth", choices=["ultra-fast", "fast", "basic", "advanced"], default="basic", help="搜索深度 (默认: basic)")
    p_search.add_argument("--max-results", "-n", type=int, default=5, help="返回结果数量上限 (默认: 5)")
    p_search.add_argument("--topic-type", choices=["general", "news", "finance"], help="主题类别")
    p_search.add_argument("--time-range", choices=["day", "week", "month", "year"], help="时间范围")
    p_search.add_argument("--include-domains", help="限定包含的域名列表，逗号分隔")
    p_search.add_argument("--exclude-domains", help="排除的域名列表，逗号分隔")
    p_search.add_argument("--include-raw-content", choices=["markdown", "text"], help="是否在搜索结果中直接抓取完整网页正文")
    p_search.add_argument("--include-answer", choices=["basic", "advanced"], help="是否包含 AI 生成的问答摘要")
    p_search.add_argument("--save-dir", help="自定义输出目录，默认保存在 ./<主题>/tavily/")

    # 2. Extract 子命令
    p_extract = subparsers.add_parser("extract", help="指定 URL 网页正文抽取 (tavily-extract)")
    p_extract.add_argument("urls", nargs="+", help="一个或多个目标网页 URL (最多20个)")
    p_extract.add_argument("--topic", help="指定调研主题名称，将自动创建 <主题>/tavily/ 目录")
    p_extract.add_argument("--query", help="可选：按相关度重排内容块并提取关键切块")
    p_extract.add_argument("--chunks-per-source", type=int, help="每个 URL 提取的块数 (需配合 --query)")
    p_extract.add_argument("--extract-depth", choices=["basic", "advanced"], default="basic", help="抽取深度 (动态渲染页面推荐 advanced)")
    p_extract.add_argument("--format", choices=["markdown", "text"], default="markdown", help="正文格式 (默认: markdown)")
    p_extract.add_argument("--timeout", type=float, help="超时时间 (秒)")
    p_extract.add_argument("--save-dir", help="自定义输出目录")

    # 3. Research 子命令
    p_research = subparsers.add_parser("research", help="AI 自主多轮深度研究与报告生成 (tavily-research)")
    p_research.add_argument("query", help="研究课题或复杂分析问题")
    p_research.add_argument("--topic", help="指定调研主题名称，将自动创建 <主题>/tavily/ 目录")
    p_research.add_argument("--model", choices=["mini", "pro", "auto"], default="auto", help="研报模型等级 (mini: ~30s定向研究, pro: ~60-120s多视角综合研究)")
    p_research.add_argument("--citation-format", choices=["numbered", "mla", "apa", "chicago"], default="numbered", help="引文引用格式")
    p_research.add_argument("--timeout", type=int, default=600, help="等待研报生成的最大超时秒数")
    p_research.add_argument("--save-dir", help="自定义输出目录")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "search":
        sys.exit(handle_search(args))
    elif args.command == "extract":
        sys.exit(handle_extract(args))
    elif args.command == "research":
        sys.exit(handle_research(args))

if __name__ == "__main__":
    main()
