---
name: tavily
description: 基于 Tavily AI 引擎的互联网智能检索、网页正文深度抽取与多源深度研报生成 Skill。整合 tavily-search（针对 LLM 优化的高相关语义搜索）、tavily-extract（JavaScript 渲染网页正文去噪抽取）与 tavily-research（AI 自主多轮网络调研与带引文长篇研报生成）三大核心工具。执行检索、抽取或调研任务时，系统会自动在当前执行目录下创建以【查询主题名称】命名的根目录（如 <查询主题>/tavily/），并为搜索结果、提取正文和深度研报分别生成独立的 JSON 数据文件与 Markdown 归档。
allowed-tools:
  - Bash(tvly *)
  - Bash(python3 /media/vdc/stock/.pi/skills/tavily/scripts/tavily_runner.py *)
---

# Tavily (AI 智能搜索、网页全文抽取与深度研究综合 Skill)

基于 **Tavily AI** 平台封装的智能互联网数据检索与调研 Skill。专为大语言模型 (LLM) 和 AI Agent 工作流量身定制，彻底解决传统搜索引擎噪音大、缺乏语义重排、动态网页无法解析以及长篇综合研报生成困难的痛点。

本 Skill 将 Tavily 最核心的三大能力整合为统一工作流，并提供原生 CLI（`tvly`）与自动化管理脚本（`tavily_runner.py`）：
1. **`tavily-search`**：专为 LLM 优化的高相关度语义搜索，内置相关度评分、智能片段提取，并支持直接抓取清洗后的完整 Markdown 网页正文（`--include-raw-content`）。
2. **`tavily-extract`**：针对特定 URL（支持单次批量最多 20 个）的高精度正文解析与去噪，完整支持客户端 JavaScript 动态渲染，输出规整的 Markdown 文本或按需语义切块。
3. **`tavily-research`**：AI 自主多轮全网检索、交叉比对与研报生成，支持快速定向分析（`mini`）与综合长篇研报（`pro`），自动输出权威文献与网页引文（Citations）。

---

## 核心特性与默认保存规范

1. **目录结构规范（严格参考《GUI大模型测试数据集和测试方案》与标准调研规范）**：
   - 每次发起检索、页面抓取或深度调研时，系统会自动在当前执行目录下创建以**【查询主题名称】**命名的根目录（如 `./GUI大模型测试数据集和测试方案/` 或 `./AI评测/`）。
   - 在其子目录 `tavily/` 中，**为三个核心工具分别生成独立的 JSON 字典与 Markdown 归档文件**：
     - `tavily_search.json` & `tavily_search_summary.md`（语义搜索命中文档、相关度评分及可选网页全文）
     - `tavily_extract.json` & `extracted/<url_slug>.md`（针对具体网页抽取的无噪音 Markdown 正文）
     - `tavily_research.json` & `tavily_research_report.md`（AI 自主深度研究生成的结构化长篇研报与引文来源）
2. **网页全文深度提取与免二次请求**：
   - 执行搜索时若需阅读正文，可直接添加 `--include-raw-content markdown` 参数，单次请求即可同时获取搜索片段与完整网页正文，无需针对每个 URL 再次发起爬虫请求。
   - 对单篇技术文章或指定文档，使用 `tavily-extract` 并开启 `--extract-depth advanced`，自动执行浏览器渲染引擎抓取 SPA 动态内容。
3. **输出严格落地磁盘（严禁控制台超大打印）**：
   - 网页全文与深度研报体积通常达到数十 KB 至数 MB，**一律通过 `-o` 参数或运行脚本直接落盘保存到 `<查询主题>/tavily/` 目录**。Agent 完成后只需对输出文件执行有界读取（`read` / `head`）并汇报核心结论。
4. **开箱即用与免 Key 机制**：
   - `search` 和 `extract` 支持开箱即用的免 Key 试用额度；
   - 系统本地已配置并完成 Tavily CLI 认证，可无缝调用全部高级能力（包括 `research`）。若遇鉴权问题可通过 `tvly login` 或配置环境变量 `TAVILY_API_KEY` 注入凭证。

---

## 目录结构与各工具保存规范

```
当前工作目录/
└── <查询主题名称>/                         # 例如：GUI大模型测试数据集和测试方案 / AI评测
    └── tavily/                             # Tavily 私有产物子目录
        ├── tavily_search.json              # tavily-search 检索结果（含 URL、分数、摘要及网页全文）
        ├── tavily_search_summary.md        # tavily-search 格式化 Markdown 摘要
        ├── tavily_extract.json             # tavily-extract 批量正文抽取元数据
        ├── extracted/                      # tavily-extract 导出的单篇清晰 Markdown 页面
        │   ├── docs_tavily_com_overview.md
        │   └── github_com_repo_readme.md
        ├── tavily_research.json            # tavily-research 原始深度研报数据
        └── tavily_research_report.md       # tavily-research 格式化综合分析报告（含 Citations 引文）
```

### JSON 产物数据格式示例

#### 1. `tavily_search.json`（语义搜索产物）
```json
{
  "query": "GUI Agent benchmark dataset evaluation",
  "response_time": 1.45,
  "results": [
    {
      "title": "OSWorld: Benchmarking Multimodal Agents on Desktop Environment",
      "url": "https://os-world.github.io/",
      "content": "OSWorld is the first scalable real-world desktop environment benchmark...",
      "score": 0.942,
      "raw_content": "# OSWorld Benchmark\n\nOSWorld provides a real-world testing environment..."
    }
  ]
}
```

#### 2. `tavily_extract.json`（网页抽取产物）
```json
{
  "results": [
    {
      "url": "https://example.com/docs/api",
      "title": "API Documentation",
      "raw_content": "# API Reference\n\nClean extracted markdown content...",
      "images": []
    }
  ],
  "failed_results": []
}
```

#### 3. `tavily_research.json`（深度研报产物）
```json
{
  "request_id": "2e20abff-ee31-4868-9e72-ad837373bf02",
  "status": "completed",
  "report": "# 大模型评测方法全景对比分析\n\n## 1. 概述\n...",
  "sources": [
    {
      "title": "Holistic Evaluation of Language Models (HELM)",
      "url": "https://crfm.stanford.edu/helm/latest/"
    }
  ]
}
```

---

## 工具契约定义 (Tool Definition)

### 1. `tavily_search` (高相关性语义搜索)
```json
{
  "name": "tavily_search",
  "description": "基于 Tavily 引擎检索全网高质量网页信息。专为大模型设计，支持语义重排、相关度打分与完整正文抓取，结果自动存入 <查询主题>/tavily/tavily_search.json。",
  "parameters": {
    "type": "object",
    "properties": {
      "query": {
        "type": "string",
        "description": "优化后的搜索关键词或短语（建议 400 字符以内，保持清晰明确）"
      },
      "topic": {
        "type": "string",
        "description": "调研主题名称，作为当前项目下的主目录名（例如：'GUI大模型测试数据集和测试方案'）"
      },
      "depth": {
        "type": "string",
        "enum": ["basic", "advanced", "fast", "ultra-fast"],
        "default": "basic",
        "description": "搜索深度：basic (标准高相关，默认), advanced (深度精排与事实检索), fast (低延迟), ultra-fast (极速)"
      },
      "max_results": {
        "type": "integer",
        "default": 5,
        "description": "返回的最大结果条数 (1-20)"
      },
      "include_raw_content": {
        "type": "string",
        "enum": ["markdown", "text"],
        "description": "是否直接在搜索结果中抓取并附带网页完整正文（强烈推荐 'markdown'，省去二次抽取）"
      },
      "time_range": {
        "type": "string",
        "enum": ["day", "week", "month", "year"],
        "description": "限定搜索时间范围"
      },
      "include_domains": {
        "type": "string",
        "description": "指定包含的域名（逗号分隔，例如：'github.com,arxiv.org'）"
      },
      "exclude_domains": {
        "type": "string",
        "description": "指定排除的域名（逗号分隔）"
      }
    },
    "required": ["query"]
  }
}
```

### 2. `tavily_extract` (网页正文精准抽取)
```json
{
  "name": "tavily_extract",
  "description": "从指定的一个或多个网页 URL 中抓取并解析纯净的正文内容，自动去除网页广告与导航噪声，支持 JS 动态渲染并将结果转为 Markdown 文件。",
  "parameters": {
    "type": "object",
    "properties": {
      "urls": {
        "type": "array",
        "items": { "type": "string" },
        "description": "目标网页 URL 列表（单次最多 20 个）"
      },
      "topic": {
        "type": "string",
        "description": "调研主题名称，输出将归档于 <主题>/tavily/extracted/ 目录下"
      },
      "extract_depth": {
        "type": "string",
        "enum": ["basic", "advanced"],
        "default": "basic",
        "description": "抽取深度：basic (静态页面快速抽取), advanced (处理 SPA、Vue/React 动态渲染页面)"
      },
      "query": {
        "type": "string",
        "description": "可选关注焦点：指定后仅提取与该 query 语义最相关的段落块并重排序"
      },
      "chunks_per_source": {
        "type": "integer",
        "default": 3,
        "description": "每个 URL 提取的语义片段块数 (1-5，需配合 query 使用)"
      },
      "format": {
        "type": "string",
        "enum": ["markdown", "text"],
        "default": "markdown",
        "description": "正文输出格式"
      }
    },
    "required": ["urls"]
  }
}
```

### 3. `tavily_research` (AI 自主多轮深度研究)
```json
{
  "name": "tavily_research",
  "description": "发起 AI 自主多轮全网深度调研。针对复杂研究课题进行多角度事实搜集、比对与综合分析，自动生成带引文（Citations）的结构化研报，保存于 <主题>/tavily/tavily_research_report.md。",
  "parameters": {
    "type": "object",
    "properties": {
      "query": {
        "type": "string",
        "description": "需要深度调研的研究课题或多角度比对问题（例如：'大模型 Agent 在 GUI 操作领域的测试基准与前沿架构全景对比'）"
      },
      "topic": {
        "type": "string",
        "description": "调研主题名称，输出将自动落盘至 <主题>/tavily/"
      },
      "model": {
        "type": "string",
        "enum": ["auto", "mini", "pro"],
        "default": "auto",
        "description": "研究模型：mini (针对性定向调研，~30s), pro (长篇全景多角度深度研报，~60-120s), auto (根据课题自动选择)"
      },
      "citation_format": {
        "type": "string",
        "enum": ["numbered", "mla", "apa", "chicago"],
        "default": "numbered",
        "description": "文献与来源引用标注格式"
      }
    },
    "required": ["query"]
  }
}
```

---

## 快速调用指南 (CLI 使用方法)

在 Agent 中推荐通过 Bash 工具调用，支持两种便捷方式：
- **推荐方式 A（Skill 统一脚本）**：自动创建 `<主题>/tavily/` 目录并同时生成 JSON 和 Markdown 报告。
- **方式 B（原生 `tvly` 命令）**：使用 Tavily 官方原生命令行直接落盘。

### 工具一：tavily-search (语义搜索)

#### 1. 基础搜索（自动创建主题目录并保存摘要）
```bash
python3 /media/vdc/stock/.pi/skills/tavily/scripts/tavily_runner.py search \
  "GUI大模型评测基准 OSWorld VisualWebArena" \
  --topic "AI评测" \
  --depth advanced \
  --max-results 5
```

#### 2. 一步到位：搜索并抓取完整网页正文（省去二次抓取）
```bash
# 原生 CLI 方式
mkdir -p "./AI评测/tavily"
tvly search "大模型 Agent 评测方法与体系" \
  --depth advanced \
  --include-raw-content markdown \
  --max-results 5 \
  -o "./AI评测/tavily/tavily_search.json" \
  --json
```

#### 3. 时效性搜索与限定权威域名
```bash
python3 /media/vdc/stock/.pi/skills/tavily/scripts/tavily_runner.py search \
  "Multimodal GUI Agent evaluation" \
  --topic "AI评测" \
  --time-range month \
  --include-domains "arxiv.org,github.com" \
  --max-results 10
```

---

### 工具二：tavily-extract (网页正文抽取)

#### 1. 单个或多个 URL 批量解析为 Markdown
```bash
python3 /media/vdc/stock/.pi/skills/tavily/scripts/tavily_runner.py extract \
  "https://os-world.github.io/" \
  "https://github.com/xlang-ai/OSWorld" \
  --topic "AI评测" \
  --extract-depth advanced
```
> 执行后会在 `./AI评测/tavily/` 生成 `tavily_extract.json`，并在 `./AI评测/tavily/extracted/` 下分别生成清晰的 `.md` 文件。

#### 2. 目标聚焦：语义切块抓取（只抽取与核心问题相关的段落）
```bash
# 提取官方文档中关于 API 鉴权和速率限制的特定章节
python3 /media/vdc/stock/.pi/skills/tavily/scripts/tavily_runner.py extract \
  "https://docs.tavily.com/documentation/api-reference/endpoint/search" \
  --topic "AI评测" \
  --query "rate limits and authentication" \
  --chunks-per-source 3
```

#### 3. 原生 CLI 方式抽取
```bash
mkdir -p "./AI评测/tavily"
tvly extract "https://os-world.github.io/" \
  --extract-depth advanced \
  --format markdown \
  -o "./AI评测/tavily/tavily_extract.json" \
  --json
```

---

### 工具三：tavily-research (深度综合研报)

当面对宏观调研、竞品对比、技术路线分析或文献综述时，使用 `tavily-research` 自动发起多轮检索与交叉论证。

#### 1. 全自动生成综合深度研报 (`--model pro`)
```bash
python3 /media/vdc/stock/.pi/skills/tavily/scripts/tavily_runner.py research \
  "全面对比当前主流大模型在 GUI 界面操作 (Computer-Use / Phone-Use) 任务上的评测数据集、核心指标与技术局限性" \
  --topic "AI评测" \
  --model pro \
  --citation-format numbered
```
> 该命令会等待研报完成（耗时约 60~90 秒），并在 `./AI评测/tavily/` 下生成：
> - `tavily_research.json`（原始数据）
> - `tavily_research_report.md`（带目录、分析结论和完整参考文献引文的排版研报）

#### 2. 定向轻量级研究 (`--model mini`)
```bash
python3 /media/vdc/stock/.pi/skills/tavily/scripts/tavily_runner.py research \
  "OSWorld 评测基准的核心架构设计与任务评测流程" \
  --topic "AI评测" \
  --model mini
```

#### 3. 原生 CLI 异步模式（支持大任务轮询与实时流）
```bash
# 启动异步任务获取 request_id
tvly research run "多模态大模型评测综述" --no-wait --json

# 检查当前生成进度
tvly research status <request_id> --json

# 阻塞等待完成并直接保存
tvly research poll <request_id> -o "./AI评测/tavily/tavily_research.json" --json
```

---

## 核心参数对照速查表

| 功能工具 | 参数项 | CLI 原生参数 | 脚本参数 | 默认值 | 作用说明 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Search** | 查询短语 | `QUERY` | `query` | 必需 | 搜索关键词或短语（保持语义清晰） |
| | 搜索深度 | `--depth` | `--depth` | `basic` | `basic` (通用) / `advanced` (深度精准) / `fast` / `ultra-fast` |
| | 返回条数 | `--max-results` | `-n, --max-results`| `5` | 1 ~ 20 条 |
| | 抓取网页正文 | `--include-raw-content`| `--include-raw-content`| 无 | 设为 `markdown` 可直接内联网页全文 |
| | 时间过滤 | `--time-range` | `--time-range` | 无 | `day`, `week`, `month`, `year` |
| | 包含域名 | `--include-domains` | `--include-domains` | 无 | 限定搜索站点（如 `github.com`） |
| **Extract** | 页面链接 | `URLS...` | `urls` | 必需 | 待抓取的网页 URL（支持单次多链接，最多 20 个） |
| | 抽取深度 | `--extract-depth` | `--extract-depth` | `basic` | `basic` (静态) / `advanced` (JS 动态渲染页面) |
| | 语义聚焦 | `--query` | `--query` | 无 | 指定要关注的问题，抽取高相关度切块 |
| | 正文格式 | `--format` | `--format` | `markdown`| `markdown` 或 `text` |
| **Research** | 研究课题 | `QUERY` | `query` | 必需 | 复杂研究分析问题，尽量详细描述 |
| | 研究模型 | `--model` | `--model` | `auto` | `mini` (~30s 单主题), `pro` (~60-120s 深度全景) |
| | 引文格式 | `--citation-format` | `--citation-format` | `numbered`| `numbered`, `mla`, `apa`, `chicago` |

---

## 最佳实践与注意事项 (Best Practices)

1. **三步走工作流（Search → Extract → Research）**：
   - 当需要寻找线索或广泛了解时，优先执行 `tavily-search`；
   - 若搜索结果中的某些高价值链接需要更深入解析，对该 URL 调用 `tavily-extract`；
   - 当需要输出综合性行业报告、全景对比或文献综述时，直接发起 `tavily-research`。
2. **优先使用 `--include-raw-content markdown`**：
   - 在执行 `tavily-search` 时，如果预计需要阅读页面正文，加上 `--include-raw-content markdown` 可以一次性返回正文，无需针对每个 URL 额外调用 Extract，极大降低总体延时与调用成本。
3. **JS 渲染与动态页面处理**：
   - 提取知乎、GitHub 动态页、现代文档站（如 VuePress/Docusaurus）时，务必将抽取深度设为 `advanced`（即 `--extract-depth advanced`），确保客户端 JavaScript 渲染完成后再截取 DOM。
4. **大文件产物与 Agent 上下文管理**：
   - 严禁将大批量带有完整 raw_content 的搜索结果直接通过终端大量输出到 LLM Context 中。
   - 统一使用本规范落盘到 `<查询主题>/tavily/` 目录，之后使用 `read`（带 `limit`/`offset`）或 `head` 命令做按需读取与提炼。
5. **凭证与配额异常排查**：
   - 本机已配置 `authenticated: true`。如果遇到 `401 Unauthorized` 或额度耗尽提示，可在终端执行 `tvly login` 重新认证，或通过环境变量 `export TAVILY_API_KEY="tvly-xxx"` 覆盖。
