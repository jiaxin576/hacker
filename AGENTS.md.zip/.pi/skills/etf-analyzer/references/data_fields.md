# ETF Analyzer 输出数据字段字典与数据源说明 (data_fields)

本文档说明 `scripts/etf_analyzer.py` 采集并输出的客观数据字段结构及对应数据源。

---

## 一、数据源与自动降级机制

| 数据模块 | 主数据源 | 备用/补充数据源 |
|---|---|---|
| **实时行情与五档盘口** | 腾讯财经实时行情 (`qt.gtimg.cn`) | 上交所官方快照 (`yunhq.sse.com.cn`，补充上交所 ETF 官方 IOPV/NAV) |
| **前复权日 K 线与周 K 线** | 东方财富历史 K 线 (`push2his.eastmoney.com`，日K `klt=101` / 周K `klt=102`) | 腾讯前复权日K/周K (`web.ifzq.gtimg.cn/appstock/app/fqkline/get`) + 实时精确价修正盘中最新 K 线 |
| **基金基本面与跟踪指数估值** | 天天基金移动端基础信息接口 (`fundmobapi.eastmoney.com/FundMNewApi/FundMNNBasicInformation`) | - |
| **前十大重仓股行情、财务增速与两融** | 天天基金持仓接口 + 东财数据中心财报 (`RPT_LICO_FN_CPD`) / 业绩预告 (`RPT_PUBLIC_OP_PREDICT`) / 两融明细 (`RPTA_WEB_RZRQ_GGMX`) | 腾讯实时行情与日 K 线批量接口（并发计算重仓股实时涨跌、PE/PB、5日/20日收益与 MA20/MA60 状态） |
| **ETF 历史份额与 1/5/20 日申赎趋势** | Tushare `fund_share` 官方每日份额接口 + 腾讯实时份额 | 本地归档 (`data/etf_share_history_{symbol}.json`) |
| **全A两融余额与趋势** | 东方财富数据中心两融汇总 (`RPTA_RZRQ_LSHJ`) | - |
| **A股风格基准与港美股AI全链条** | 腾讯财经批量行情 (`qt.gtimg.cn`，含恒指/恒科/纳指/标普/英伟达/台积电/ASML/美光/CoreWeave/微软等) | - |
| **全A涨跌宽度与成交额峰值缩量率** | 东方财富实时行情 (`push2.eastmoney.com`，沪深涨跌家数与实时成交额) + 历史日K (`push2his`，120日沪深成交额序列与 `<45%` 峰值缩量监测) | `push2delay.eastmoney.com` |
| **亚太股指、宏观利率汇率与大宗商品** | 东方财富历史与实时 K 线 (`push2his.eastmoney.com`，含韩国KOSPI/日经225/费城半导体/美债10Y/中债10Y/美元/离岸人民币/布伦特原油/NYMEX原油/黄金/棕榈油) | 多节点自动轮询 (`33.push2his` / `17.push2his`) |
| **7×24小时快讯与相关新闻资讯** | 东方财富 7×24 全球快讯接口 (`np-weblist.eastmoney.com/comm/web/getFastNewsList`) + 站内文章搜索接口 (`search-api-web.eastmoney.com`) | 内置 ETF 营销软文正则过滤与降权 |
| **知名博主最新专栏与市场复盘** | 雪球专栏与用户原发动态接口 (`statuses/original/timeline.json`、`v4/statuses/user_timeline.json`、`statuses/show.json`) | Cookie 缓存直连 (`data/xueqiu_cookies.json`) + Playwright 无头 Chrome 自动过阿里云 WAF 降级 |

---

## 二、JSON 顶层结构

```json
{
  "collected_at": "2026-10-16 11:06:36",
  "market_phase": "盘中连续竞价时段",
  "market_context": [ ... ],
  "market_breadth_and_volume": { ... },
  "overseas_context": { ... },
  "macro_and_commodities": { ... },
  "global_fast_news": [ ... ],
  "kol_columns": {
    "available": true,
    "config_file": "/media/vdc/stock/.pi/skills/etf-analyzer/data/kol_sources.json",
    "kol_count": 1,
    "kol_list": [
      {
        "id": "2817386050",
        "name": "搬砖小组",
        "platform": "xueqiu",
        "style": "买方投研/全球宏观与产业高频数据日更复盘",
        "profile_url": "https://www.xueqiu.com/u/2817386050",
        "article_count": 2,
        "articles": [
          {
            "id": 412564606,
            "title": "科技又杀一遍。。",
            "published_at": "2026-10-16 10:21:41",
            "url": "https://www.xueqiu.com/2817386050/412564606",
            "view_count": 1146,
            "summary": "...",
            "content": "完整清洗后的纯文本干货正文..."
          }
        ]
      }
    ]
  },
  "etfs": [
    {
      "symbol": "515070",
      "name": "人工智能ETF华夏",
      "secid": "1.515070",
      "analysis_time": "2026-10-15 11:20:00",
      "market_phase": "盘中连续竞价时段",
      "quote": { ... },
      "fund_profile": { ... },
      "technical_summary": { ... },
      "recent_daily_bars": [ ... ],
      "constituents_analysis": { ... },
      "share_flow": { ... },
      "market_context": [ ... ],
      "overseas_context": { ... },
      "news_keywords": [ ... ],
      "news": [ ... ]
    }
  ]
}
```

---

## 三、核心子模块字段说明

### 1. `quote`（实时行情与微观盘口）
- `current_price` / `open_price` / `high_price` / `low_price` / `prev_close`：最新价、今开、最高、最低、昨收。
- `change_amount` / `change_percent`：涨跌额、涨跌幅(%)。
- `avg_price`：日内分时均价 (VWAP)。
- `iopv` / `nav` / `premium_pct`：实时参考单位净值、最新单位净值、实时折溢价率(%)。
- `volume` / `amount` / `turnover_rate` / `volume_ratio` / `amplitude_percent`：成交量(手)、成交额(元)、换手率(%)、量比、振幅(%)。
- `total_market_value` / `float_market_value` / `total_shares`：场内总市值(元)、流通市值(元)、总份额(份)。
- `outer_volume` / `inner_volume` / `active_buy_ratio`：外盘(手)、内盘(手)、主动买盘占比(0~1)。
- `bids` / `asks` / `spread_pct` / `depth_imbalance`：买一至买五、卖一至卖五挂单价格与手数、买卖一档价差率(%)、五档买卖挂单失衡度(-1~+1)。

### 2. `fund_profile` & `index_valuation`（基金档案与指数估值）
- `fund_company` / `establish_date` / `report_scale_yi` / `report_scale_date` / `tracking_error_pct`：基金管理人、成立日、报告期规模(亿元)与截止日、年化跟踪误差(%)。
- `sharpe_1y` / `sharpe_2y` / `sharpe_3y` / `max_drawdown_1y_pct` / `volatility_1y_pct`：近1/2/3年夏普比率、近1年最大回撤(%)、近1年年化波动率(%)。
- `index_valuation`：
  - `index_code` / `index_name` / `valuation_date`：跟踪指数代码、名称、估值日期。
  - `pe_ttm` / `pe_percentile_pct`：指数市盈率(TTM)及历史分位数(%)。
  - `pb` / `pb_percentile_pct`：指数市净率及历史分位数(%)。
  - `dividend_yield_pct` / `roe_pct`：指数股息率(%)、净资产收益率 ROE(%)。
  - `return_1w_pct` / `return_1m_pct` / `return_3m_pct` / `return_6m_pct` / `return_1y_pct` / `return_ytd_pct`：指数各阶段涨跌幅(%)。

### 3. `technical_summary` & `weekly_technical_summary`（日 K 与周 K 技术统计及历史价格分位数）
- **日线指标 (`technical_summary`)**：
  - `MA5` / `MA10` / `MA20` / `MA60` / `MA120` / `MA250` 及 `close_vs_ma*_pct`：各周期移动平均线及当前价偏离百分比。
  - `ma20_slope_5d_pct` / `ma60_slope_10d_pct` / `ma_alignment`：均线斜率与多空排列形态描述。
  - `return_3d_pct` ~ `return_250d_pct`：多周期历史涨跌幅(%)。
  - `range_20d` / `range_60d` / `range_120d` / `range_250d`：窗口最高价、最低价、区间位置(`position_pct`)、收盘历史分位数(`close_percentile_pct`)、回撤与反弹幅度。
  - `rsi14` / `macd` / `atr20` / `pivot_levels` / `key_supports` / `key_resistances`。
- **周线中长期指标 (`weekly_technical_summary`)**：
  - `WMA5` / `WMA10` / `WMA20` / `WMA30` / `WMA60` / `WMA120` 及 `close_vs_wma*_pct`、`wma20_slope_4w_pct`、`weekly_ma_alignment`。
  - `weekly_boll`：20周布林中轨(`mid_wma20`)、上轨(`upper`)、下轨(`lower`)、布林带位置 `%B` (`percent_b`)。
  - `range_13w` / `range_26w` / `range_52w` / `range_104w`：近1季/半年/1年/2年的周最高价(`high`)、周最低价(`low`)、周区间中位价(`mid_price`)、距中位价偏离(`vs_mid_pct`)、周区间位置(`position_pct`)、周收盘分位数(`close_percentile_pct`)。

### 4. `constituents_analysis`（前十大重仓股实时行情、基本面财务增速与两融资金）
- `report_date` / `total_weight_pct` / `up_count` / `down_count` / `weighted_change_pct` / `estimated_top10_contribution_pct` / `above_ma20_weighted_breadth_pct` / `above_ma60_weighted_breadth_pct` / `industry_distribution_pct`。
- `fundamentals_summary`：
  - `weighted_rev_yoy_pct` / `weighted_profit_yoy_pct` / `median_profit_yoy_pct` / `weighted_roe_pct`：前十大重仓股加权营收同比增速(%)、加权及中位数归母净利润同比增速(%)、加权 ROE(%)。
  - `profit_positive_growth_count` / `latest_earnings_forecasts`：归母净利正增长家数、最新三季报/年报业绩预告速递。
- `margin_summary`：
  - `etf_margin`：ETF 自身融资余额(亿元)、1日/3日/5日/10日融资净买入(亿元)、融券余额(亿元)。
  - `top10_total_fin_balance_yi` / `top10_fin_net_buy_1d_yi` / `top10_fin_net_buy_5d_yi` / `top10_fin_net_buy_10d_yi`：前十大重仓股合计融资余额与 1日/5日/10日合计融资净买入(亿元)。
- `constituents`：每只重仓股的行情、均线状态及 `pe_ttm`、`pb`、`peg`、`report_period`、`rev_yoy_pct`、`profit_yoy_pct`、`roe_pct`、`latest_earnings_forecast`、`fin_balance_yi`、`fin_net_buy_1d_yi`、`fin_net_buy_5d_yi`。

### 5. `share_flow`（ETF 近 1日 / 5日 / 20日 份额变化趋势）
- `shares_yi` / `market_value_yi` / `share_percentile_20d_pct` / `status` / `trend_5d_20d_summary`。
- `change_1d` / `change_5d` / `change_20d`：分别包含基准日期(`base_date`)、基准份额(`base_shares_yi`)、份额变化率(`share_change_pct`)、净申赎份额(`net_shares_yi`)、估算净申赎金额(`net_amount_yi`)，其中 `change_5d` 含近5日净申购天数(`inflow_days`)与净赎回天数(`outflow_days`)。
- `recent_share_series`：最近 10 个交易日的每日份额与价格明细序列。
