---
name: etf-analyzer
description: >
  获取指定场内 ETF 的全方位客观市场信息（实时行情、分时均价VWAP、实时IOPV与单位净值NAV、折溢价率、五档盘口、
  场内规模与近1日/5日/20日份额申赎变化趋势、ETF自身两融数据、基金基本面档案、跟踪指数估值 PE/PB/历史分位数/股息率/ROE/相对10年期国债利差与ERP、
  前复权日K与周K中长期技术指标 MA/WMA/周布林带BOLL/MACD/RSI/ATR、近1月~2年日线与周线价格分位数与枢轴点位、
  前十大重仓成分股清单及实时涨跌/基本面财务增速(营收同比/归母净利同比/ROE/PE/PB/最新业绩预告)/两融资金流向、
  全A市场涨跌宽度与总成交额峰值缩量率(<45%阶段低点监测)、全A两融余额与连增连降趋势、亚太与欧美跨市场行情(含韩国KOSPI/日经225/恒科/费城半导体/CoreWeave/美光等)、
  全球宏观利率汇率与能源大宗商品底座(美债10Y/中债10Y/美元/离岸人民币/原油/黄金/棕榈油)、7×24小时全球宏观产业硬核快讯与去软文提纯后的东方财富相关新闻），
  并同步抓取可配置的知名博主（默认含雪球“搬砖小组”等，支持随时扩展）最新专栏与市场复盘全文作为实时主观参考数据。
  当用户需要查询 ETF 信息、获取客观盘面数据与知名博主最新复盘作为投资建议依据时使用。
---

# ETF Analyzer — 场内 ETF 全维客观信息获取工具

本 Skill 参考 `/media/vdb/PycharmProjects/pythonProject/stock/backtest_today.py` 中获取 ETF 股票信息的代码构建，整合**东方财富**、**天天基金 F10**、**腾讯财经**与**上交所官方快照**接口（内置多源自动降级与代理 SSL 容错）。

**职责边界**：本 Skill **仅用于客观信息采集与历史统计指标计算，本身不含任何预测模块或主观交易结论生成**。采集到的结构化 JSON 与 Markdown 事实材料供上层 Agent 进一步分析并为用户提供投资建议。

---

## 获取的客观信息维度

1. **实时行情、折溢价与微观盘口 (`quote`)**：
   - 最新价、涨跌额、涨跌幅(%)、今开、最高、最低、昨收、分时均价(VWAP)、52周最高/最低价、涨跌停价。
   - 成交量(手)、成交额(元/亿元)、量比、换手率(%)、振幅(%)、外盘/内盘及主动买盘占比。
   - 实时参考净值 (**IOPV**)、最新单位净值 (**NAV**)、**实时折溢价率 (%)**。
   - 买一至买五、卖一至卖五挂单价量、买卖价差 (`spread_pct`)、盘口深度失衡度 (`depth_imbalance`)。
2. **基金基本面档案与跟踪指数估值 (`fund_profile` & `index_valuation`)**：
   - 基金简称、类型、基金公司、成立日期、最新报告期规模(亿元)与日期、年化跟踪误差、风险等级。
   - 近 1/2/3 年夏普比率、近 1 年最大回撤(%)、近 1 年年化波动率(%)、近 1/2/3 年历史定投收益率。
   - **跟踪指数客观估值数据**：指数名称与代码、估值日期、**PE(TTM) 及历史分位数(%)**、**PB 及历史分位数(%)**、**股息率(%)及较中债10Y溢价**、**ROE(%)**、**盈利收益率(E/P)及股权风险溢价(ERP)**、指数各阶段收益率（近1周/1月/3月/半年/1年/今年以来）及指数编制简介。
3. **前复权日 K 线与周 K 线中长期技术指标及历史价格分位数 (`technical_summary` & `weekly_technical_summary`)**：
   - **日 K 线系统**：前复权日 K 线（东方财富 `push2his` 与腾讯 `fqkline` 自动降级互备，盘中用精确实时报价修正最新 K 线）；`MA5`~`MA250` 数值与偏离率、均线斜率与排列、近 3日~250日阶段涨跌幅、日线 `RSI(14)` / `MACD` / `20日ATR`、近 1月/3月/半年/1年区间位置与收盘分位数、枢轴点支撑压力位。
   - **周 K 线中长期系统 (`weekly_technical_summary`)**：
     - 前复权周 K 线（`WMA5`、`WMA10`、`WMA20`、`WMA30`、`WMA60`、`WMA120` 及偏离率、`WMA20` 4周斜率、周线均线排列）；
     - 周线阶段涨跌幅（近 1周、2周、4周、13周、26周、52周、104周）；
     - 周线布林带 `BOLL(20, 2)`（中轨 `WMA20`、上轨、下轨、布林位置 `%B`）、周线 `RSI(14)`、周线 `MACD`、14周 `ATR`；
     - 近 1季(13周)、近半年(26周)、近 1年(52周)、近 2年(104周) 的周最高价、周最低价、周区间中位价 (`mid_price`)、周区间位置 (`position_pct`) 与周收盘历史分位数 (`close_percentile_pct`)。
4. **前十大重仓成分股实时行情、基本面财务增速/业绩预告与两融资金 (`constituents_analysis`)**：
   - 最新披露的前十大重仓股（代码、名称、占净值比、较上期增减持变化、所属行业、披露报告期）。
   - 10 只重仓股的实时行情与近期日 K 统计：最新价、今日涨跌幅、涨跌贡献度、近 5 日/20 日涨跌幅、是否高于 MA20/MA60。
   - **重仓股基本面财务增速与估值 (`fundamentals_summary`)**：每只重仓股的 `PE(TTM)`、`PB`、`PEG`、最新财报期**营收同比增速(`rev_yoy_pct`)**、**归母净利润同比增速(`profit_yoy_pct`)**、**ROE(`roe_pct`)**、**最新三季报/年报业绩预告(`latest_earnings_forecast`)**，以及前十重仓股加权营收增速、加权/中位数净利增速与加权 ROE。
   - **ETF 自身与重仓股两融杠杆资金 (`margin_summary`)**：ETF 自身及每只重仓股的最新融资余额(亿元)、1日/3日/5日/10日融资净买入(亿元)，以及前十大重仓股合计融资余额与 1日/5日/10日合计融资净买入。
5. **ETF 规模与近 1日 / 5日 / 20日 份额申赎趋势 (`share_flow`)**：
   - 自动拉取官方历史场内份额序列并归档至 `data/etf_share_history_{symbol}.json`，精确计算**较前1日(1D)、近5日(5D)、近20日(20D)** 的份额变化率(%)、累计净申赎份额(亿份)、估算净申赎规模(亿元)、近5日净申购/净赎回天数及中短期资金申赎趋势定性。
6. **全A量能缩量择时指标、全A两融趋势、跨市场全球宏观商品底座与 7×24 硬核资讯 (`market_breadth_and_volume` / `market_margin_context` / `overseas_context` / `macro_and_commodities` / `global_fast_news` / `news`)**：
   - **A股市场基准、宽度量能与全A两融 (`market_context` / `market_breadth_and_volume` / `market_margin_context`)**：核心宽基实时行情；沪深实时涨跌家数宽度；**全A总成交额相对60日/120日峰值的缩量比率及 `<45%` 阶段低点监测**；**全A(沪深京)两融总余额、1日/3日/5日/10日/20日融资净买入及连增/连降天数**。
   - **亚太与海外AI全链条风向标 (`overseas_context` & `macro_and_commodities`)**：韩国KOSPI、日经225、恒生指数、恒生科技、费城半导体、纳斯达克、标普500，以及英伟达、AMD、博通、台积电、阿斯麦(ASML)、美光科技(MU)、CoreWeave(CRWV，海外算力租赁与信用风向标)、微软、苹果、特斯拉。
   - **全球宏观利率、汇率与大宗商品底座 (`macro_and_commodities`)**：美国10年期国债收益率(`US10Y`)、中国10年期国债收益率(`CN10Y`)、美元指数(`DXY`)、离岸人民币(`USD/CNH`)、布伦特原油、NYMEX原油、COMEX黄金、棕榈油连续（最新值、今日涨跌、前日涨跌、近5日涨跌）。
   - **7×24小时全球宏观产业快讯与去软文个股新闻 (`global_fast_news` & `news`)**：东方财富7×24小时全球焦点/国际宏观电报流（自动剔除ETF营销软文），以及按ETF重仓股与主题词检索并降权营销软文后的高相关性新闻。
7. **实时主观参考：知名博主最新专栏与市场复盘 (`kol_columns`)**：
   - 自动读取 `data/kol_sources.json` 中的知名投研博主列表（默认内置雪球买方投研博主 **“搬砖小组”** `2817386050`，支持通过配置文件或 `--add-kol` 无限扩展更多博主）。
   - 内置 **“Cookie 缓存极速直连 (`0.3s`) + Playwright 无头 Chrome 自动过阿里云 WAF 降级 (`3.5s`)”** 双层引擎，自动抓取每位博主最新 N 篇专栏/长帖全文，并清洗 HTML 标签与底部免责套话，作为与实时客观盘面交叉验证的实时主观参考源。

---

## 快速调用指南 (CLI)

通过 `bash` 工具执行 `scripts/etf_analyzer.py`：

```bash
# 1. 获取指定一只或多只 ETF 的全维客观信息 + 知名博主最新专栏复盘
python3 /media/vdc/stock/.pi/skills/etf-analyzer/scripts/etf_analyzer.py --symbols 515070 159338

# 2. 获取默认 ETF 列表（159338, 515070, 159611, 515180）及默认博主（搬砖小组等）最新专栏
python3 /media/vdc/stock/.pi/skills/etf-analyzer/scripts/etf_analyzer.py

# 3. 永久添加新的雪球知名博主到 data/kol_sources.json（后续每次运行都会自动抓取）
python3 /media/vdc/stock/.pi/skills/etf-analyzer/scripts/etf_analyzer.py \
  --add-kol "https://www.xueqiu.com/u/2817386050" "搬砖小组" "买方投研/全球宏观与产业高频数据日更复盘"

# 4. 临时追加抓取指定博主或调整每位博主的抓取篇数
python3 /media/vdc/stock/.pi/skills/etf-analyzer/scripts/etf_analyzer.py \
  --symbols 515070 \
  --kol-users 2817386050 \
  --kol-limit 3

# 5. 仅在终端输出 JSON 结构化数据
python3 /media/vdc/stock/.pi/skills/etf-analyzer/scripts/etf_analyzer.py --symbols 159338 --json-only
```

### CLI 参数说明

| 参数 | 默认值 | 说明 |
|---|---|---|
| `--symbols` | `159338 515070 159611 515180` | ETF 代码，支持 6 位代码（如 `515070`）或东方财富 `secid`（如 `1.515070`） |
| `--news-days` | `3` | 东方财富新闻回看天数 |
| `--news-limit` | `15` | 每只 ETF 最多返回的相关新闻条数 |
| `--kline-limit` | `260` | 前复权日 K 线回看根数（默认 260，约 1 年交易日） |
| `--keywords` | 空 | 追加自定义东方财富新闻检索关键词 |
| `--kol-users` | 空（读取 `data/kol_sources.json`） | 临时追加要抓取的雪球博主 UID 或主页/专栏 URL |
| `--kol-limit` | `2` | 每位知名博主抓取的最新专栏/长文篇数 |
| `--no-kol` | `False` | 跳过知名博主最新专栏抓取 |
| `--add-kol` | 空 | 永久添加新博主到 `data/kol_sources.json`，格式：`--add-kol <UID或URL> [博主名称] [风格备注]` |
| `--output-dir` | `outputs` | Markdown 汇总报告与 JSON 数据文件保存目录 |
| `--json-only` | `False` | 终端仅输出 JSON 格式数据 |
| `--log-level` | `WARNING` | 日志级别 |

---

## 输出文件与字段字典

每次运行默认在 `--output-dir`（默认 `outputs/`）下生成：
- `etf_info_<代码>_<时间戳>.md`：结构化 Markdown 客观数据汇总表。
- `etf_info_<代码>_<时间戳>.json`：完整 JSON 原始数据包。

详细 JSON 字段结构与数据来源说明请参见 [references/data_fields.md](references/data_fields.md)。
