#!/usr/bin/env python3
"""ETF 全维客观信息获取脚本 (etf-analyzer)。

参考 /media/vdb/PycharmProjects/pythonProject/stock/backtest_today.py 中获取 ETF 股票信息的代码构建，
整合东方财富、天天基金F10、腾讯财经与上交所官方快照接口（支持多源自动降级与代理SSL容错），
纯粹用于获取指定 ETF 的客观市场数据（不含预测模块）：
1. 实时行情、分时均价(VWAP)、实时IOPV、单位净值(NAV)、折溢价率与五档买卖盘口；
2. 基金基本面档案与跟踪指数估值（PE/PB及历史分位数、股息率、ROE、阶段收益、夏普比率、最大回撤）；
3. 前复权日K线、均线系统(MA5~MA250)、MACD/RSI/ATR、近1月/3月/半年/1年价格分位数与枢轴点位；
4. 前十大重仓成分股清单、实时行情、涨跌贡献度、近5日/20日表现与MA20/MA60均线广度；
5. ETF 场内总市值、总份额及历史份额归档对比；
6. A股核心宽基/风格指数基准与海外隔夜关联市场行情；
7. 东方财富按主题词与重仓股检索的最新相关新闻列表。
"""

from __future__ import annotations

import argparse
import html
import json
import logging
import math
import re
import sys
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path
from statistics import mean, pstdev
from typing import Any, Iterable
from urllib.parse import urlencode

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore")

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent

DEFAULT_SYMBOLS = ("159338", "515070", "159611", "515180")
EASTMONEY_BASE = "https://push2.eastmoney.com/api/qt"
EASTMONEY_DELAY_BASE = "https://push2delay.eastmoney.com/api/qt"
EASTMONEY_HISTORY_BASES = (
    "https://push2his.eastmoney.com/api/qt",
    "https://33.push2his.eastmoney.com/api/qt",
    "https://17.push2his.eastmoney.com/api/qt",
)
EASTMONEY_SEARCH_URL = "https://search-api-web.eastmoney.com/search/jsonp"
EASTMONEY_FAST_NEWS_URL = "https://np-weblist.eastmoney.com/comm/web/getFastNewsList"
FUND_MOB_BASE = "https://fundmobapi.eastmoney.com/FundMNewApi"
TENCENT_QUOTE_URL = "https://qt.gtimg.cn/q="
TENCENT_KLINE_URL = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"
SSE_SNAPSHOT_URL = "https://yunhq.sse.com.cn:32042/v1/sh1/snap/{symbol}"

REQUEST_TIMEOUT = 12
DEFAULT_NEWS_DAYS = 3
DEFAULT_NEWS_LIMIT = 15
DEFAULT_KLINE_LIMIT = 260
DEFAULT_WEEKLY_KLINE_LIMIT = 130
ETF_SHARE_CHANGE_SUSPECT_PCT = 25.0
EASTMONEY_DATACENTER_URL = "https://datacenter-web.eastmoney.com/api/data/v1/get"
TUSHARE_API_URL = "http://api.tushare.pro"
DEFAULT_TUSHARE_TOKEN = "401b133258e6f9fcac8a50437359abad5d0b2f95a15179a50b956f1c"

THEME_PRESETS: dict[str, dict[str, tuple[str, ...]]] = {
    "宽基A500": {
        "triggers": ("a500", "沪深300", "中证500", "中证1000", "上证50", "创业板", "科创50", "宽基"),
        "keywords": (
            "中证A500 ETF", "A股 核心资产 资金", "宽基ETF 净申购", "央行 降准 降息 货币政策",
            "财政政策 稳增长", "外资 北向 A股", "新质生产力 龙头股",
        ),
    },
    "人工智能": {
        "triggers": ("人工智能", "ai", "算力", "通信", "软件", "云计算", "大数据", "信创"),
        "keywords": (
            "人工智能ETF", "AI算力 大模型", "CPO 光模块", "国产AI芯片 寒武纪 海光",
            "美国科技股 纳斯达克", "英伟达 AI芯片", "存储芯片 HBM", "算力中心 服务器",
        ),
    },
    "半导体": {
        "triggers": ("半导体", "芯片", "集成电路", "科创芯片", "电子"),
        "keywords": (
            "半导体ETF", "国产芯片 自主可控", "晶圆 先进制程", "存储芯片 HBM",
            "费城半导体", "英伟达 AMD 博通", "半导体设备 光刻", "美国芯片 出口管制",
        ),
    },
    "电力公用": {
        "triggers": ("电力", "绿电", "公用事业", "能源", "电网", "特高压", "核电", "水电"),
        "keywords": (
            "电力ETF", "新型电力系统 电网投资", "特高压 算力电力", "水电 核电 火电 电价",
            "长江电力 中国核电", "绿电 碳中和", "用电量 迎峰度夏 迎峰度冬",
        ),
    },
    "红利高股息": {
        "triggers": ("红利", "高股息", "央企", "国企", "价值", "低波"),
        "keywords": (
            "红利ETF", "高股息 分红", "央企市值管理 国企改革", "险资 长期资金 举牌",
            "银行 煤炭 航运 股息率", "无风险利率 国债收益率",
        ),
    },
    "机器人": {
        "triggers": ("机器人", "智能制造", "自动化", "机床"),
        "keywords": ("机器人ETF", "人形机器人", "特斯拉 擎天柱", "减速器 丝杠 传感器", "具身智能"),
    },
    "新能源": {
        "triggers": ("新能源", "光伏", "锂电", "电池", "汽车", "储能", "风电"),
        "keywords": ("新能源ETF", "新能源汽车 销量", "锂电池 固态电池", "光伏 储能 逆变器", "碳酸锂"),
    },
    "医药医疗": {
        "triggers": ("医药", "医疗", "创新药", "生物", "中药", "恒生医疗"),
        "keywords": ("医药ETF", "创新药 临床 获批", "医疗器械 集采", "医保谈判 政策", "CXO 出海"),
    },
    "军工航天": {
        "triggers": ("军工", "国防", "航空", "航天", "卫星", "低空"),
        "keywords": ("军工ETF", "商业航天 卫星互联网", "国防军工 订单", "大飞机 低空经济"),
    },
    "金融券商": {
        "triggers": ("证券", "券商", "银行", "金融", "保险"),
        "keywords": ("证券ETF", "券商 并购 业绩", "银行 净息差", "资本市场政策 两融 成交额"),
    },
    "消费周期": {
        "triggers": ("消费", "白酒", "食品", "家电", "有色", "黄金", "煤炭", "化工"),
        "keywords": ("促消费 补贴 社零", "有色金属 黄金 铜价", "大宗商品 涨价"),
    },
}

MARKET_REFERENCES = {
    "上证指数": ("1.000001", "sh000001"),
    "沪深300": ("1.000300", "sh000300"),
    "中证A500": ("1.000510", "sh000510"),
    "中证500": ("1.000905", "sh000905"),
    "创业板指": ("0.399006", "sz399006"),
    "科创50": ("1.000688", "sh000688"),
    "中证红利": ("1.000922", "sh000922"),
}

OVERSEAS_REFERENCES = {
    "hsi": ("hkHSI", "恒生指数"),
    "hstech": ("hkHSTECH", "恒生科技"),
    "nasdaq": ("us.IXIC", "纳斯达克"),
    "sp500": ("us.INX", "标普500"),
    "nvidia": ("usNVDA", "英伟达"),
    "amd": ("usAMD", "AMD"),
    "broadcom": ("usAVGO", "博通"),
    "tsmc": ("usTSM", "台积电"),
    "asml": ("usASML", "阿斯麦"),
    "micron": ("usMU", "美光科技"),
    "coreweave": ("usCRWV", "CoreWeave"),
    "microsoft": ("usMSFT", "微软"),
    "apple": ("usAAPL", "苹果"),
    "tesla": ("usTSLA", "特斯拉"),
}

GLOBAL_MACRO_TARGETS: dict[str, tuple[str, str, str]] = {
    "kospi": ("100.KS11", "韩国KOSPI", "asia_index"),
    "nikkei225": ("100.N225", "日经225", "asia_index"),
    "phlx_sox": ("251.SOX", "费城半导体", "us_index"),
    "us10y": ("171.US10Y", "美债10年收益率(%)", "rate_fx"),
    "cn10y": ("171.CN10Y", "中债10年收益率(%)", "rate_fx"),
    "dxy": ("100.UDI", "美元指数", "rate_fx"),
    "usdcnh": ("133.USDCNH", "离岸人民币(USD/CNH)", "rate_fx"),
    "brent_oil": ("112.B00Y", "布伦特原油", "commodity"),
    "wti_oil": ("102.CL00Y", "NYMEX原油", "commodity"),
    "comex_gold": ("101.GC00Y", "COMEX黄金", "commodity"),
    "palm_oil": ("110.MPM00Y", "棕榈油连续", "commodity"),
}

ETF_SOFT_AD_RE = re.compile(
    r"(ETF|联接).*?(净流入|净申购|备受关注|配置价值|布局机遇|蓄势|吸金|反包|交投活跃|迎布局|一键布局|掘金)"
    r"|(资金抢筹|越跌越买).*?ETF",
    re.I,
)


@dataclass
class DailyBar:
    date: str
    open: float | None
    close: float | None
    high: float | None
    low: float | None
    volume: float | None
    amount: float | None
    amplitude_percent: float | None
    change_percent: float | None
    change_amount: float | None
    turnover_rate: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Quote:
    symbol: str
    name: str
    market: int
    secid: str
    collected_at: str
    quote_time: str | None
    current_price: float | None
    change_amount: float | None
    change_percent: float | None
    avg_price: float | None
    volume: float | None
    amount: float | None
    volume_ratio: float | None
    high_price: float | None
    low_price: float | None
    open_price: float | None
    prev_close: float | None
    turnover_rate: float | None
    amplitude_percent: float | None
    upper_limit: float | None = None
    lower_limit: float | None = None
    high_52w: float | None = None
    low_52w: float | None = None
    iopv: float | None = None
    nav: float | None = None
    premium_pct: float | None = None
    total_market_value: float | None = None
    float_market_value: float | None = None
    total_shares: float | None = None
    outer_volume: float | None = None
    inner_volume: float | None = None
    active_buy_ratio: float | None = None
    bid1_price: float | None = None
    ask1_price: float | None = None
    bid1_volume: float | None = None
    ask1_volume: float | None = None
    spread_pct: float | None = None
    depth_imbalance: float | None = None
    bids: list[dict[str, float]] | None = None
    asks: list[dict[str, float]] | None = None
    pe_ttm: float | None = None
    pe_dynamic: float | None = None
    pb: float | None = None
    source: str = "Tencent/Eastmoney"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _session() -> requests.Session:
    session = requests.Session()
    session.verify = False
    session.headers.update(
        {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125 Safari/537.36"
            )
        }
    )
    return session


def _num(value: Any) -> float | None:
    if value in (None, "", "-", "--") or isinstance(value, bool):
        return None
    if isinstance(value, str):
        cleaned = value.strip().replace(",", "").replace("%", "")
        if not cleaned or cleaned in ("-", "--"):
            return None
        value = cleaned
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _round(value: float | None, digits: int = 4) -> float | None:
    return round(value, digits) if value is not None and math.isfinite(value) else None


def _pct_change(current: float | None, base: float | None, digits: int = 2) -> float | None:
    if current is None or base in (None, 0):
        return None
    return round((current / base - 1.0) * 100.0, digits)


def _clean_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _strip_html(value: Any) -> str:
    return _clean_text(html.unescape(re.sub(r"<[^>]+>", " ", str(value or ""))))


def split_symbol_values(values: Iterable[str]) -> list[str]:
    """解析空格、逗号分隔和误粘连的多个六位证券代码。"""
    result: list[str] = []
    for value in values:
        for item in re.split(r"[,;，；\s]+", str(value)):
            item = item.strip()
            if not item:
                continue
            item_clean = re.sub(r"^(?:sh|sz|bj)", "", item, flags=re.I)
            if item_clean.isdigit() and len(item_clean) > 6 and len(item_clean) % 6 == 0:
                result.extend(item_clean[i : i + 6] for i in range(0, len(item_clean), 6))
            else:
                result.append(item)
    if not result:
        raise ValueError("请提供至少一个 6 位 ETF 代码，例如 515070 或 159338")
    return list(dict.fromkeys(result))


def symbol_to_secid(raw: str) -> tuple[str, str, str]:
    """返回 (secid, tencent_code, pure_symbol)。"""
    text = raw.strip()
    if re.fullmatch(r"[01]\.\d{6}", text):
        market, sym = text.split(".", 1)
        prefix = "sh" if market == "1" else "sz"
        return text, f"{prefix}{sym}", sym
    m = re.fullmatch(r"(sh|sz|bj)(\d{6})", text, flags=re.I)
    if m:
        prefix, sym = m.group(1).lower(), m.group(2)
        market = "1" if prefix == "sh" else "0"
        return f"{market}.{sym}", f"{prefix}{sym}", sym
    sym = re.sub(r"\D", "", text)
    if len(sym) != 6:
        raise ValueError(f"无效的证券代码: {raw}（应为6位数字，如 515070、159338）")
    if sym.startswith(("5", "6", "9")):
        return f"1.{sym}", f"sh{sym}", sym
    if sym.startswith(("4", "8")):
        return f"0.{sym}", f"bj{sym}", sym
    return f"0.{sym}", f"sz{sym}", sym


# ============================================================================
# 1. 实时行情、IOPV 折溢价与五档盘口（腾讯 + 东方财富 + 上交所官方互备）
# ============================================================================


def fetch_tencent_quotes(codes: Iterable[str]) -> dict[str, Quote]:
    """批量请求腾讯行情接口 qt.gtimg.cn，支持 ETF、A股股票、指数、美股。"""
    code_list = [c for c in dict.fromkeys(codes) if c]
    if not code_list:
        return {}
    session = _session()
    result: dict[str, Quote] = {}
    for start in range(0, len(code_list), 45):
        batch = code_list[start : start + 45]
        url = TENCENT_QUOTE_URL + ",".join(batch)
        resp = session.get(url, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        text = resp.content.decode("gbk", errors="replace")
        for line in text.split(";"):
            line = line.strip()
            if "=" not in line:
                continue
            key, val = line.split("=", 1)
            t_code = key.strip().removeprefix("v_")
            parts = val.strip().strip('"').split("~")
            if len(parts) < 35 or not parts[1]:
                continue
            quote = _parse_tencent_quote_parts(t_code, parts)
            result[t_code] = quote
            result[quote.symbol] = quote
    return result


def _parse_tencent_quote_parts(t_code: str, parts: list[str]) -> Quote:
    def p(idx: int) -> str:
        return parts[idx].strip() if idx < len(parts) else ""

    is_us = t_code.startswith(("us", "hk"))
    symbol = p(2) or t_code.removeprefix("sh").removeprefix("sz").removeprefix("us").removeprefix("hk")
    name = p(1)
    market = 1 if t_code.startswith("sh") else 0
    secid = f"{market}.{symbol}" if not is_us else t_code

    current_price = _num(p(3))
    prev_close = _num(p(4))
    open_price = _num(p(5))
    volume = _num(p(6))
    outer_vol = _num(p(7))
    inner_vol = _num(p(8))

    bids: list[dict[str, float]] = []
    asks: list[dict[str, float]] = []
    if not is_us:
        for i in range(5):
            bp, bv = _num(p(9 + i * 2)), _num(p(10 + i * 2))
            if bp is not None and bp > 0 and bv is not None:
                bids.append({"price": bp, "volume": bv})
            ap, av = _num(p(19 + i * 2)), _num(p(20 + i * 2))
            if ap is not None and ap > 0 and av is not None:
                asks.append({"price": ap, "volume": av})

    raw_time = p(30)
    if re.fullmatch(r"\d{14}", raw_time):
        quote_time = (
            f"{raw_time[:4]}-{raw_time[4:6]}-{raw_time[6:8]} "
            f"{raw_time[8:10]}:{raw_time[10:12]}:{raw_time[12:14]}"
        )
    else:
        quote_time = raw_time or None

    change_amount = _num(p(31))
    change_percent = _num(p(32))
    high_price = _num(p(33))
    low_price = _num(p(34))

    amount: float | None = None
    p35 = p(35)
    if "/" in p35:
        seg = p35.split("/")
        if len(seg) >= 3:
            amount = _num(seg[2])
    if amount is None:
        amt_wan = _num(p(57)) if not is_us else None
        if amt_wan is None:
            amt_wan = _num(p(37))
        if amt_wan is not None:
            amount = amt_wan * 10000.0 if not is_us else amt_wan

    turnover_rate = _num(p(38))
    pe_ttm = _num(p(39)) if not is_us else None
    amplitude_percent = _num(p(43))
    float_mv_yi = _num(p(44))
    total_mv_yi = _num(p(45))
    pb = _num(p(46)) if not is_us else None
    float_mv = float_mv_yi * 1e8 if float_mv_yi is not None and not is_us else None
    total_mv = total_mv_yi * 1e8 if total_mv_yi is not None and not is_us else None

    upper_limit = _num(p(47)) if not is_us else None
    lower_limit = _num(p(48)) if not is_us else None
    volume_ratio = _num(p(49)) if not is_us else None
    avg_price = _num(p(51)) if not is_us else None
    pe_dynamic = _num(p(52)) if not is_us else None
    high_52w = _num(p(67)) if not is_us else _num(p(48))
    low_52w = _num(p(68)) if not is_us else _num(p(49))
    total_shares = _num(p(72)) if not is_us else None
    premium_pct = _num(p(77)) if not is_us else None
    iopv = _num(p(78)) if not is_us else None
    nav = _num(p(81)) if not is_us else None

    if iopv is not None and current_price is not None and premium_pct is None and iopv > 0:
        premium_pct = _pct_change(current_price, iopv, digits=3)

    active_buy_ratio = None
    if outer_vol is not None and inner_vol is not None and (outer_vol + inner_vol) > 0:
        active_buy_ratio = round(outer_vol / (outer_vol + inner_vol), 4)

    bid1_price = bids[0]["price"] if bids else None
    bid1_vol = bids[0]["volume"] if bids else None
    ask1_price = asks[0]["price"] if asks else None
    ask1_vol = asks[0]["volume"] if asks else None
    spread_pct = None
    if bid1_price and ask1_price and bid1_price > 0:
        spread_pct = round((ask1_price - bid1_price) / ((ask1_price + bid1_price) / 2) * 100, 4)

    depth_imbalance = None
    bid_sum = sum(x["volume"] for x in bids)
    ask_sum = sum(x["volume"] for x in asks)
    if (bid_sum + ask_sum) > 0:
        depth_imbalance = round((bid_sum - ask_sum) / (bid_sum + ask_sum), 4)

    return Quote(
        symbol=symbol,
        name=name,
        market=market,
        secid=secid,
        collected_at=datetime.now().isoformat(timespec="seconds"),
        quote_time=quote_time,
        current_price=current_price,
        change_amount=change_amount,
        change_percent=change_percent,
        avg_price=avg_price,
        volume=volume,
        amount=amount,
        volume_ratio=volume_ratio,
        high_price=high_price,
        low_price=low_price,
        open_price=open_price,
        prev_close=prev_close,
        turnover_rate=turnover_rate,
        amplitude_percent=amplitude_percent,
        upper_limit=upper_limit,
        lower_limit=lower_limit,
        high_52w=high_52w,
        low_52w=low_52w,
        iopv=iopv,
        nav=nav,
        premium_pct=premium_pct,
        total_market_value=total_mv,
        float_market_value=float_mv,
        total_shares=total_shares,
        outer_volume=outer_vol,
        inner_volume=inner_vol,
        active_buy_ratio=active_buy_ratio,
        bid1_price=bid1_price,
        ask1_price=ask1_price,
        bid1_volume=bid1_vol,
        ask1_volume=ask1_vol,
        spread_pct=spread_pct,
        depth_imbalance=depth_imbalance,
        bids=bids,
        asks=asks,
        pe_ttm=pe_ttm,
        pe_dynamic=pe_dynamic,
        pb=pb,
        source="Tencent realtime",
    )


def enrich_with_sse_snapshot(quote: Quote) -> Quote:
    """对上交所 ETF 补充上交所官方快照 IOPV/NAV 与五档盘口校验。"""
    if quote.market != 1 or not quote.symbol.startswith(("51", "56", "58")):
        return quote
    try:
        session = _session()
        resp = session.get(
            SSE_SNAPSHOT_URL.format(symbol=quote.symbol),
            params={"select": "name,last,prev_close,nav,iopv,volume,amount,bid,ask"},
            headers={"Referer": "https://www.sse.com.cn/"},
            timeout=6,
        )
        resp.raise_for_status()
        snap = (resp.json() or {}).get("snap") or []
        if len(snap) >= 9:
            sse_iopv = _num(snap[4])
            sse_nav = _num(snap[3])
            if sse_iopv and sse_iopv > 0:
                quote.iopv = sse_iopv
                if quote.current_price:
                    quote.premium_pct = _pct_change(quote.current_price, sse_iopv, digits=3)
            if sse_nav and sse_nav > 0 and not quote.nav:
                quote.nav = sse_nav
            quote.source = "Tencent + SSE Official"
    except Exception as exc:
        logging.debug("上交所官方快照补充跳过 (%s): %s", quote.symbol, exc)
    return quote


def resolve_security(raw_symbol: str) -> tuple[str, Quote]:
    """解析证券代码并获取实时行情，自动在沪深市场间容错确认。"""
    secid, t_code, sym = symbol_to_secid(raw_symbol)
    alt_t_code = f"sz{sym}" if t_code.startswith("sh") else f"sh{sym}"
    quotes = fetch_tencent_quotes([t_code, alt_t_code])
    for candidate in (t_code, alt_t_code):
        q = quotes.get(candidate)
        if q and q.symbol == sym and (q.name or q.current_price is not None):
            q = enrich_with_sse_snapshot(q)
            return q.secid, q
    raise RuntimeError(f"未能获取到证券 {raw_symbol} 的有效实时行情")


# ============================================================================
# 2. 前复权日K线、技术指标体系与中长期价格分位数
# ============================================================================


def fetch_daily_bars(secid: str, *, limit: int = DEFAULT_KLINE_LIMIT, quote: Quote | None = None) -> list[DailyBar]:
    """获取前复权日K线（东方财富与腾讯前复权日K自动互备，并用实时精确价修正盘中最新K线）。"""
    bars: list[DailyBar] = []
    session = _session()
    params = {
        "secid": secid,
        "klt": "101",
        "fqt": "1",
        "lmt": str(limit),
        "end": "20500101",
        "iscca": "1",
        "fields1": "f1,f2,f3,f4,f5,f6",
        "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
        "ut": "fa5fd1943c7b386f172d6893dbfba10b",
    }
    for base in EASTMONEY_HISTORY_BASES:
        try:
            resp = session.get(
                f"{base}/stock/kline/get",
                params=params,
                headers={"Referer": "https://quote.eastmoney.com/"},
                timeout=6,
            )
            if resp.status_code == 200:
                klines = ((resp.json().get("data") or {}).get("klines")) or []
                if klines:
                    for item in klines:
                        parts = str(item).split(",")
                        if len(parts) >= 11:
                            bars.append(
                                DailyBar(
                                    date=parts[0],
                                    open=_num(parts[1]),
                                    close=_num(parts[2]),
                                    high=_num(parts[3]),
                                    low=_num(parts[4]),
                                    volume=_num(parts[5]),
                                    amount=_num(parts[6]),
                                    amplitude_percent=_num(parts[7]),
                                    change_percent=_num(parts[8]),
                                    change_amount=_num(parts[9]),
                                    turnover_rate=_num(parts[10]),
                                )
                            )
                    break
        except Exception:
            continue

    if not bars:
        market, symbol = secid.split(".", 1)
        code = ("sh" if market == "1" else "sz") + symbol
        resp = session.get(
            TENCENT_KLINE_URL,
            params={"param": f"{code},day,,,{limit},qfq"},
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        node = ((resp.json().get("data") or {}).get(code)) or {}
        rows = node.get("qfqday") or node.get("day") or []
        bars = _parse_tencent_daily_rows(rows)

    if not bars:
        raise RuntimeError(f"未取得 {secid} 的可用日K线")

    # 若腾讯日K最后一条是今日盘中数据（有时仅保留2位小数），用实时报价的3位小数精确值修正
    if quote and quote.quote_time and bars:
        q_date = quote.quote_time[:10]
        if bars[-1].date == q_date and quote.current_price is not None:
            prev_close = bars[-2].close if len(bars) >= 2 else quote.prev_close
            bars[-1] = DailyBar(
                date=q_date,
                open=quote.open_price or bars[-1].open,
                close=quote.current_price,
                high=quote.high_price or bars[-1].high,
                low=quote.low_price or bars[-1].low,
                volume=quote.volume or bars[-1].volume,
                amount=quote.amount or bars[-1].amount,
                amplitude_percent=quote.amplitude_percent or bars[-1].amplitude_percent,
                change_percent=quote.change_percent or _pct_change(quote.current_price, prev_close),
                change_amount=quote.change_amount
                or (round(quote.current_price - prev_close, 4) if prev_close else None),
                turnover_rate=quote.turnover_rate,
            )
    return bars


def _parse_tencent_daily_rows(rows: Iterable[Any]) -> list[DailyBar]:
    result: list[DailyBar] = []
    previous_close: float | None = None
    for row in rows:
        if not isinstance(row, list) or len(row) < 6:
            continue
        open_p, close_p, high_p, low_p, vol = (_num(v) for v in row[1:6])
        change = round(close_p - previous_close, 4) if close_p is not None and previous_close is not None else None
        change_pct = _pct_change(close_p, previous_close, digits=2) if previous_close else None
        amplitude = (
            round((high_p - low_p) / previous_close * 100.0, 2)
            if high_p is not None and low_p is not None and previous_close not in (None, 0)
            else None
        )
        avg_p = (open_p + close_p + high_p + low_p) / 4.0 if all(x is not None for x in (open_p, close_p, high_p, low_p)) else close_p
        est_amount = round(vol * 100.0 * avg_p, 2) if vol is not None and avg_p is not None else None
        result.append(
            DailyBar(
                date=str(row[0]),
                open=open_p,
                close=close_p,
                high=high_p,
                low=low_p,
                volume=vol,
                amount=est_amount,
                amplitude_percent=amplitude,
                change_percent=change_pct,
                change_amount=change,
                turnover_rate=None,
            )
        )
        if close_p is not None:
            previous_close = close_p
    return result


def build_technical_summary(quote: Quote, bars: list[DailyBar]) -> dict[str, Any]:
    """计算全维度日线技术指标、均线排列、MACD/RSI/ATR、多窗口价格分位数与支撑压力位。"""
    closes = [float(b.close) for b in bars if b.close is not None]
    if not closes:
        return {}
    latest = bars[-1]
    current = quote.current_price or closes[-1]

    ma_periods = (5, 10, 20, 60, 120, 250)
    mas: dict[str, float | None] = {}
    vs_mas: dict[str, float | None] = {}
    for p in ma_periods:
        val = round(mean(closes[-p:]), 4) if len(closes) >= p else None
        mas[f"MA{p}"] = val
        vs_mas[f"close_vs_ma{p}_pct"] = _pct_change(current, val, digits=2)

    ma20_5d_ago = mean(closes[-25:-5]) if len(closes) >= 25 else None
    ma60_10d_ago = mean(closes[-70:-10]) if len(closes) >= 70 else None
    ma20_slope = _pct_change(mas["MA20"], ma20_5d_ago, digits=2)
    ma60_slope = _pct_change(mas["MA60"], ma60_10d_ago, digits=2)
    ma_alignment = _classify_ma_alignment(current, mas["MA5"], mas["MA10"], mas["MA20"], mas["MA60"])

    returns = {
        "latest_return_pct": quote.change_percent if quote.change_percent is not None else latest.change_percent,
        "return_3d_pct": _period_return(closes, 3),
        "return_5d_pct": _period_return(closes, 5),
        "return_10d_pct": _period_return(closes, 10),
        "return_20d_pct": _period_return(closes, 20),
        "return_60d_pct": _period_return(closes, 60),
        "return_120d_pct": _period_return(closes, 120),
        "return_250d_pct": _period_return(closes, 250),
    }

    windows = {
        "range_20d": _range_and_percentile(bars, closes, current, 20),
        "range_60d": _range_and_percentile(bars, closes, current, 60),
        "range_120d": _range_and_percentile(bars, closes, current, 120),
        "range_250d": _range_and_percentile(bars, closes, current, 250),
    }

    rsi14 = _rsi(closes, 14)
    macd_data = _macd(closes)
    atr20 = _atr(bars, 20)
    atr20_pct = round(atr20 / current * 100.0, 2) if atr20 is not None and current else None

    daily_rets = [
        (closes[i] / closes[i - 1] - 1.0) * 100.0
        for i in range(max(1, len(closes) - 20), len(closes))
        if closes[i - 1] > 0
    ]
    vol_20d = round(pstdev(daily_rets), 2) if len(daily_rets) >= 2 else None
    annual_vol_20d = round(vol_20d * math.sqrt(252), 2) if vol_20d is not None else None
    avg_amp_20d = _round(
        mean([b.amplitude_percent for b in bars[-20:] if b.amplitude_percent is not None])
        if any(b.amplitude_percent is not None for b in bars[-20:])
        else None,
        2,
    )

    vols = [float(b.volume) for b in bars if b.volume is not None]
    vol5 = mean(vols[-5:]) if len(vols) >= 5 else None
    vol20 = mean(vols[-20:]) if len(vols) >= 20 else None
    vol60 = mean(vols[-60:]) if len(vols) >= 60 else None
    latest_vol = float(latest.volume) if latest.volume is not None else None
    vol_5_vs_20 = round(vol5 / vol20, 2) if vol5 and vol20 else None
    vol_20_vs_60 = round(vol20 / vol60, 2) if vol20 and vol60 else None
    latest_vol_vs_20 = round(latest_vol / vol20, 2) if latest_vol and vol20 else None

    up_streak, down_streak = _streaks(closes)
    pivots = _pivot_levels(latest.high, latest.low, latest.close)
    support_levels = sorted(
        {
            round(v, 4)
            for v in (
                pivots.get("s1"),
                pivots.get("s2"),
                mas.get("MA20"),
                mas.get("MA60"),
                windows["range_20d"].get("low"),
                windows["range_60d"].get("low"),
            )
            if v is not None and v <= current * 1.005
        },
        reverse=True,
    )
    resistance_levels = sorted(
        {
            round(v, 4)
            for v in (
                pivots.get("r1"),
                pivots.get("r2"),
                mas.get("MA5"),
                mas.get("MA10"),
                mas.get("MA20"),
                mas.get("MA60"),
                windows["range_20d"].get("high"),
                windows["range_60d"].get("high"),
            )
            if v is not None and v >= current * 0.995
        }
    )

    return {
        "基准价": current,
        "日线区间": f"{bars[0].date} ~ {latest.date} (共{len(bars)}个交易日)",
        **mas,
        **vs_mas,
        "ma5": mas["MA5"],
        "ma10": mas["MA10"],
        "ma20": mas["MA20"],
        "ma60": mas["MA60"],
        "ma120": mas["MA120"],
        "ma250": mas["MA250"],
        "ma20_slope_5d_pct": ma20_slope,
        "ma60_slope_10d_pct": ma60_slope,
        "ma_alignment": ma_alignment,
        **returns,
        **windows,
        "rsi14": rsi14,
        "macd": macd_data,
        "atr20": _round(atr20, 4),
        "atr20_pct": atr20_pct,
        "avg_amplitude_20d_pct": avg_amp_20d,
        "realized_volatility_20d_pct": vol_20d,
        "annualized_volatility_20d_pct": annual_vol_20d,
        "up_streak_days": up_streak,
        "down_streak_days": down_streak,
        "volume_5d_vs_20d_ratio": vol_5_vs_20,
        "volume_20d_vs_60d_ratio": vol_20_vs_60,
        "latest_volume_vs_20d_ratio": latest_vol_vs_20,
        "pivot_levels": pivots,
        "key_supports": support_levels[:4],
        "key_resistances": resistance_levels[:4],
    }


def _period_return(values: list[float], periods: int) -> float | None:
    if len(values) <= periods or values[-periods - 1] == 0:
        return None
    return round((values[-1] / values[-periods - 1] - 1.0) * 100.0, 2)


def _range_and_percentile(
    bars: list[DailyBar], closes: list[float], current: float, lookback: int
) -> dict[str, Any]:
    w_bars = bars[-lookback:]
    w_closes = closes[-lookback:]
    highs = [b.high for b in w_bars if b.high is not None]
    lows = [b.low for b in w_bars if b.low is not None]
    high_v = max(highs) if highs else None
    low_v = min(lows) if lows else None
    pos_pct = (
        round((current - low_v) / (high_v - low_v) * 100.0, 1)
        if high_v is not None and low_v is not None and high_v > low_v
        else 50.0
    )
    pos_pct = max(0.0, min(100.0, pos_pct)) if pos_pct is not None else None
    pctile = (
        round(sum(1 for c in w_closes if c <= current) / len(w_closes) * 100.0, 1)
        if w_closes
        else None
    )
    return {
        "window_days": len(w_closes),
        "high": _round(high_v, 4),
        "low": _round(low_v, 4),
        "position_pct": pos_pct,
        "close_percentile_pct": pctile,
        "drawdown_from_high_pct": _pct_change(current, high_v, digits=2),
        "rebound_from_low_pct": _pct_change(current, low_v, digits=2),
    }


def _classify_ma_alignment(
    close: float | None,
    ma5: float | None,
    ma10: float | None,
    ma20: float | None,
    ma60: float | None,
) -> str:
    if any(x is None for x in (close, ma5, ma10, ma20)):
        return "均线数据不足"
    if ma60 is not None:
        if close >= ma5 >= ma10 >= ma20 >= ma60:
            return "标准多头排列（强势上升趋势）"
        if close <= ma5 <= ma10 <= ma20 <= ma60:
            return "标准空头排列（弱势下降趋势）"
        if close < ma20 and ma20 >= ma60:
            return "中期偏多、短期跌破20日线回调"
        if close >= ma20 and ma20 < ma60:
            return "中期偏弱、短期站上20日线反弹"
    if close >= ma5 >= ma10 >= ma20:
        return "短中期多头排列"
    if close <= ma5 <= ma10 <= ma20:
        return "短中期空头排列"
    return "均线交织震荡"


def _ema_series(values: list[float], period: int) -> list[float | None]:
    if period <= 0 or len(values) < period:
        return [None] * len(values)
    alpha = 2.0 / (period + 1)
    result: list[float | None] = [None] * (period - 1)
    ema = mean(values[:period])
    result.append(ema)
    for v in values[period:]:
        ema = v * alpha + ema * (1.0 - alpha)
        result.append(ema)
    return result


def _macd(closes: list[float]) -> dict[str, Any]:
    ema12 = _ema_series(closes, 12)
    ema26 = _ema_series(closes, 26)
    dif = [f - s if f is not None and s is not None else None for f, s in zip(ema12, ema26)]
    valid_dif = [x for x in dif if x is not None]
    dea_valid = _ema_series(valid_dif, 9)
    it = iter(dea_valid)
    dea = [next(it) if x is not None else None for x in dif]
    hist = [(d - e) * 2.0 if d is not None and e is not None else None for d, e in zip(dif, dea)]
    d_now = dif[-1] if dif else None
    e_now = dea[-1] if dea else None
    h_now = hist[-1] if hist else None
    h_prev = hist[-2] if len(hist) >= 2 else None
    state = "未知"
    if d_now is not None and e_now is not None and h_now is not None:
        if d_now >= e_now:
            state = "金叉/多头红柱放大" if (h_prev is not None and h_now >= h_prev) else "多头红柱缩短"
        else:
            state = "死叉/空头绿柱放大" if (h_prev is not None and h_now <= h_prev) else "空头绿柱收敛（跌势放缓）"
    return {
        "dif": _round(d_now, 4),
        "dea": _round(e_now, 4),
        "histogram": _round(h_now, 4),
        "state": state,
    }


def _rsi(closes: list[float], period: int = 14) -> float | None:
    if len(closes) <= period:
        return None
    changes = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains = [max(c, 0.0) for c in changes]
    losses = [abs(min(c, 0.0)) for c in changes]
    avg_g = mean(gains[:period])
    avg_l = mean(losses[:period])
    for i in range(period, len(changes)):
        avg_g = (avg_g * (period - 1) + gains[i]) / period
        avg_l = (avg_l * (period - 1) + losses[i]) / period
    if avg_l == 0:
        return 100.0
    rs = avg_g / avg_l
    return round(100.0 - 100.0 / (1.0 + rs), 2)


def _atr(bars: list[DailyBar], period: int = 20) -> float | None:
    if len(bars) < 2:
        return None
    trs: list[float] = []
    for i in range(max(1, len(bars) - period), len(bars)):
        cur, prev = bars[i], bars[i - 1]
        if cur.high is None or cur.low is None:
            continue
        cands = [cur.high - cur.low]
        if prev.close is not None:
            cands.extend([abs(cur.high - prev.close), abs(cur.low - prev.close)])
        trs.append(max(cands))
    return mean(trs) if trs else None


def _streaks(closes: list[float]) -> tuple[int, int]:
    up = down = 0
    for i in range(len(closes) - 1, 0, -1):
        diff = closes[i] - closes[i - 1]
        if diff > 0:
            if down > 0:
                break
            up += 1
        elif diff < 0:
            if up > 0:
                break
            down += 1
        else:
            break
    return up, down


def _pivot_levels(high: float | None, low: float | None, close: float | None) -> dict[str, float | None]:
    if high is None or low is None or close is None or high < low:
        return {}
    p = (high + low + close) / 3.0
    return {
        "pivot": round(p, 4),
        "r1": round(2 * p - low, 4),
        "r2": round(p + (high - low), 4),
        "s1": round(2 * p - high, 4),
        "s2": round(p - (high - low), 4),
    }


def fetch_weekly_bars(
    secid: str,
    *,
    limit: int = DEFAULT_WEEKLY_KLINE_LIMIT,
    quote: Quote | None = None,
) -> list[DailyBar]:
    """获取前复权周K线（东方财富 klt=102 与腾讯 qfqweek 自动互备，并用实时精确价修正本周最新K线）。"""
    bars: list[DailyBar] = []
    session = _session()
    params = {
        "secid": secid,
        "klt": "102",
        "fqt": "1",
        "lmt": str(limit),
        "end": "20500101",
        "iscca": "1",
        "fields1": "f1,f2,f3,f4,f5,f6",
        "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
        "ut": "fa5fd1943c7b386f172d6893dbfba10b",
    }
    for base in EASTMONEY_HISTORY_BASES:
        try:
            resp = session.get(
                f"{base}/stock/kline/get",
                params=params,
                headers={"Referer": "https://quote.eastmoney.com/"},
                timeout=6,
            )
            if resp.status_code == 200:
                klines = ((resp.json().get("data") or {}).get("klines")) or []
                if klines:
                    for item in klines:
                        parts = str(item).split(",")
                        if len(parts) >= 11:
                            bars.append(
                                DailyBar(
                                    date=parts[0],
                                    open=_num(parts[1]),
                                    close=_num(parts[2]),
                                    high=_num(parts[3]),
                                    low=_num(parts[4]),
                                    volume=_num(parts[5]),
                                    amount=_num(parts[6]),
                                    amplitude_percent=_num(parts[7]),
                                    change_percent=_num(parts[8]),
                                    change_amount=_num(parts[9]),
                                    turnover_rate=_num(parts[10]),
                                )
                            )
                    break
        except Exception:
            continue

    if not bars:
        try:
            market, symbol = secid.split(".", 1)
            code = ("sh" if market == "1" else "sz") + symbol
            resp = session.get(
                TENCENT_KLINE_URL,
                params={"param": f"{code},week,,,{limit},qfq"},
                timeout=REQUEST_TIMEOUT,
            )
            resp.raise_for_status()
            node = ((resp.json().get("data") or {}).get(code)) or {}
            rows = node.get("qfqweek") or node.get("week") or []
            bars = _parse_tencent_daily_rows(rows)
        except Exception as exc:
            logging.warning("获取 %s 周K线失败: %s", secid, exc)
            return []

    if quote and quote.current_price is not None and bars:
        last_bar = bars[-1]
        q_date = (quote.quote_time or "")[:10]
        try:
            b_dt = datetime.strptime(last_bar.date[:10], "%Y-%m-%d")
            q_dt = datetime.strptime(q_date, "%Y-%m-%d") if q_date else b_dt
            same_week = abs((q_dt - b_dt).days) <= 6 and q_dt.isocalendar()[:2] == b_dt.isocalendar()[:2]
        except Exception:
            same_week = (q_date == last_bar.date)
        if same_week:
            prev_w_close = bars[-2].close if len(bars) >= 2 else last_bar.open
            new_high = max(x for x in (last_bar.high, quote.high_price, quote.current_price) if x is not None)
            new_low = min(x for x in (last_bar.low, quote.low_price, quote.current_price) if x is not None)
            bars[-1] = DailyBar(
                date=q_date or last_bar.date,
                open=last_bar.open,
                close=quote.current_price,
                high=new_high,
                low=new_low,
                volume=last_bar.volume,
                amount=last_bar.amount,
                amplitude_percent=(
                    round((new_high - new_low) / prev_w_close * 100.0, 2)
                    if prev_w_close not in (None, 0)
                    else last_bar.amplitude_percent
                ),
                change_percent=_pct_change(quote.current_price, prev_w_close, digits=2),
                change_amount=(
                    round(quote.current_price - prev_w_close, 4) if prev_w_close is not None else last_bar.change_amount
                ),
                turnover_rate=last_bar.turnover_rate,
            )
    return bars


def _weekly_range_and_percentile(
    bars: list[DailyBar], closes: list[float], current: float, lookback_weeks: int
) -> dict[str, Any]:
    w_bars = bars[-lookback_weeks:]
    w_closes = closes[-lookback_weeks:]
    highs = [b.high for b in w_bars if b.high is not None]
    lows = [b.low for b in w_bars if b.low is not None]
    high_v = max(highs) if highs else None
    low_v = min(lows) if lows else None
    mid_v = round((high_v + low_v) / 2.0, 4) if high_v is not None and low_v is not None else None
    pos_pct = (
        round((current - low_v) / (high_v - low_v) * 100.0, 1)
        if high_v is not None and low_v is not None and high_v > low_v
        else 50.0
    )
    pos_pct = max(0.0, min(100.0, pos_pct)) if pos_pct is not None else None
    pctile = (
        round(sum(1 for c in w_closes if c <= current) / len(w_closes) * 100.0, 1)
        if w_closes
        else None
    )
    return {
        "window_weeks": len(w_closes),
        "high": _round(high_v, 4),
        "low": _round(low_v, 4),
        "mid_price": mid_v,
        "vs_mid_pct": _pct_change(current, mid_v, digits=2),
        "below_mid": bool(current < mid_v) if mid_v is not None else None,
        "position_pct": pos_pct,
        "close_percentile_pct": pctile,
        "drawdown_from_high_pct": _pct_change(current, high_v, digits=2),
        "rebound_from_low_pct": _pct_change(current, low_v, digits=2),
    }


def build_weekly_technical_summary(quote: Quote, weekly_bars: list[DailyBar]) -> dict[str, Any]:
    """计算前复权周K线中长期技术指标、周布林带(BOLL20)与多周期周线价格分位数。"""
    closes = [float(b.close) for b in weekly_bars if b.close is not None]
    if not closes:
        return {"available": False}
    latest = weekly_bars[-1]
    current = quote.current_price or closes[-1]

    wma_periods = (5, 10, 20, 30, 60, 120)
    wmas: dict[str, float | None] = {}
    vs_wmas: dict[str, float | None] = {}
    for p in wma_periods:
        val = round(mean(closes[-p:]), 4) if len(closes) >= p else None
        wmas[f"WMA{p}"] = val
        vs_wmas[f"close_vs_wma{p}_pct"] = _pct_change(current, val, digits=2)

    wma20_4w_ago = mean(closes[-24:-4]) if len(closes) >= 24 else None
    wma60_8w_ago = mean(closes[-68:-8]) if len(closes) >= 68 else None
    wma20_slope = _pct_change(wmas["WMA20"], wma20_4w_ago, digits=2)
    wma60_slope = _pct_change(wmas["WMA60"], wma60_8w_ago, digits=2)
    w_alignment = _classify_ma_alignment(
        current, wmas["WMA5"], wmas["WMA10"], wmas["WMA20"], wmas["WMA60"]
    ).replace("20日线", "20周线")

    # 周线布林带 BOLL(20, 2)
    boll_mid = wmas["WMA20"]
    boll_std = pstdev(closes[-20:]) if len(closes) >= 20 else None
    boll_upper = round(boll_mid + 2.0 * boll_std, 4) if boll_mid is not None and boll_std is not None else None
    boll_lower = round(boll_mid - 2.0 * boll_std, 4) if boll_mid is not None and boll_std is not None else None
    boll_pct_b = (
        round((current - boll_lower) / (boll_upper - boll_lower) * 100.0, 1)
        if boll_upper is not None and boll_lower is not None and boll_upper > boll_lower
        else None
    )
    boll_bw_pct = (
        round((boll_upper - boll_lower) / boll_mid * 100.0, 2)
        if boll_upper is not None and boll_lower is not None and boll_mid
        else None
    )

    returns = {
        "return_1w_pct": latest.change_percent if latest.change_percent is not None else _period_return(closes, 1),
        "return_2w_pct": _period_return(closes, 2),
        "return_4w_pct": _period_return(closes, 4),
        "return_13w_pct": _period_return(closes, 13),
        "return_26w_pct": _period_return(closes, 26),
        "return_52w_pct": _period_return(closes, 52),
        "return_104w_pct": _period_return(closes, 104),
    }

    windows = {
        "range_13w": _weekly_range_and_percentile(weekly_bars, closes, current, 13),
        "range_26w": _weekly_range_and_percentile(weekly_bars, closes, current, 26),
        "range_52w": _weekly_range_and_percentile(weekly_bars, closes, current, 52),
        "range_104w": _weekly_range_and_percentile(weekly_bars, closes, current, 104),
    }

    w_rsi14 = _rsi(closes, 14)
    w_macd = _macd(closes)
    w_atr14 = _atr(weekly_bars, 14)
    w_atr14_pct = round(w_atr14 / current * 100.0, 2) if w_atr14 is not None and current else None
    up_w, down_w = _streaks(closes)

    return {
        "available": True,
        "基准价": current,
        "周线区间": f"{weekly_bars[0].date} ~ {latest.date} (共{len(weekly_bars)}周)",
        **wmas,
        **vs_wmas,
        "wma20_slope_4w_pct": wma20_slope,
        "wma60_slope_8w_pct": wma60_slope,
        "weekly_ma_alignment": w_alignment,
        "weekly_boll": {
            "mid_wma20": boll_mid,
            "upper": boll_upper,
            "lower": boll_lower,
            "percent_b": boll_pct_b,
            "bandwidth_pct": boll_bw_pct,
        },
        **returns,
        **windows,
        "weekly_rsi14": w_rsi14,
        "weekly_macd": w_macd,
        "weekly_atr14": _round(w_atr14, 4),
        "weekly_atr14_pct": w_atr14_pct,
        "up_streak_weeks": up_w,
        "down_streak_weeks": down_w,
    }


# ============================================================================
# 3. 基金基本面档案、跟踪指数估值与前十大重仓股共振分析
# ============================================================================


def fetch_fund_profile_and_valuation(symbol: str, *, cn10y_yield: float | None = None) -> dict[str, Any]:
    """从天天基金移动端接口获取 ETF 基本面、夏普/回撤、跟踪指数 PE/PB/分位数/股息率/ROE 及相对国债利差。"""
    session = _session()
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://fund.eastmoney.com/"}
    url = f"{FUND_MOB_BASE}/FundMNNBasicInformation"
    try:
        resp = session.get(
            url,
            params={
                "FCODE": symbol,
                "deviceid": "Wap",
                "plat": "Wap",
                "product": "EFund",
                "version": "2.0.0",
            },
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        payload = resp.json() or {}
        d = payload.get("Datas") or {}
        idx = (payload.get("Expansion") or {}).get("INDEXINFO") or {}
    except Exception as exc:
        logging.warning("获取 %s 基金概况与指数估值失败: %s", symbol, exc)
        return {"available": False, "error": str(exc)}

    end_nav = _num(d.get("ENDNAV"))
    scale_yi = round(end_nav / 1e8, 2) if end_nav else None
    pe_ttm = _num(idx.get("PETTM"))
    pe_pct = _num(idx.get("PEP100"))
    pb = _num(idx.get("PB"))
    pb_pct = _num(idx.get("PBP100"))
    gxl = _num(idx.get("GXL"))
    roe = _num(idx.get("ROE"))
    ep_pct = round(100.0 / pe_ttm, 2) if pe_ttm and pe_ttm > 0 else None
    erp_vs_cn10y = round(ep_pct - cn10y_yield, 2) if ep_pct is not None and cn10y_yield is not None else None
    div_spread_vs_cn10y = round(gxl - cn10y_yield, 2) if gxl is not None and cn10y_yield is not None else None

    val_status = "未知"
    if pe_pct is not None:
        if pe_pct < 20:
            val_status = "极度低估区间 (<20%分位)"
        elif pe_pct < 40:
            val_status = "估值偏低区间 (20%~40%分位)"
        elif pe_pct <= 60:
            val_status = "估值适中区间 (40%~60%分位)"
        elif pe_pct <= 80:
            val_status = "估值偏高区间 (60%~80%分位)"
        else:
            val_status = "估值高估区间 (>80%分位)"

    return {
        "available": bool(d),
        "fund_code": d.get("FCODE") or symbol,
        "short_name": d.get("SHORTNAME"),
        "fund_type": d.get("FTYPE"),
        "establish_date": d.get("ESTABDATE"),
        "fund_company": d.get("JJGS"),
        "benchmark": d.get("BENCH"),
        "report_scale_yi": scale_yi,
        "report_scale_date": d.get("FEGMRQ"),
        "latest_nav": _num(d.get("DWJZ")),
        "accumulated_nav": _num(d.get("LJJZ")),
        "nav_date": d.get("FSRQ"),
        "tracking_error_pct": _num(d.get("TRKERROR")),
        "risk_level": d.get("RISKLEVEL"),
        "sharpe_1y": _num(d.get("SHARP1")),
        "sharpe_2y": _num(d.get("SHARP2")),
        "sharpe_3y": _num(d.get("SHARP3")),
        "max_drawdown_1y_pct": _num(d.get("MAXRETRA1")),
        "volatility_1y_pct": _num(d.get("STDDEV1")),
        "sip_return_1y_pct": _num(d.get("PTDT_Y")),
        "sip_return_2y_pct": _num(d.get("PTDT_TWY")),
        "sip_return_3y_pct": _num(d.get("PTDT_TRY")),
        "index_valuation": {
            "index_code": idx.get("INDEXCODE") or d.get("INDEXCODE"),
            "index_name": idx.get("FULLINDEXNAME") or d.get("INDEXNAME") or idx.get("INDEXNAME"),
            "valuation_date": idx.get("PDATE"),
            "pe_ttm": pe_ttm,
            "pe_percentile_pct": pe_pct,
            "pb": pb,
            "pb_percentile_pct": pb_pct,
            "dividend_yield_pct": gxl,
            "roe_pct": roe,
            "cn10y_yield_pct": cn10y_yield,
            "earnings_yield_ep_pct": ep_pct,
            "erp_vs_cn10y_pct": erp_vs_cn10y,
            "dividend_spread_vs_cn10y_pct": div_spread_vs_cn10y,
            "valuation_status": val_status,
            "return_1w_pct": _num(idx.get("W")),
            "return_1m_pct": _num(idx.get("M")),
            "return_3m_pct": _num(idx.get("Q")),
            "return_6m_pct": _num(idx.get("HY")),
            "return_1y_pct": _num(idx.get("Y")),
            "return_ytd_pct": _num(idx.get("SY")),
            "profile": _clean_text(idx.get("REAPROFILE")),
        },
    }


def fetch_market_margin_context() -> dict[str, Any]:
    """获取全A(沪深京)两融余额、融资净买入(1日/3日/5日/10日/20日)及连增/连降趋势。"""
    session = _session()
    try:
        resp = session.get(
            EASTMONEY_DATACENTER_URL,
            params={
                "reportName": "RPTA_RZRQ_LSHJ",
                "columns": "ALL",
                "pageSize": "25",
                "sortColumns": "DIM_DATE",
                "sortTypes": "-1",
            },
            headers={"Referer": "https://data.eastmoney.com/"},
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        rows = ((resp.json().get("result") or {}).get("data")) or []
    except Exception as exc:
        logging.warning("获取全A两融数据失败: %s", exc)
        return {"available": False, "error": str(exc)}

    if not rows:
        return {"available": False}

    latest = rows[0]
    date_str = str(latest.get("DIM_DATE") or "")[:10]
    total_margin_yi = _round((_num(latest.get("RZRQYE")) or 0) / 1e8, 2)
    fin_balance_yi = _round((_num(latest.get("RZYE")) or 0) / 1e8, 2)
    loan_balance_yi = _round((_num(latest.get("RQYE")) or 0) / 1e8, 2)
    fin_mv_ratio_pct = _round(_num(latest.get("RZYEZB")), 2)
    net_1d_yi = _round((_num(latest.get("RZJME")) or 0) / 1e8, 2)
    net_3d_yi = _round((_num(latest.get("RZJME3D")) or 0) / 1e8, 2)
    net_5d_yi = _round((_num(latest.get("RZJME5D")) or 0) / 1e8, 2)
    net_10d_yi = _round((_num(latest.get("RZJME10D")) or 0) / 1e8, 2)

    net_20d_vals = [_num(r.get("RZJME")) for r in rows[:20] if _num(r.get("RZJME")) is not None]
    net_20d_yi = _round(sum(net_20d_vals) / 1e8, 2) if net_20d_vals else None

    fin_20d_ago = _num(rows[min(len(rows) - 1, 20)].get("RZYE"))
    fin_now_raw = _num(latest.get("RZYE"))
    fin_chg_20d_pct = _pct_change(fin_now_raw, fin_20d_ago, digits=2)

    # 计算融资余额连增/连降天数
    fin_series = [_num(r.get("RZYE")) for r in reversed(rows) if _num(r.get("RZYE")) is not None]
    up_streak, down_streak = _streaks([float(x) for x in fin_series if x is not None])

    if down_streak >= 3:
        status = f"融资余额 {down_streak} 连降（单日 {net_1d_yi:+.2f}亿 / 近5日 {net_5d_yi:+.2f}亿 / 近10日 {net_10d_yi:+.2f}亿，杠杆资金持续去化）"
    elif up_streak >= 3:
        status = f"融资余额 {up_streak} 连增（单日 {net_1d_yi:+.2f}亿 / 近5日 {net_5d_yi:+.2f}亿 / 近10日 {net_10d_yi:+.2f}亿，杠杆资金持续加仓）"
    elif net_1d_yi is not None and net_5d_yi is not None:
        status = f"单日融资净买入 {net_1d_yi:+.2f}亿 | 近5日累计 {net_5d_yi:+.2f}亿 | 近10日累计 {net_10d_yi:+.2f}亿"
    else:
        status = "两融余额平稳"

    return {
        "available": True,
        "date": date_str,
        "total_margin_balance_yi": total_margin_yi,
        "fin_balance_yi": fin_balance_yi,
        "loan_balance_yi": loan_balance_yi,
        "fin_ratio_of_float_mv_pct": fin_mv_ratio_pct,
        "net_buy_1d_yi": net_1d_yi,
        "net_buy_3d_yi": net_3d_yi,
        "net_buy_5d_yi": net_5d_yi,
        "net_buy_10d_yi": net_10d_yi,
        "net_buy_20d_yi": net_20d_yi,
        "fin_change_20d_pct": fin_chg_20d_pct,
        "up_streak_days": up_streak,
        "down_streak_days": down_streak,
        "status_summary": status,
    }


def fetch_securities_margin_and_fundamentals(
    etf_symbol: str, constituent_symbols: list[str]
) -> tuple[dict[str, Any], dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    """批量获取 ETF 与前十大重仓股的两融数据、最新财报增速指标及最新业绩预告。"""
    session = _session()
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://data.eastmoney.com/"}
    all_codes = list(dict.fromkeys([etf_symbol] + constituent_symbols))
    code_filter_str = ",".join(f'"{c}"' for c in all_codes if c)
    stock_filter_str = ",".join(f'"{c}"' for c in constituent_symbols if c)

    margin_map: dict[str, dict[str, Any]] = {}
    fin_map: dict[str, dict[str, Any]] = {}
    predict_map: dict[str, dict[str, Any]] = {}

    def _job_margin() -> None:
        if not code_filter_str:
            return
        try:
            resp = session.get(
                EASTMONEY_DATACENTER_URL,
                params={
                    "reportName": "RPTA_WEB_RZRQ_GGMX",
                    "columns": "SCODE,SECNAME,DATE,RZYE,RQYE,RZRQYE,RZJME,RZJME3D,RZJME5D,RZJME10D,FIN_BALANCE_GR",
                    "pageSize": str(max(50, len(all_codes) * 4)),
                    "sortColumns": "DATE",
                    "sortTypes": "-1",
                    "filter": f"(SCODE in ({code_filter_str}))",
                },
                headers=headers,
                timeout=8,
            )
            if resp.status_code != 200:
                return
            rows = ((resp.json().get("result") or {}).get("data")) or []
            for row in rows:
                code = str(row.get("SCODE") or "").strip()
                if not code or code in margin_map:
                    continue
                rzye = _num(row.get("RZYE"))
                rqye = _num(row.get("RQYE"))
                j1 = _num(row.get("RZJME"))
                j3 = _num(row.get("RZJME3D"))
                j5 = _num(row.get("RZJME5D"))
                j10 = _num(row.get("RZJME10D"))
                margin_map[code] = {
                    "date": str(row.get("DATE") or "")[:10],
                    "fin_balance_yi": round(rzye / 1e8, 2) if rzye is not None else None,
                    "loan_balance_yi": round(rqye / 1e8, 3) if rqye is not None else None,
                    "fin_net_buy_1d_yi": round(j1 / 1e8, 3) if j1 is not None else None,
                    "fin_net_buy_3d_yi": round(j3 / 1e8, 3) if j3 is not None else None,
                    "fin_net_buy_5d_yi": round(j5 / 1e8, 3) if j5 is not None else None,
                    "fin_net_buy_10d_yi": round(j10 / 1e8, 3) if j10 is not None else None,
                    "fin_change_1d_pct": _round(_num(row.get("FIN_BALANCE_GR")), 2),
                }
        except Exception as exc:
            logging.debug("批量获取两融明细异常: %s", exc)

    def _job_fundamentals() -> None:
        if not stock_filter_str:
            return
        try:
            resp = session.get(
                EASTMONEY_DATACENTER_URL,
                params={
                    "reportName": "RPT_LICO_FN_CPD",
                    "columns": (
                        "SECURITY_CODE,SECURITY_NAME_ABBR,REPORTDATE,DATATYPE,QDATE,"
                        "BASIC_EPS,TOTAL_OPERATE_INCOME,PARENT_NETPROFIT,WEIGHTAVG_ROE,"
                        "YSTZ,SJLTZ,XSMLL,YSHZ,SJLHZ,NOTICE_DATE"
                    ),
                    "pageSize": "50",
                    "sortColumns": "REPORTDATE,NOTICE_DATE",
                    "sortTypes": "-1,-1",
                    "filter": f"(SECURITY_CODE in ({stock_filter_str}))",
                },
                headers=headers,
                timeout=8,
            )
            if resp.status_code != 200:
                return
            rows = ((resp.json().get("result") or {}).get("data")) or []
            for row in rows:
                code = str(row.get("SECURITY_CODE") or "").strip()
                if not code or code in fin_map:
                    continue
                fin_map[code] = {
                    "report_period": _clean_text(row.get("QDATE") or row.get("DATATYPE")),
                    "report_date": str(row.get("REPORTDATE") or "")[:10],
                    "notice_date": str(row.get("NOTICE_DATE") or "")[:10],
                    "rev_yoy_pct": _round(_num(row.get("YSTZ")), 2),
                    "rev_qoq_pct": _round(_num(row.get("YSHZ")), 2),
                    "profit_yoy_pct": _round(_num(row.get("SJLTZ")), 2),
                    "profit_qoq_pct": _round(_num(row.get("SJLHZ")), 2),
                    "roe_pct": _round(_num(row.get("WEIGHTAVG_ROE")), 2),
                    "gross_margin_pct": _round(_num(row.get("XSMLL")), 2),
                    "basic_eps": _round(_num(row.get("BASIC_EPS")), 3),
                }
        except Exception as exc:
            logging.debug("批量获取重仓股财报指标异常: %s", exc)

    def _job_predictions() -> None:
        if not stock_filter_str:
            return
        try:
            resp = session.get(
                EASTMONEY_DATACENTER_URL,
                params={
                    "reportName": "RPT_PUBLIC_OP_PREDICT",
                    "columns": "ALL",
                    "pageSize": "50",
                    "sortColumns": "REPORTDATE,NOTICE_DATE",
                    "sortTypes": "-1,-1",
                    "filter": f"(SECURITY_CODE in ({stock_filter_str}))",
                },
                headers=headers,
                timeout=8,
            )
            if resp.status_code != 200:
                return
            rows = ((resp.json().get("result") or {}).get("data")) or []
            for row in rows:
                code = str(row.get("SECURITY_CODE") or "").strip()
                if not code or code in predict_map:
                    continue
                rpt_dt = str(row.get("REPORTDATE") or "")[:10]
                if rpt_dt < "2026-06-30":
                    continue
                low_v = _round(_num(row.get("INCREASEL")), 2)
                high_v = _round(_num(row.get("INCREASET")), 2)
                mid_v = (
                    round((low_v + high_v) / 2.0, 2)
                    if low_v is not None and high_v is not None
                    else (low_v if low_v is not None else high_v)
                )
                p_type = _clean_text(row.get("FORECASTTYPE"))
                n_dt = str(row.get("NOTICE_DATE") or "")[:10]
                q_label = (
                    f"{rpt_dt[:4]}Q3"
                    if "-09-30" in rpt_dt
                    else (f"{rpt_dt[:4]}Q2" if "-06-30" in rpt_dt else rpt_dt)
                )
                range_s = (
                    f"{low_v:+.1f}%~{high_v:+.1f}%"
                    if low_v is not None and high_v is not None and low_v != high_v
                    else (f"{mid_v:+.1f}%" if mid_v is not None else "")
                )
                predict_map[code] = {
                    "report_date": rpt_dt,
                    "period_label": q_label,
                    "predict_type": p_type,
                    "yoy_low_pct": low_v,
                    "yoy_high_pct": high_v,
                    "yoy_mid_pct": mid_v,
                    "notice_date": n_dt,
                    "summary": f"{q_label}{p_type}({range_s}, {n_dt[5:]}公告)" if p_type else None,
                }
        except Exception as exc:
            logging.debug("批量获取重仓股业绩预告异常: %s", exc)

    with ThreadPoolExecutor(max_workers=3) as pool:
        futs = [pool.submit(_job_margin), pool.submit(_job_fundamentals), pool.submit(_job_predictions)]
        for f in as_completed(futs):
            try:
                f.result()
            except Exception:
                continue

    etf_margin = margin_map.get(etf_symbol) or {"available": False}
    if etf_symbol in margin_map:
        etf_margin["available"] = True
    return etf_margin, margin_map, {
        c: {"fin": fin_map.get(c) or {}, "predict": predict_map.get(c) or {}}
        for c in constituent_symbols
    }


def fetch_constituents_analysis(symbol: str) -> dict[str, Any]:
    """获取前十大重仓股清单，并批量拉取实时行情、日K均线状态、基本面财务增速/业绩预告与两融资金数据。"""
    session = _session()
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://fund.eastmoney.com/"}
    url = f"{FUND_MOB_BASE}/FundMNInverstPosition"
    try:
        resp = session.get(
            url,
            params={
                "FCODE": symbol,
                "deviceid": "Wap",
                "plat": "Wap",
                "product": "EFund",
                "version": "2.0.0",
            },
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        payload = resp.json() or {}
        raw_stocks = ((payload.get("Datas") or {}).get("fundStocks")) or []
        asof_date = payload.get("Expansion")
    except Exception as exc:
        logging.warning("获取 %s 重仓股失败: %s", symbol, exc)
        return {"available": False, "error": str(exc), "constituents": []}

    if not raw_stocks:
        return {"available": False, "reason": "未披露重仓股", "constituents": []}

    items: list[dict[str, Any]] = []
    t_codes: list[str] = []
    c_symbols: list[str] = []
    for row in raw_stocks:
        code = str(row.get("GPDM") or "").strip()
        if not code:
            continue
        secid, t_code, pure = symbol_to_secid(code)
        t_codes.append(t_code)
        c_symbols.append(pure)
        items.append(
            {
                "symbol": pure,
                "secid": secid,
                "t_code": t_code,
                "name": _clean_text(row.get("GPJC")),
                "weight_pct": _num(row.get("JZBL")) or 0.0,
                "change_type": _clean_text(row.get("PCTNVCHGTYPE")),
                "weight_change_pct": _num(row.get("PCTNVCHG")),
                "industry": _clean_text(row.get("INDEXNAME")),
            }
        )

    quote_map = fetch_tencent_quotes(t_codes)
    etf_margin, margin_map, fund_pred_map = fetch_securities_margin_and_fundamentals(symbol, c_symbols)

    # 并发获取前十大重仓股最近 65 根日K以计算 5日/20日涨跌及 MA20/MA60 广度
    kline_stats: dict[str, dict[str, Any]] = {}

    def _fetch_stock_ma(item: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        tc = item["t_code"]
        r = session.get(
            TENCENT_KLINE_URL,
            params={"param": f"{tc},day,,,65,qfq"},
            timeout=6,
        )
        node = ((r.json().get("data") or {}).get(tc)) or {}
        rows = node.get("qfqday") or node.get("day") or []
        closes = [_num(x[2]) for x in rows if isinstance(x, list) and len(x) >= 3 and _num(x[2]) is not None]
        q = quote_map.get(item["symbol"])
        cur = (q.current_price if q and q.current_price else (closes[-1] if closes else None))
        if cur is not None and closes:
            closes[-1] = cur
        ma20 = mean(closes[-20:]) if len(closes) >= 20 else None
        ma60 = mean(closes[-60:]) if len(closes) >= 60 else None
        return item["symbol"], {
            "return_5d_pct": _period_return(closes, 5),
            "return_20d_pct": _period_return(closes, 20),
            "above_ma20": bool(cur >= ma20) if cur is not None and ma20 is not None else None,
            "above_ma60": bool(cur >= ma60) if cur is not None and ma60 is not None else None,
        }

    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = [pool.submit(_fetch_stock_ma, it) for it in items]
        for fut in as_completed(futures):
            try:
                sym, st = fut.result()
                kline_stats[sym] = st
            except Exception:
                continue

    total_weight = 0.0
    weighted_change_sum = 0.0
    up_count = down_count = flat_count = 0
    up_weight = 0.0
    ma20_up_weight = 0.0
    ma60_up_weight = 0.0
    industry_weights: dict[str, float] = {}

    # 基本面与两融加权汇总统计变量
    rev_w_sum = 0.0
    rev_w_total = 0.0
    prof_w_sum = 0.0
    prof_w_total = 0.0
    roe_w_sum = 0.0
    roe_w_total = 0.0
    prof_yoy_list: list[float] = []
    prof_pos_count = 0
    latest_pred_notes: list[str] = []

    top10_fin_bal_yi = 0.0
    top10_fin_1d_yi = 0.0
    top10_fin_5d_yi = 0.0
    top10_fin_10d_yi = 0.0
    fin_inflow_1d_cnt = 0
    fin_inflow_5d_cnt = 0

    for it in items:
        sym_c = it["symbol"]
        q = quote_map.get(sym_c)
        w = it["weight_pct"]
        total_weight += w
        chg = q.change_percent if q else None
        it["current_price"] = q.current_price if q else None
        it["change_pct"] = chg
        it["amount_yi"] = round(q.amount / 1e8, 2) if q and q.amount else None
        it["turnover_rate_pct"] = q.turnover_rate if q else None
        it["total_mv_yi"] = round(q.total_market_value / 1e8, 2) if q and q.total_market_value else None
        it["pe_ttm"] = q.pe_ttm if q else None
        it["pe_dynamic"] = q.pe_dynamic if q else None
        it["pb"] = q.pb if q else None

        st = kline_stats.get(sym_c, {})
        it["return_5d_pct"] = st.get("return_5d_pct")
        it["return_20d_pct"] = st.get("return_20d_pct")
        it["above_ma20"] = st.get("above_ma20")
        it["above_ma60"] = st.get("above_ma60")

        # 合并财务增速与业绩预告
        fp = fund_pred_map.get(sym_c) or {}
        fin = fp.get("fin") or {}
        pred = fp.get("predict") or {}
        rev_yoy = fin.get("rev_yoy_pct")
        prof_yoy = fin.get("profit_yoy_pct")
        roe_v = fin.get("roe_pct")
        pe_for_peg = it["pe_ttm"] or it["pe_dynamic"]
        peg = (
            round(pe_for_peg / prof_yoy, 2)
            if pe_for_peg is not None and pe_for_peg > 0 and prof_yoy is not None and prof_yoy > 0
            else None
        )
        it["report_period"] = fin.get("report_period")
        it["rev_yoy_pct"] = rev_yoy
        it["profit_yoy_pct"] = prof_yoy
        it["roe_pct"] = roe_v
        it["gross_margin_pct"] = fin.get("gross_margin_pct")
        it["peg"] = peg

        # 若业绩预告的报告期比正式财报期更新，则展示最新预告
        pred_rpt = pred.get("report_date") or ""
        fin_rpt = fin.get("report_date") or ""
        if pred and pred_rpt > fin_rpt:
            it["latest_earnings_forecast"] = pred.get("summary")
            latest_pred_notes.append(f"{it['name']}({sym_c}): {pred.get('summary')}")
        else:
            it["latest_earnings_forecast"] = None

        if rev_yoy is not None:
            rev_w_sum += w * rev_yoy
            rev_w_total += w
        if prof_yoy is not None:
            prof_w_sum += w * prof_yoy
            prof_w_total += w
            prof_yoy_list.append(prof_yoy)
            if prof_yoy > 0:
                prof_pos_count += 1
        if roe_v is not None:
            roe_w_sum += w * roe_v
            roe_w_total += w

        # 合并两融数据
        mg = margin_map.get(sym_c) or {}
        it["fin_balance_yi"] = mg.get("fin_balance_yi")
        it["fin_net_buy_1d_yi"] = mg.get("fin_net_buy_1d_yi")
        it["fin_net_buy_5d_yi"] = mg.get("fin_net_buy_5d_yi")
        it["fin_net_buy_10d_yi"] = mg.get("fin_net_buy_10d_yi")
        if mg.get("fin_balance_yi") is not None:
            top10_fin_bal_yi += mg["fin_balance_yi"]
        if mg.get("fin_net_buy_1d_yi") is not None:
            top10_fin_1d_yi += mg["fin_net_buy_1d_yi"]
            if mg["fin_net_buy_1d_yi"] > 0:
                fin_inflow_1d_cnt += 1
        if mg.get("fin_net_buy_5d_yi") is not None:
            top10_fin_5d_yi += mg["fin_net_buy_5d_yi"]
            if mg["fin_net_buy_5d_yi"] > 0:
                fin_inflow_5d_cnt += 1
        if mg.get("fin_net_buy_10d_yi") is not None:
            top10_fin_10d_yi += mg["fin_net_buy_10d_yi"]

        if chg is not None:
            contrib = round(w * chg / 100.0, 4)
            it["contribution_pct"] = contrib
            weighted_change_sum += w * chg
            if chg > 0:
                up_count += 1
                up_weight += w
            elif chg < 0:
                down_count += 1
            else:
                flat_count += 1
        else:
            it["contribution_pct"] = None
        if st.get("above_ma20"):
            ma20_up_weight += w
        if st.get("above_ma60"):
            ma60_up_weight += w
        ind = it.get("industry") or "其他"
        industry_weights[ind] = round(industry_weights.get(ind, 0.0) + w, 2)

    n_valid = up_count + down_count + flat_count
    breadth_up_pct = round(up_count / n_valid * 100.0, 1) if n_valid > 0 else None
    weighted_breadth_up_pct = round(up_weight / total_weight * 100.0, 1) if total_weight > 0 else None
    weighted_change_pct = round(weighted_change_sum / total_weight, 2) if total_weight > 0 else None
    above_ma20_pct = round(ma20_up_weight / total_weight * 100.0, 1) if total_weight > 0 else None
    above_ma60_pct = round(ma60_up_weight / total_weight * 100.0, 1) if total_weight > 0 else None

    sorted_prof = sorted(prof_yoy_list)
    median_prof_yoy = (
        round(sorted_prof[len(sorted_prof) // 2], 2) if sorted_prof else None
    )

    sorted_by_chg = sorted(
        [x for x in items if x.get("change_pct") is not None],
        key=lambda x: x["change_pct"],
        reverse=True,
    )

    return {
        "available": True,
        "report_date": asof_date,
        "count": len(items),
        "total_weight_pct": round(total_weight, 2),
        "up_count": up_count,
        "down_count": down_count,
        "flat_count": flat_count,
        "breadth_up_pct": breadth_up_pct,
        "weighted_breadth_up_pct": weighted_breadth_up_pct,
        "weighted_change_pct": weighted_change_pct,
        "estimated_top10_contribution_pct": round(weighted_change_sum / 100.0, 3),
        "above_ma20_weighted_breadth_pct": above_ma20_pct,
        "above_ma60_weighted_breadth_pct": above_ma60_pct,
        "industry_distribution_pct": dict(
            sorted(industry_weights.items(), key=lambda kv: kv[1], reverse=True)
        ),
        "fundamentals_summary": {
            "weighted_rev_yoy_pct": round(rev_w_sum / rev_w_total, 2) if rev_w_total > 0 else None,
            "weighted_profit_yoy_pct": round(prof_w_sum / prof_w_total, 2) if prof_w_total > 0 else None,
            "median_profit_yoy_pct": median_prof_yoy,
            "weighted_roe_pct": round(roe_w_sum / roe_w_total, 2) if roe_w_total > 0 else None,
            "profit_positive_growth_count": prof_pos_count,
            "latest_earnings_forecasts": latest_pred_notes,
        },
        "margin_summary": {
            "etf_margin": etf_margin,
            "top10_total_fin_balance_yi": round(top10_fin_bal_yi, 2),
            "top10_fin_net_buy_1d_yi": round(top10_fin_1d_yi, 2),
            "top10_fin_net_buy_5d_yi": round(top10_fin_5d_yi, 2),
            "top10_fin_net_buy_10d_yi": round(top10_fin_10d_yi, 2),
            "top10_fin_inflow_1d_count": fin_inflow_1d_cnt,
            "top10_fin_inflow_5d_count": fin_inflow_5d_cnt,
        },
        "top_gainers": [
            f"{x['name']}({x['symbol']} {x['change_pct']:+.2f}%, 权重{x['weight_pct']}%)"
            for x in sorted_by_chg[:3]
        ],
        "top_losers": [
            f"{x['name']}({x['symbol']} {x['change_pct']:+.2f}%, 权重{x['weight_pct']}%)"
            for x in sorted_by_chg[-3:]
        ],
        "constituents": items,
    }


# ============================================================================
# 4. 份额变化（含近1日/5日/20日趋势）、市场基准、海外映射与东方财富新闻检索
# ============================================================================


def _fetch_remote_etf_share_history(symbol: str, market: int, limit: int = 35) -> dict[str, float]:
    """从 Tushare fund_share（主源）或上交所官方接口获取最近 N 个交易日的真实场内份额序列（单位：份）。"""
    session = _session()
    ts_code = f"{symbol}.{'SH' if market == 1 else 'SZ'}"
    share_map: dict[str, float] = {}
    try:
        resp = session.post(
            TUSHARE_API_URL,
            json={
                "api_name": "fund_share",
                "token": DEFAULT_TUSHARE_TOKEN,
                "params": {"ts_code": ts_code},
                "fields": "ts_code,trade_date,fd_share",
            },
            timeout=6,
        )
        if resp.status_code == 200:
            data = (resp.json() or {}).get("data") or {}
            fields = data.get("fields") or []
            items = data.get("items") or []
            if "trade_date" in fields and "fd_share" in fields:
                idx_dt = fields.index("trade_date")
                idx_sh = fields.index("fd_share")
                for row in items[:limit]:
                    raw_dt = str(row[idx_dt] or "").strip()
                    sh_wan = _num(row[idx_sh])
                    if len(raw_dt) == 8 and sh_wan and sh_wan > 0:
                        dt_fmt = f"{raw_dt[:4]}-{raw_dt[4:6]}-{raw_dt[6:8]}"
                        share_map[dt_fmt] = round(sh_wan * 10000.0, 2)
    except Exception as exc:
        logging.debug("Tushare 获取 %s 历史份额异常: %s", symbol, exc)

    return share_map


def update_etf_share_archive(
    quote: Quote, trade_date: str, bars: list[DailyBar] | None = None
) -> dict[str, Any]:
    """按日归档 ETF 份额，自动回填官方历史份额序列，计算近1日/5日/20日份额变化率与净申赎趋势。"""
    shares = quote.total_shares
    if shares is None and quote.total_market_value and quote.current_price:
        shares = quote.total_market_value / quote.current_price
    if not shares or shares <= 0:
        return {"available": False, "usable_for_scoring": False, "reason": "未取得有效总份额或总市值"}

    data_dir = SKILL_DIR / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    path = data_dir / f"etf_share_history_{quote.symbol}.json"
    legacy_path = Path(f"/media/vdb/PycharmProjects/pythonProject/stock/data/etf_share_history_{quote.symbol}.json")

    records: list[dict[str, Any]] = []
    for p in (legacy_path, path):
        if p.exists():
            try:
                loaded = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(loaded, list):
                    records.extend(x for x in loaded if isinstance(x, dict))
            except Exception:
                continue

    dedup: dict[str, dict[str, Any]] = {
        _clean_text(r.get("trade_date")): r for r in records if _clean_text(r.get("trade_date"))
    }

    price_by_date: dict[str, float] = {}
    if bars:
        for b in bars:
            if b.date and b.close is not None:
                price_by_date[b.date[:10]] = b.close

    # 若本地有效历史交易日不足 22 天，或缺少近期连续序列，自动拉取远程官方历史份额回填
    remote_shares = _fetch_remote_etf_share_history(quote.symbol, quote.market, limit=35)
    for dt_str, sh_val in remote_shares.items():
        hist_p = price_by_date.get(dt_str)
        existing = dedup.get(dt_str) or {}
        dedup[dt_str] = {
            "trade_date": dt_str,
            "known_at": existing.get("known_at") or quote.collected_at,
            "price": existing.get("price") or hist_p,
            "total_market_value": (
                round(sh_val * hist_p, 2) if hist_p else existing.get("total_market_value")
            ),
            "estimated_shares": sh_val,
            "source": "official_fund_share",
        }

    # 今日最新份额：若远程已披露今日官方份额则优先采用，否则使用实时行情的 total_shares
    today_shares = remote_shares.get(trade_date) or round(shares, 2)
    dedup[trade_date] = {
        "trade_date": trade_date,
        "known_at": quote.collected_at,
        "price": quote.current_price,
        "total_market_value": quote.total_market_value,
        "estimated_shares": today_shares,
    }
    sorted_dates = sorted(d for d in dedup if _num(dedup[d].get("estimated_shares")))
    sorted_records = [dedup[k] for k in sorted_dates][-400:]
    path.write_text(json.dumps(sorted_records, ensure_ascii=False, indent=2), encoding="utf-8")

    shares_yi = round(today_shares / 1e8, 2)
    mv_yi = round(quote.total_market_value / 1e8, 2) if quote.total_market_value else None

    prev_dates = [d for d in sorted_dates if d < trade_date]
    if not prev_dates:
        return {
            "available": True,
            "usable_for_scoring": False,
            "status": "baseline_only",
            "current_trade_date": trade_date,
            "shares_yi": shares_yi,
            "market_value_yi": mv_yi,
            "note": "首次建立份额归档基线",
        }

    def _calc_window(lookback_idx: int) -> dict[str, Any]:
        if len(prev_dates) < lookback_idx:
            base_dt = prev_dates[0]
        else:
            base_dt = prev_dates[-lookback_idx]
        base_rec = dedup[base_dt]
        base_sh = _num(base_rec.get("estimated_shares"))
        chg_pct = _pct_change(today_shares, base_sh, digits=2)
        suspected_split = bool(chg_pct is not None and abs(chg_pct) >= ETF_SHARE_CHANGE_SUSPECT_PCT)
        diff_sh_yi = round((today_shares - base_sh) / 1e8, 2) if base_sh and not suspected_split else None
        ref_price = quote.current_price or price_by_date.get(trade_date) or _num(base_rec.get("price")) or 1.0
        net_amt_yi = (
            round((today_shares - base_sh) * ref_price / 1e8, 2)
            if base_sh and not suspected_split
            else None
        )
        return {
            "base_date": base_dt,
            "base_shares_yi": round(base_sh / 1e8, 2) if base_sh else None,
            "share_change_pct": chg_pct,
            "net_shares_yi": diff_sh_yi,
            "net_amount_yi": net_amt_yi,
            "suspected_split": suspected_split,
        }

    w1 = _calc_window(1)
    w5 = _calc_window(5)
    w20 = _calc_window(20)

    # 统计近5个交易日每日净申购/净赎回天数
    recent_6_dates = (prev_dates + [trade_date])[-6:]
    inflow_5d = outflow_5d = flat_5d = 0
    for i in range(1, len(recent_6_dates)):
        s_cur = _num(dedup[recent_6_dates[i]].get("estimated_shares"))
        s_prv = _num(dedup[recent_6_dates[i - 1]].get("estimated_shares"))
        if s_cur and s_prv:
            if s_cur - s_prv > 10000:
                inflow_5d += 1
            elif s_cur - s_prv < -10000:
                outflow_5d += 1
            else:
                flat_5d += 1

    # 近20日份额分位数
    recent_20_shares = [
        _num(dedup[d].get("estimated_shares"))
        for d in (prev_dates + [trade_date])[-20:]
        if _num(dedup[d].get("estimated_shares")) is not None
    ]
    sh_pctile_20d = (
        round(sum(1 for x in recent_20_shares if x <= today_shares) / len(recent_20_shares) * 100.0, 1)
        if recent_20_shares
        else None
    )

    chg_pct = w1["share_change_pct"]
    suspected = w1["suspected_split"]
    p_chg = quote.change_percent or 0.0
    s_chg = chg_pct or 0.0
    if suspected:
        state_cn = "疑似份额折算/拆分（不计入申赎）"
    elif s_chg > 0.05 and p_chg > 0:
        state_cn = "价涨份额增（资金顺势净申购）"
    elif s_chg > 0.05 and p_chg <= 0:
        state_cn = "价跌份额增（资金逢低抄底净申购）"
    elif s_chg < -0.05 and p_chg > 0:
        state_cn = "价涨份额减（资金逢高赎回兑现）"
    elif s_chg < -0.05 and p_chg <= 0:
        state_cn = "价跌份额减（资金流出）"
    else:
        state_cn = "单日份额基本稳定"

    # 近5日/20日趋势定性
    s5 = w5.get("share_change_pct") or 0.0
    s20 = w20.get("share_change_pct") or 0.0
    if s5 >= 1.0 and s20 >= 2.0:
        trend_summary = f"近5日/20日持续显著净申购（5日{s5:+.2f}% / 20日{s20:+.2f}%，大资金逆势/顺势持续流入）"
    elif s5 <= -1.0 and s20 <= -2.0:
        trend_summary = f"近5日/20日持续净赎回（5日{s5:+.2f}% / 20日{s20:+.2f}%，场内资金阶段性流出）"
    elif s5 >= 0.5 and s20 < 0:
        trend_summary = f"近20日偏流出但近5日转为净申购回流（5日{s5:+.2f}% / 20日{s20:+.2f}%）"
    elif s5 <= -0.5 and s20 > 0:
        trend_summary = f"近20日总体净申购但近5日出现阶段赎回（5日{s5:+.2f}% / 20日{s20:+.2f}%）"
    else:
        trend_summary = f"中短期份额总体平稳（5日{s5:+.2f}% / 20日{s20:+.2f}%）"

    return {
        "available": True,
        "usable_for_scoring": not suspected,
        "status": state_cn,
        "trend_5d_20d_summary": trend_summary,
        "current_trade_date": trade_date,
        "previous_trade_date": w1["base_date"],
        "shares_yi": shares_yi,
        "market_value_yi": mv_yi,
        "share_percentile_20d_pct": sh_pctile_20d,
        "share_change_pct": chg_pct,
        "net_creation_shares_yi": w1["net_shares_yi"],
        "net_creation_amount_yi": w1["net_amount_yi"],
        "change_1d": w1,
        "change_5d": {
            **w5,
            "inflow_days": inflow_5d,
            "outflow_days": outflow_5d,
            "flat_days": flat_5d,
        },
        "change_20d": w20,
        "recent_share_series": [
            {
                "date": d,
                "shares_yi": round((_num(dedup[d].get("estimated_shares")) or 0) / 1e8, 2),
                "price": dedup[d].get("price") or price_by_date.get(d),
            }
            for d in (prev_dates + [trade_date])[-10:]
        ],
    }


def fetch_market_and_overseas_context() -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    """一次批量获取 A 股核心风格基准与海外隔夜市场行情。"""
    a_codes = [tc for _, tc in MARKET_REFERENCES.values()]
    us_codes = [tc for tc, _ in OVERSEAS_REFERENCES.values()]
    quotes = fetch_tencent_quotes(a_codes + us_codes)

    market_ctx: list[dict[str, Any]] = []
    for name, (secid, tc) in MARKET_REFERENCES.items():
        q = quotes.get(tc)
        if q:
            market_ctx.append(
                {
                    "名称": name,
                    "代码": q.symbol,
                    "最新价": q.current_price,
                    "涨跌幅_pct": q.change_percent,
                    "成交额_亿": round(q.amount / 1e8, 2) if q.amount else None,
                    "振幅_pct": q.amplitude_percent,
                }
            )

    overseas_ctx: dict[str, dict[str, Any]] = {}
    for key, (tc, name) in OVERSEAS_REFERENCES.items():
        q = quotes.get(tc)
        if q:
            overseas_ctx[key] = {
                "name": name,
                "symbol": q.symbol,
                "price": q.current_price,
                "change_percent": q.change_percent,
                "quote_time": q.quote_time,
                "high_52w": q.high_52w,
                "low_52w": q.low_52w,
            }
    return market_ctx, overseas_ctx


def fetch_global_macro_and_commodities() -> dict[str, dict[str, Any]]:
    """获取亚太股指(韩国KOSPI/日经225)、费城半导体、美债/中债10年期收益率、美元/离岸人民币汇率及原油/黄金/棕榈油行情。"""
    session = _session()
    results: dict[str, dict[str, Any]] = {}

    def _fetch_one(key: str, secid: str, name: str, category: str) -> tuple[str, dict[str, Any] | None]:
        for base in EASTMONEY_HISTORY_BASES:
            try:
                resp = session.get(
                    f"{base}/stock/kline/get",
                    params={
                        "secid": secid,
                        "klt": "101",
                        "fqt": "1",
                        "lmt": "6",
                        "end": "20500101",
                        "fields1": "f1,f2,f3",
                        "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
                    },
                    headers={"Referer": "https://quote.eastmoney.com/"},
                    timeout=6,
                )
                if resp.status_code != 200:
                    continue
                klines = ((resp.json().get("data") or {}).get("klines")) or []
                if not klines:
                    continue
                last = str(klines[-1]).split(",")
                prev = str(klines[-2]).split(",") if len(klines) >= 2 else None
                first = str(klines[0]).split(",")
                close_now = _num(last[2])
                close_first = _num(first[2])
                ret_5d = _pct_change(close_now, close_first, digits=2) if len(klines) >= 5 else None
                return key, {
                    "name": name,
                    "secid": secid,
                    "category": category,
                    "date": last[0],
                    "price": close_now,
                    "change_pct": _num(last[8]),
                    "prev_change_pct": _num(prev[8]) if prev and len(prev) > 8 else None,
                    "return_5d_pct": ret_5d,
                    "high": _num(last[3]),
                    "low": _num(last[4]),
                }
            except Exception:
                continue
        return key, None

    with ThreadPoolExecutor(max_workers=6) as pool:
        futs = [
            pool.submit(_fetch_one, k, sid, name, cat)
            for k, (sid, name, cat) in GLOBAL_MACRO_TARGETS.items()
        ]
        for fut in as_completed(futs):
            try:
                k, val = fut.result()
                if val:
                    results[k] = val
            except Exception:
                continue
    return {k: results[k] for k in GLOBAL_MACRO_TARGETS if k in results}


def _trading_elapsed_minutes(now: datetime) -> int | None:
    """计算 A 股当日已交易分钟数（0~240），盘后或周末返回 240。"""
    if now.weekday() >= 5:
        return 240
    hm = now.hour * 60 + now.minute
    open_am, close_am = 9 * 60 + 30, 11 * 60 + 30
    open_pm, close_pm = 13 * 60, 15 * 60
    if hm < open_am:
        return 0
    if hm <= close_am:
        return max(1, hm - open_am)
    if hm < open_pm:
        return 120
    if hm <= close_pm:
        return 120 + (hm - open_pm)
    return 240


def fetch_market_breadth_and_volume(analysis_time: datetime) -> dict[str, Any]:
    """获取全A(沪深两市)实时涨跌家数宽度、历史总成交额及相对60日/120日峰值的缩量率(<45%阶段低点指标)。"""
    session = _session()
    breadth: dict[str, Any] = {}
    for base in (EASTMONEY_BASE, EASTMONEY_DELAY_BASE):
        try:
            r = session.get(
                f"{base}/ulist.np/get",
                params={
                    "fltt": "2",
                    "invt": "2",
                    "fields": "f12,f14,f2,f3,f6,f104,f105,f106",
                    "secids": "1.000001,0.399001",
                },
                headers={"Referer": "https://quote.eastmoney.com/"},
                timeout=6,
            )
            diffs = ((r.json().get("data") or {}).get("diff")) or []
            if diffs:
                up_total = sum(int(_num(d.get("f104")) or 0) for d in diffs)
                down_total = sum(int(_num(d.get("f105")) or 0) for d in diffs)
                flat_total = sum(int(_num(d.get("f106")) or 0) for d in diffs)
                rt_amt_yi = round(sum((_num(d.get("f6")) or 0.0) for d in diffs) / 1e8, 2)
                total_stocks = up_total + down_total + flat_total
                breadth = {
                    "up_count": up_total,
                    "down_count": down_total,
                    "flat_count": flat_total,
                    "up_ratio_pct": round(up_total / total_stocks * 100.0, 1) if total_stocks > 0 else None,
                    "realtime_total_amount_yi": rt_amt_yi,
                }
                break
        except Exception:
            continue

    def _idx_daily_amt(secid: str) -> dict[str, float]:
        for base in EASTMONEY_HISTORY_BASES:
            try:
                r = session.get(
                    f"{base}/stock/kline/get",
                    params={
                        "secid": secid,
                        "klt": "101",
                        "fqt": "1",
                        "lmt": "130",
                        "end": "20500101",
                        "fields1": "f1,f2,f3",
                        "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
                    },
                    headers={"Referer": "https://quote.eastmoney.com/"},
                    timeout=6,
                )
                kl = ((r.json().get("data") or {}).get("klines")) or []
                if kl:
                    res: dict[str, float] = {}
                    for item in kl:
                        ps = str(item).split(",")
                        if len(ps) >= 7 and _num(ps[6]) is not None:
                            res[ps[0]] = float(ps[6]) / 1e8
                    return res
            except Exception:
                continue
        return {}

    sh_amt = _idx_daily_amt("1.000001")
    sz_amt = _idx_daily_amt("0.399001")
    common_dates = sorted(set(sh_amt.keys()) & set(sz_amt.keys()))
    if not common_dates:
        return {"available": False, **breadth}

    daily_totals = [(d, round(sh_amt[d] + sz_amt[d], 2)) for d in common_dates]
    today_str = analysis_time.strftime("%Y-%m-%d")
    elapsed_min = _trading_elapsed_minutes(analysis_time) or 240
    is_intraday = daily_totals[-1][0] == today_str and 0 < elapsed_min < 240

    full_days = daily_totals[:-1] if is_intraday and len(daily_totals) >= 2 else daily_totals
    peak_60 = max(full_days[-60:], key=lambda x: x[1])
    peak_120 = max(full_days[-120:], key=lambda x: x[1])
    last_full_date, last_full_amt = full_days[-1]
    min_5d_date, min_5d_amt = min(full_days[-5:], key=lambda x: x[1])
    avg_5d_amt = round(mean([x[1] for x in full_days[-5:]]), 2)
    avg_20d_amt = round(mean([x[1] for x in full_days[-20:]]), 2)

    last_vs_60 = round(last_full_amt / peak_60[1] * 100.0, 1) if peak_60[1] > 0 else None
    last_vs_120 = round(last_full_amt / peak_120[1] * 100.0, 1) if peak_120[1] > 0 else None
    min5_vs_60 = round(min_5d_amt / peak_60[1] * 100.0, 1) if peak_60[1] > 0 else None
    min5_vs_120 = round(min_5d_amt / peak_120[1] * 100.0, 1) if peak_120[1] > 0 else None

    est_full_today_yi = None
    est_vs_60 = None
    est_vs_120 = None
    if is_intraday:
        cur_amt = breadth.get("realtime_total_amount_yi") or daily_totals[-1][1]
        est_full_today_yi = round(cur_amt * (240.0 / max(elapsed_min, 15)), 2)
        est_vs_60 = round(est_full_today_yi / peak_60[1] * 100.0, 1) if peak_60[1] > 0 else None
        est_vs_120 = round(est_full_today_yi / peak_120[1] * 100.0, 1) if peak_120[1] > 0 else None

    # 判定是否处于 <45% 阶段缩量低点区域
    ref_ratios = [r for r in (last_vs_120, min5_vs_120, last_vs_60, min5_vs_60) if r is not None]
    min_ratio = min(ref_ratios) if ref_ratios else None
    if min_ratio is not None and min_ratio <= 45.0:
        shrink_status = f"已触及<45%阶段缩量低点区域（最低缩至峰值 {min_ratio}%，关注后续放量右侧信号）"
    elif min_ratio is not None and min_ratio <= 52.0:
        shrink_status = f"临近45%缩量阈值区（近期最低缩至峰值 {min_ratio}%）"
    else:
        shrink_status = f"量能常态区间（近期最低占峰值 {min_ratio}%）"

    return {
        "available": True,
        **breadth,
        "is_intraday": is_intraday,
        "elapsed_trading_minutes": elapsed_min,
        "estimated_full_day_amount_yi": est_full_today_yi,
        "estimated_vs_60d_peak_pct": est_vs_60,
        "estimated_vs_120d_peak_pct": est_vs_120,
        "last_full_day_date": last_full_date,
        "last_full_day_amount_yi": last_full_amt,
        "last_full_vs_60d_peak_pct": last_vs_60,
        "last_full_vs_120d_peak_pct": last_vs_120,
        "min_5d_full_date": min_5d_date,
        "min_5d_full_amount_yi": min_5d_amt,
        "min_5d_vs_60d_peak_pct": min5_vs_60,
        "min_5d_vs_120d_peak_pct": min5_vs_120,
        "avg_5d_amount_yi": avg_5d_amt,
        "avg_20d_amount_yi": avg_20d_amt,
        "peak_60d_date": peak_60[0],
        "peak_60d_amount_yi": peak_60[1],
        "peak_120d_date": peak_120[0],
        "peak_120d_amount_yi": peak_120[1],
        "volume_shrinkage_status": shrink_status,
        "recent_10d_amounts_yi": [{"date": d, "amount_yi": a} for d, a in daily_totals[-10:]],
    }


def fetch_global_fast_news(limit: int = 15) -> list[dict[str, Any]]:
    """获取东方财富 7×24 小时全球宏观、海外市场与核心产业硬核快讯（自动过滤ETF营销软文）。"""
    session = _session()
    merged: dict[str, dict[str, Any]] = {}
    columns = (("101", "焦点要闻"), ("105", "国际宏观"), ("102", "7×24快讯"))
    priority_re = re.compile(
        r"(美联储|CPI|非农|加息|降息|美债|国债|央行|汇率|熔断|暴跌|救市|外资|IEA|原油|黄金|厄尔尼诺|"
        r"台积电|英伟达|Anthropic|OpenAI|微软|苹果|高通|阿斯麦|CoreWeave|存储|HBM|DDR|长鑫|寒武纪|海光|"
        r"中际旭创|新易盛|光模块|算力|半导体|芯片|宁德时代|储能|电网|核电|电价|煤炭|红利)",
        re.I,
    )
    for col_id, col_name in columns:
        try:
            r = session.get(
                EASTMONEY_FAST_NEWS_URL,
                params={
                    "client": "web",
                    "biz": "web_724",
                    "fastColumn": col_id,
                    "sortEnd": "",
                    "pageSize": "25",
                    "req_trace": "1",
                },
                headers={"Referer": "https://www.eastmoney.com/"},
                timeout=6,
            )
            rows = ((r.json().get("data") or {}).get("fastNewsList")) or []
            for row in rows:
                code = str(row.get("code") or "")
                title = _clean_text(row.get("title"))
                summary = _clean_text(row.get("summary"))
                text = f"{title} {summary}".strip()
                if not text or ETF_SOFT_AD_RE.search(text):
                    continue
                show_time = _clean_text(row.get("showTime"))
                is_key = bool(priority_re.search(text))
                key = code or f"{show_time}_{title[:30]}"
                if key not in merged:
                    merged[key] = {
                        "time": show_time,
                        "category": col_name,
                        "title": title or summary[:80],
                        "summary": summary[:280],
                        "is_priority": is_key,
                    }
        except Exception:
            continue

    items = list(merged.values())
    items.sort(key=lambda x: (1 if x["is_priority"] else 0, x["time"]), reverse=True)
    return items[:limit]


def build_news_keywords(
    symbol: str,
    fund_name: str,
    *,
    index_name: str | None = None,
    constituents: list[dict[str, Any]] | None = None,
    extra_keywords: Iterable[str] = (),
) -> list[str]:
    """根据基金名称、跟踪指数、前十大重仓股与预置主题词构建新闻检索关键词。"""
    clean_name = re.sub(r"ETF.*$", "ETF", fund_name) if "ETF" in fund_name else fund_name
    keywords: list[str] = [symbol, clean_name]
    if index_name:
        idx_short = re.sub(r"(主题|指数|证券|收益率|\(.*?\))", "", index_name).strip()
        if idx_short and len(idx_short) >= 2:
            keywords.append(idx_short)

    if constituents:
        top_names = [c["name"] for c in constituents[:5] if c.get("name")]
        if len(top_names) >= 2:
            keywords.append(f"{top_names[0]} {top_names[1]}")
        for n in top_names[:3]:
            keywords.append(n)

    combined_text = f"{fund_name} {index_name or ''}".lower()
    matched = False
    for preset in THEME_PRESETS.values():
        if any(t.lower() in combined_text for t in preset["triggers"]):
            keywords.extend(preset["keywords"])
            matched = True
    if not matched:
        keywords.extend((f"{clean_name}", "A股 ETF 资金", "央行 宏观政策"))

    keywords.extend(_clean_text(x) for x in extra_keywords if _clean_text(x))
    return [k for k in dict.fromkeys(keywords) if k][:14]


def fetch_relevant_news(
    keywords: Iterable[str],
    *,
    constituents: list[dict[str, Any]] | None = None,
    cutoff: datetime,
    days: int = DEFAULT_NEWS_DAYS,
    limit: int = DEFAULT_NEWS_LIMIT,
) -> list[dict[str, Any]]:
    """按主题词与重仓股检索东方财富新闻，去重、过滤时间并按相关性排序。"""
    session = _session()
    keyword_list = list(keywords)
    start = cutoff - timedelta(days=days)
    merged: dict[str, dict[str, Any]] = {}
    stock_names = [c["name"] for c in (constituents or []) if c.get("name")]

    for kw in keyword_list:
        try:
            rows = search_eastmoney_news(kw, session=session, page_size=8)
        except Exception as exc:
            logging.debug("东方财富新闻检索跳过 (%s): %s", kw, exc)
            continue
        for row in rows:
            published = _parse_dt(row.get("date"))
            if published is None or published < start or published > cutoff + timedelta(minutes=10):
                continue
            title = _strip_html(row.get("title"))
            summary = _strip_html(row.get("content"))
            url = _clean_text(row.get("url")).replace("http://", "https://", 1)
            if not title or not url:
                continue
            item = merged.setdefault(
                url,
                {
                    "time": published.isoformat(sep=" ", timespec="seconds"),
                    "title": title,
                    "summary": summary[:450],
                    "source": _clean_text(row.get("mediaName")) or "东方财富",
                    "url": url,
                    "matched_keywords": [],
                    "matched_constituents": [],
                },
            )
            if kw not in item["matched_keywords"]:
                item["matched_keywords"].append(kw)

    items = list(merged.values())
    for item in items:
        text = f"{item['title']} {item['summary']}".lower()
        title_l = item["title"].lower()
        for sn in stock_names:
            if sn.lower() in text and sn not in item["matched_constituents"]:
                item["matched_constituents"].append(sn)
        score = sum(
            3 if kw.lower() in title_l else 1
            for kw in keyword_list
            if any(part.lower() in text for part in kw.split())
        )
        score += len(item["matched_keywords"]) * 2 + len(item["matched_constituents"]) * 4
        if ETF_SOFT_AD_RE.search(item["title"]):
            score = max(1, score - 12)
            item["is_etf_marketing"] = True
        else:
            item["is_etf_marketing"] = False
        item["relevance_score"] = score

    items.sort(key=lambda x: (x["relevance_score"], x["time"]), reverse=True)
    return items[:limit]


def search_eastmoney_news(keyword: str, *, session: requests.Session, page_size: int = 8) -> list[dict[str, Any]]:
    search_param = {
        "uid": "",
        "keyword": keyword,
        "type": ["cmsArticleWebOld"],
        "client": "web",
        "clientType": "web",
        "clientVersion": "curr",
        "param": {
            "cmsArticleWebOld": {
                "searchScope": "default",
                "sort": "time",
                "pageIndex": 1,
                "pageSize": page_size,
                "preTag": "",
                "postTag": "",
            }
        },
    }
    url = EASTMONEY_SEARCH_URL + "?" + urlencode(
        {"cb": "callback", "param": json.dumps(search_param, ensure_ascii=False, separators=(",", ":"))}
    )
    resp = session.get(url, headers={"Referer": "https://so.eastmoney.com/"}, timeout=REQUEST_TIMEOUT)
    resp.raise_for_status()
    text = resp.text
    s_idx, e_idx = text.find("{"), text.rfind("}")
    if s_idx < 0 or e_idx < s_idx:
        return []
    payload = json.loads(text[s_idx : e_idx + 1])
    return ((payload.get("result") or {}).get("cmsArticleWebOld")) or []


def _parse_dt(value: Any) -> datetime | None:
    text = _clean_text(value).replace("T", " ").removesuffix("Z")
    if not text:
        return None
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def market_phase(value: datetime) -> str:
    if value.weekday() >= 5:
        return "周末自然休市时段"
    clock = value.strftime("%H:%M")
    if clock < "09:30":
        return "盘前时段"
    if "09:30" <= clock <= "11:30" or "13:00" <= clock <= "15:00":
        return "盘中连续竞价时段"
    if "11:30" < clock < "13:00":
        return "午间休市时段"
    return "盘后已收盘时段"


# ============================================================================
# 4.5 实时主观参考：知名博主（如雪球“搬砖小组”等）最新专栏与复盘采集
# ============================================================================

KOL_SOURCES_FILE = SKILL_DIR / "data" / "kol_sources.json"
XUEQIU_COOKIE_CACHE = SKILL_DIR / "data" / "xueqiu_cookies.json"
DEFAULT_KOL_LIMIT = 2

DEFAULT_KOL_SOURCES: list[dict[str, Any]] = [
    {
        "id": "2817386050",
        "name": "搬砖小组",
        "platform": "xueqiu",
        "url": "https://www.xueqiu.com/u/2817386050",
        "style": "买方投研/全球宏观与产业高频数据日更复盘",
        "enabled": True,
        "max_articles": DEFAULT_KOL_LIMIT,
    }
]


def _extract_xueqiu_uid(raw: str) -> str:
    """从 UID 字符串、用户主页 URL 或帖子 URL 中提取雪球用户 ID。"""
    text = str(raw or "").strip()
    if text.isdigit():
        return text
    m_user = re.search(r"xueqiu\.com/u/(\d+)", text)
    if m_user:
        return m_user.group(1)
    m_post = re.search(r"xueqiu\.com/(\d{5,})/\d+", text)
    if m_post:
        return m_post.group(1)
    m_num = re.search(r"(\d{6,})", text)
    return m_num.group(1) if m_num else text


def load_kol_sources(extra_users: Iterable[str] = (), limit_override: int | None = None) -> list[dict[str, Any]]:
    """加载知名博主配置列表（data/kol_sources.json），并合并命令行临时指定的博主。"""
    KOL_SOURCES_FILE.parent.mkdir(parents=True, exist_ok=True)
    sources: list[dict[str, Any]] = []
    if KOL_SOURCES_FILE.exists():
        try:
            loaded = json.loads(KOL_SOURCES_FILE.read_text(encoding="utf-8"))
            if isinstance(loaded, list):
                sources = [s for s in loaded if isinstance(s, dict) and s.get("enabled", True)]
        except Exception as exc:
            logging.warning("读取 %s 失败，使用默认博主配置: %s", KOL_SOURCES_FILE, exc)
    if not sources:
        sources = [dict(item) for item in DEFAULT_KOL_SOURCES]
        try:
            KOL_SOURCES_FILE.write_text(json.dumps(sources, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    by_id: dict[str, dict[str, Any]] = {}
    for s in sources:
        uid = _extract_xueqiu_uid(s.get("id") or s.get("url") or "")
        if not uid:
            continue
        entry = dict(s)
        entry["id"] = uid
        entry.setdefault("name", f"雪球博主_{uid}")
        entry.setdefault("platform", "xueqiu")
        entry.setdefault("url", f"https://www.xueqiu.com/u/{uid}")
        entry.setdefault("style", "市场观察与复盘")
        entry["max_articles"] = int(limit_override or entry.get("max_articles") or DEFAULT_KOL_LIMIT)
        by_id[uid] = entry

    for raw_u in extra_users or ():
        for part in str(raw_u).replace(",", " ").split():
            uid = _extract_xueqiu_uid(part)
            if not uid:
                continue
            if uid in by_id:
                if limit_override:
                    by_id[uid]["max_articles"] = int(limit_override)
            else:
                by_id[uid] = {
                    "id": uid,
                    "name": f"雪球博主_{uid}",
                    "platform": "xueqiu",
                    "url": f"https://www.xueqiu.com/u/{uid}",
                    "style": "自定义关注博主",
                    "enabled": True,
                    "max_articles": int(limit_override or DEFAULT_KOL_LIMIT),
                }
    return list(by_id.values())


def add_kol_source_to_config(raw_uid_or_url: str, name: str = "", style: str = "市场观点与复盘") -> dict[str, Any]:
    """将新博主持久化写入 data/kol_sources.json。"""
    uid = _extract_xueqiu_uid(raw_uid_or_url)
    if not uid:
        raise ValueError(f"无法从 {raw_uid_or_url!r} 解析出有效的博主 ID")
    KOL_SOURCES_FILE.parent.mkdir(parents=True, exist_ok=True)
    existing: list[dict[str, Any]] = []
    if KOL_SOURCES_FILE.exists():
        try:
            existing = json.loads(KOL_SOURCES_FILE.read_text(encoding="utf-8"))
            if not isinstance(existing, list):
                existing = []
        except Exception:
            existing = []
    if not existing:
        existing = [dict(item) for item in DEFAULT_KOL_SOURCES]

    target: dict[str, Any] | None = None
    for item in existing:
        if _extract_xueqiu_uid(item.get("id") or "") == uid:
            target = item
            break
    if target is None:
        target = {
            "id": uid,
            "name": name or f"雪球博主_{uid}",
            "platform": "xueqiu",
            "url": f"https://www.xueqiu.com/u/{uid}",
            "style": style or "市场观点与复盘",
            "enabled": True,
            "max_articles": DEFAULT_KOL_LIMIT,
        }
        existing.append(target)
    else:
        if name:
            target["name"] = name
        if style:
            target["style"] = style
        target["enabled"] = True

    KOL_SOURCES_FILE.write_text(json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def _clean_xueqiu_article_html(raw_html: str) -> str:
    """将雪球专栏/帖子 HTML 正文清洗为保留段落结构的纯文本，并去除底部固定免责声明。"""
    if not raw_html:
        return ""
    text = re.sub(r"(?i)<\s*br\s*/?\s*>", "\n", raw_html)
    text = re.sub(r"(?i)</\s*(p|div|li|blockquote|h[1-6]|tr)\s*>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = html.unescape(text)
    text = text.replace("\xa0", " ").replace("\u200b", "")
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in text.splitlines()]
    cleaned_lines: list[str] = []
    for ln in lines:
        if not ln:
            if cleaned_lines and cleaned_lines[-1] != "":
                cleaned_lines.append("")
            continue
        if (
            ln.startswith("素材来源：")
            or ln.startswith("风险提示：文中提及到上市公司")
            or ln.startswith("本资料所引用的观点")
            or ln.startswith("从业人员信息公示：")
        ):
            continue
        cleaned_lines.append(ln)
    while cleaned_lines and cleaned_lines[-1] == "":
        cleaned_lines.pop()
    return "\n".join(cleaned_lines).strip()


def _load_cached_xueqiu_cookie() -> str | None:
    if not XUEQIU_COOKIE_CACHE.exists():
        return None
    try:
        payload = json.loads(XUEQIU_COOKIE_CACHE.read_text(encoding="utf-8"))
        return payload.get("cookie_str") or None
    except Exception:
        return None


def _save_cached_xueqiu_cookie(cookie_str: str) -> None:
    try:
        XUEQIU_COOKIE_CACHE.parent.mkdir(parents=True, exist_ok=True)
        XUEQIU_COOKIE_CACHE.write_text(
            json.dumps(
                {
                    "updated_at": datetime.now().isoformat(sep=" ", timespec="seconds"),
                    "cookie_str": cookie_str,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    except Exception as exc:
        logging.debug("保存雪球 Cookie 缓存失败: %s", exc)


def _refresh_xueqiu_cookie_via_playwright(seed_uid: str = "2817386050") -> str | None:
    """当无 Cookie 或触发阿里云 WAF 时，使用无头 Chrome 自动完成 JS 挑战并提取最新 Cookie。"""
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        logging.warning("Playwright 未安装或不可用，无法自动刷新雪球 WAF Cookie: %s", exc)
        return None

    chrome_candidates = [
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
    ]
    exec_path = next((p for p in chrome_candidates if Path(p).exists()), None)
    try:
        with sync_playwright() as p:
            launch_kwargs: dict[str, Any] = {
                "headless": True,
                "args": ["--no-sandbox", "--disable-blink-features=AutomationControlled"],
            }
            if exec_path:
                launch_kwargs["executable_path"] = exec_path
            browser = p.chromium.launch(**launch_kwargs)
            ctx = browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                ),
                ignore_https_errors=True,
            )
            page = ctx.new_page()
            page.goto(f"https://www.xueqiu.com/u/{seed_uid}", wait_until="domcontentloaded", timeout=22000)
            page.wait_for_timeout(3200)
            cookies = ctx.cookies()
            browser.close()
        cookie_str = "; ".join(f"{c['name']}={c['value']}" for c in cookies if c.get("name") and c.get("value"))
        if cookie_str and ("xq_a_token" in cookie_str or "acw_sc__v2" in cookie_str):
            _save_cached_xueqiu_cookie(cookie_str)
            return cookie_str
    except Exception as exc:
        logging.warning("Playwright 刷新雪球 WAF Cookie 失败: %s", exc)
    return None


def _xueqiu_get_json(url: str, *, cookie_str: str, referer: str) -> dict[str, Any] | None:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        "Cookie": cookie_str,
        "Referer": referer,
        "Accept": "application/json, text/plain, */*",
        "X-Requested-With": "XMLHttpRequest",
    }
    try:
        resp = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT, verify=False)
        if resp.status_code != 200:
            return None
        text = resp.text.strip()
        if not text.startswith("{"):
            return None
        data = json.loads(text)
        if isinstance(data, dict) and ("_waf_" in text[:200] or data.get("error_code")):
            return None
        return data
    except Exception:
        return None


def _fetch_single_xueqiu_kol(
    source: dict[str, Any],
    *,
    cookie_str: str,
) -> tuple[dict[str, Any] | None, bool]:
    """使用给定 cookie_str 抓取单个雪球博主的最新文章。返回 (结果字典, 是否因WAF需要刷新Cookie)。"""
    uid = str(source["id"])
    max_articles = int(source.get("max_articles") or DEFAULT_KOL_LIMIT)
    referer = f"https://www.xueqiu.com/u/{uid}"

    orig_data = _xueqiu_get_json(
        f"https://www.xueqiu.com/statuses/original/timeline.json?user_id={uid}&page=1",
        cookie_str=cookie_str,
        referer=referer,
    )
    tl_data = _xueqiu_get_json(
        f"https://www.xueqiu.com/v4/statuses/user_timeline.json?user_id={uid}&page=1&type=0",
        cookie_str=cookie_str,
        referer=referer,
    )
    if orig_data is None and tl_data is None:
        return None, True

    candidates: dict[int, dict[str, Any]] = {}
    for row in (orig_data or {}).get("list") or []:
        if isinstance(row, dict) and row.get("id"):
            candidates[int(row["id"])] = row
    for row in (tl_data or {}).get("statuses") or []:
        if isinstance(row, dict) and row.get("id") and int(row["id"]) not in candidates:
            candidates[int(row["id"])] = row

    sorted_posts = sorted(
        candidates.values(),
        key=lambda x: int(x.get("created_at") or 0),
        reverse=True,
    )[:max_articles]

    articles: list[dict[str, Any]] = []
    detected_name = source.get("name") or f"雪球博主_{uid}"
    for post in sorted_posts:
        post_id = post["id"]
        detail = _xueqiu_get_json(
            f"https://www.xueqiu.com/statuses/show.json?id={post_id}",
            cookie_str=cookie_str,
            referer=referer,
        )
        raw_obj = detail if isinstance(detail, dict) and detail.get("id") else post
        user_info = raw_obj.get("user") or {}
        if user_info.get("screen_name"):
            detected_name = user_info["screen_name"]
        created_ms = raw_obj.get("created_at") or post.get("created_at")
        pub_time = (
            datetime.fromtimestamp(int(created_ms) / 1000).strftime("%Y-%m-%d %H:%M:%S")
            if created_ms
            else None
        )
        raw_html = raw_obj.get("text") or raw_obj.get("description") or ""
        content = _clean_xueqiu_article_html(raw_html)
        title = _clean_text(raw_obj.get("title") or post.get("title") or "")
        if not title and content:
            first_line = content.splitlines()[0][:40]
            title = first_line + ("..." if len(content.splitlines()[0]) > 40 else "")
        articles.append(
            {
                "id": post_id,
                "title": title or f"动态_{post_id}",
                "published_at": pub_time,
                "url": f"https://www.xueqiu.com/{uid}/{post_id}",
                "view_count": post.get("view_count") or raw_obj.get("view_count"),
                "reply_count": raw_obj.get("reply_count"),
                "like_count": raw_obj.get("like_count"),
                "summary": content[:260].replace("\n", " ") + ("..." if len(content) > 260 else ""),
                "content": content,
            }
        )

    return {
        "id": uid,
        "name": detected_name,
        "platform": source.get("platform", "xueqiu"),
        "style": source.get("style", ""),
        "profile_url": referer,
        "article_count": len(articles),
        "articles": articles,
    }, False


def fetch_kol_columns(
    extra_users: Iterable[str] = (),
    *,
    limit_override: int | None = None,
) -> dict[str, Any]:
    """获取所有已配置知名博主的最新专栏/复盘文章（Cookie缓存极速直连 + Playwright无头浏览器自动降级）。"""
    sources = load_kol_sources(extra_users=extra_users, limit_override=limit_override)
    if not sources:
        return {"available": False, "kol_list": []}

    cookie_str = _load_cached_xueqiu_cookie()
    refreshed = False
    if not cookie_str:
        cookie_str = _refresh_xueqiu_cookie_via_playwright(seed_uid=sources[0]["id"])
        refreshed = True

    kol_results: list[dict[str, Any]] = []
    for src in sources:
        if src.get("platform", "xueqiu") != "xueqiu":
            continue
        res: dict[str, Any] | None = None
        need_refresh = True
        if cookie_str:
            res, need_refresh = _fetch_single_xueqiu_kol(src, cookie_str=cookie_str)
        if (res is None or need_refresh) and not refreshed:
            cookie_str = _refresh_xueqiu_cookie_via_playwright(seed_uid=src["id"])
            refreshed = True
            if cookie_str:
                res, _ = _fetch_single_xueqiu_kol(src, cookie_str=cookie_str)
        if res is not None:
            kol_results.append(res)
            if src.get("name", "").startswith("雪球博主_") and res.get("name") and not res["name"].startswith("雪球博主_"):
                try:
                    add_kol_source_to_config(src["id"], name=res["name"], style=src.get("style", ""))
                except Exception:
                    pass
        else:
            kol_results.append(
                {
                    "id": src["id"],
                    "name": src.get("name"),
                    "platform": src.get("platform", "xueqiu"),
                    "style": src.get("style", ""),
                    "profile_url": src.get("url"),
                    "article_count": 0,
                    "articles": [],
                    "error": "未能获取到最新专栏文章（可能触发访问保护或网络超时）",
                }
            )

    return {
        "available": any(k.get("article_count", 0) > 0 for k in kol_results),
        "config_file": str(KOL_SOURCES_FILE),
        "kol_count": len(kol_results),
        "kol_list": kol_results,
    }


def format_kol_markdown_section(kol_ctx: dict[str, Any] | None) -> str:
    """将知名博主最新专栏格式化为 Markdown 章节。"""
    if not kol_ctx or not kol_ctx.get("kol_list"):
        return ""
    lines: list[str] = []
    lines.append("## 实时主观参考：知名博主最新专栏与市场复盘（交叉验证源）")
    lines.append("")
    lines.append(
        f"> 配置文件：`{kol_ctx.get('config_file')}`（可通过编辑该 JSON 或使用 `--add-kol <雪球UID或链接> \"博主名\" \"风格\"` 随时追加新博主）"
    )
    for kol in kol_ctx.get("kol_list", []):
        lines.append("")
        style_str = f" | **风格定位**：{kol['style']}" if kol.get("style") else ""
        lines.append(f"### 博主：{kol.get('name')}（UID: `{kol.get('id')}`{style_str}）")
        articles = kol.get("articles") or []
        if not articles:
            lines.append(f"- 暂无最新文章（{kol.get('error') or '无数据'}）")
            continue
        for idx, art in enumerate(articles, 1):
            view_str = f" | 阅读 `{art['view_count']}`" if art.get("view_count") else ""
            lines.append(
                f"\n#### [{idx}] 《{art.get('title')}》 — 发布于 `{art.get('published_at')}`{view_str} ([原文链接]({art.get('url')}))"
            )
            lines.append("")
            lines.append(art.get("content") or art.get("summary") or "（无正文）")
    return "\n".join(lines) + "\n"


# ============================================================================
# 5. Markdown 客观信息汇总与主流程入口（纯信息获取，不含预测模块）
# ============================================================================


def format_markdown_report(data: dict[str, Any]) -> str:
    """将单只 ETF 采集到的全量客观信息格式化为 Markdown 报告。"""
    q = data["quote"]
    prof = data["fund_profile"]
    idx_val = prof.get("index_valuation") or {}
    tech = data["technical_summary"]
    w_tech = data.get("weekly_technical_summary") or {}
    comp = data["constituents_analysis"]
    flow = data["share_flow"]
    news = data["news"]

    lines: list[str] = []
    lines.append(f"## {q['name']}（{q['symbol']}）客观信息汇总")
    lines.append("")
    lines.append(f"- **采集时间**：{data['analysis_time']}（{data['market_phase']}） | **数据源**：{q.get('source')}")
    lines.append(
        f"- **实时行情**：最新价 **{q['current_price']}** | 涨跌幅 **{q['change_percent']:+.2f}%** ({q['change_amount']:+.4f}) "
        f"| 今开 {q['open_price']} | 最高 {q['high_price']} | 最低 {q['low_price']} | 昨收 {q['prev_close']}"
        if q.get("change_percent") is not None and q.get("change_amount") is not None
        else f"- **实时行情**：最新价 **{q.get('current_price')}**"
    )
    amt_yi = round(q["amount"] / 1e8, 2) if q.get("amount") else None
    mv_yi = round(q["total_market_value"] / 1e8, 2) if q.get("total_market_value") else None
    sh_yi = flow.get("shares_yi") or (round(q["total_shares"] / 1e8, 2) if q.get("total_shares") else None)
    lines.append(
        f"- **量能与折溢价**：分时均价(VWAP) `{q.get('avg_price')}` | 实时IOPV `{q.get('iopv')}` | 最新单位净值(NAV) `{q.get('nav') or prof.get('latest_nav')}` "
        f"| 折溢价率 `{q.get('premium_pct')}%` | 成交额 `{amt_yi}亿` | 换手率 `{q.get('turnover_rate')}%` | 量比 `{q.get('volume_ratio')}` | 振幅 `{q.get('amplitude_percent')}%`"
    )
    lines.append(
        f"- **盘口与资金流**：买一 `{q.get('bid1_price')}` ({q.get('bid1_volume')}手) / 卖一 `{q.get('ask1_price')}` ({q.get('ask1_volume')}手) "
        f"| 盘口失衡度 `{q.get('depth_imbalance')}` | 外盘主动买占比 `{round(q['active_buy_ratio'] * 100, 1) if q.get('active_buy_ratio') is not None else None}%`"
    )

    c1 = flow.get("change_1d") or {}
    c5 = flow.get("change_5d") or {}
    c20 = flow.get("change_20d") or {}
    s1_str = (
        f"较前日({c1.get('base_date')}) `{c1['share_change_pct']:+.2f}%` ({c1['net_shares_yi']:+.2f}亿份 / 约 `{c1['net_amount_yi']:+.2f}亿`)"
        if c1.get("share_change_pct") is not None and c1.get("net_amount_yi") is not None
        else "暂无单日对比"
    )
    s5_str = (
        f"近5日 `{c5['share_change_pct']:+.2f}%` ({c5['net_shares_yi']:+.2f}亿份 / 约 `{c5['net_amount_yi']:+.2f}亿`，{c5.get('inflow_days', 0)}日净申购/{c5.get('outflow_days', 0)}日净赎回)"
        if c5.get("share_change_pct") is not None and c5.get("net_amount_yi") is not None
        else "暂无5日对比"
    )
    s20_str = (
        f"近20日 `{c20['share_change_pct']:+.2f}%` ({c20['net_shares_yi']:+.2f}亿份 / 约 `{c20['net_amount_yi']:+.2f}亿`)"
        if c20.get("share_change_pct") is not None and c20.get("net_amount_yi") is not None
        else "暂无20日对比"
    )
    lines.append(
        f"- **场内规模与近1/5/20日份额申赎趋势**：场内总市值 `{mv_yi}亿` | 场内总份额 `{sh_yi}亿份`（20日份额分位 `{flow.get('share_percentile_20d_pct')}%`）  \n"
        f"  - **趋势定性**：**{flow.get('trend_5d_20d_summary') or flow.get('status', '未知')}**（单日状态：{flow.get('status', '未知')}）  \n"
        f"  - **1D / 5D / 20D 明细**：{s1_str} | {s5_str} | {s20_str}"
    )

    etf_mg = ((comp.get("margin_summary") or {}).get("etf_margin")) or {}
    if etf_mg.get("available"):
        lines.append(
            f"- **ETF自身两融数据（{etf_mg.get('date')}）**：融资余额 `{etf_mg.get('fin_balance_yi')}亿`（单日增幅 `{etf_mg.get('fin_change_1d_pct')}%`） "
            f"| 融资净买入：1日 `{etf_mg.get('fin_net_buy_1d_yi'):+.3f}亿` / 3日 `{etf_mg.get('fin_net_buy_3d_yi'):+.3f}亿` / 5日 `{etf_mg.get('fin_net_buy_5d_yi'):+.3f}亿` / 10日 `{etf_mg.get('fin_net_buy_10d_yi'):+.3f}亿` "
            f"| 融券余额 `{etf_mg.get('loan_balance_yi')}亿`"
        )

    lines.append("\n### 一、基金基本面与跟踪指数估值")
    lines.append(
        f"- **基金档案**：{prof.get('fund_company') or '-'} | 类型：{prof.get('fund_type') or '-'} | 成立日：{prof.get('establish_date') or '-'} "
        f"| 报告期规模：`{prof.get('report_scale_yi')}亿` ({prof.get('report_scale_date')}) | 年化跟踪误差：`{prof.get('tracking_error_pct')}%`"
    )
    lines.append(
        f"- **历史风险收益指标**：近1年夏普 `{prof.get('sharpe_1y')}` (近2年 `{prof.get('sharpe_2y')}` / 近3年 `{prof.get('sharpe_3y')}`) "
        f"| 近1年最大回撤 `{prof.get('max_drawdown_1y_pct')}%` | 近1年年化波动率 `{prof.get('volatility_1y_pct')}%`"
    )
    lines.append(
        f"- **跟踪指数**：**{idx_val.get('index_name')} ({idx_val.get('index_code')})**（估值日期：{idx_val.get('valuation_date')}，区间定位：{idx_val.get('valuation_status')}）"
    )
    lines.append(
        f"  - **PE(TTM)**：`{idx_val.get('pe_ttm')}`（历史分位数 **{idx_val.get('pe_percentile_pct')}%**） | **PB**：`{idx_val.get('pb')}`（历史分位数 **{idx_val.get('pb_percentile_pct')}%**）"
    )
    lines.append(
        f"  - **股息率**：`{idx_val.get('dividend_yield_pct')}%`"
        + (
            f"（较中债10Y `{idx_val.get('cn10y_yield_pct')}%` 溢价 `{idx_val.get('dividend_spread_vs_cn10y_pct'):+.2f}%`）"
            if idx_val.get("dividend_spread_vs_cn10y_pct") is not None
            else ""
        )
        + f" | **ROE**：`{idx_val.get('roe_pct')}%`"
        + (
            f" | **盈利收益率(E/P)**：`{idx_val.get('earnings_yield_ep_pct')}%`（股权风险溢价ERP `{idx_val.get('erp_vs_cn10y_pct'):+.2f}%`）"
            if idx_val.get("erp_vs_cn10y_pct") is not None
            else ""
        )
    )
    lines.append(
        f"  - **指数历史阶段涨跌**：近1周 `{idx_val.get('return_1w_pct')}%` / 近1月 `{idx_val.get('return_1m_pct')}%` / 近3月 `{idx_val.get('return_3m_pct')}%` / 近半年 `{idx_val.get('return_6m_pct')}%` / 近1年 `{idx_val.get('return_1y_pct')}%`"
    )
    if idx_val.get("profile"):
        lines.append(f"  - **指数简介**：{idx_val.get('profile')}")

    lines.append("\n### 二、前复权日K技术指标与历史价格分位数")
    lines.append(
        f"- **均线数值与偏离**：**{tech.get('ma_alignment')}** | MA5 `{tech.get('MA5')}` ({tech.get('close_vs_ma5_pct')}%) "
        f"| MA10 `{tech.get('MA10')}` ({tech.get('close_vs_ma10_pct')}%) | MA20 `{tech.get('MA20')}` ({tech.get('close_vs_ma20_pct')}%，5日斜率 `{tech.get('ma20_slope_5d_pct')}%`) "
        f"| MA60 `{tech.get('MA60')}` ({tech.get('close_vs_ma60_pct')}%，10日斜率 `{tech.get('ma60_slope_10d_pct')}%`) | MA120 `{tech.get('MA120')}` ({tech.get('close_vs_ma120_pct')}%) | MA250 `{tech.get('MA250')}` ({tech.get('close_vs_ma250_pct')}%)"
    )
    lines.append(
        f"- **阶段历史涨跌**：近3日 `{tech.get('return_3d_pct')}%` | 近5日 `{tech.get('return_5d_pct')}%` | 近10日 `{tech.get('return_10d_pct')}%` "
        f"| 近20日 `{tech.get('return_20d_pct')}%` | 近60日 `{tech.get('return_60d_pct')}%` | 近120日 `{tech.get('return_120d_pct')}%` | 近250日 `{tech.get('return_250d_pct')}%`"
    )
    macd_info = tech.get("macd") or {}
    lines.append(
        f"- **动量与波动指标**：RSI(14) `{tech.get('rsi14')}` | MACD `{macd_info.get('state')}` (DIF `{macd_info.get('dif')}`, DEA `{macd_info.get('dea')}`, Hist `{macd_info.get('histogram')}`) "
        f"| 20日ATR `{tech.get('atr20')}` ({tech.get('atr20_pct')}%) | 20日年化波动率 `{tech.get('annualized_volatility_20d_pct')}%` | 5日/20日均量比 `{tech.get('volume_5d_vs_20d_ratio')}`"
    )
    lines.append("")
    lines.append("| 周期窗口 | 最高价 | 最低价 | 区间位置 | 收盘价历史分位 | 距高点回撤 | 距低点反弹 |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|")
    for label, key in (("近1月(20日)", "range_20d"), ("近3月(60日)", "range_60d"), ("近半年(120日)", "range_120d"), ("近1年(250日)", "range_250d")):
        w = tech.get(key) or {}
        lines.append(
            f"| {label} | {w.get('high')} | {w.get('low')} | {w.get('position_pct')}% | **{w.get('close_percentile_pct')}%** | {w.get('drawdown_from_high_pct')}% | {w.get('rebound_from_low_pct')}% |"
        )
    lines.append("")
    lines.append(
        f"- **技术参考价位**：支撑位参考 `{tech.get('key_supports')}` | 压力位参考 `{tech.get('key_resistances')}` | 经典枢轴点(Pivot) `{tech.get('pivot_levels')}`"
    )

    lines.append("\n### 三、前复权周K线中长期技术指标与历史价格分位数")
    if w_tech.get("available"):
        wb = w_tech.get("weekly_boll") or {}
        w_macd = w_tech.get("weekly_macd") or {}
        lines.append(
            f"- **周线均线与偏离**：**{w_tech.get('weekly_ma_alignment')}** | WMA5 `{w_tech.get('WMA5')}` ({w_tech.get('close_vs_wma5_pct')}%) "
            f"| WMA10 `{w_tech.get('WMA10')}` ({w_tech.get('close_vs_wma10_pct')}%) | WMA20 `{w_tech.get('WMA20')}` ({w_tech.get('close_vs_wma20_pct')}%，4周斜率 `{w_tech.get('wma20_slope_4w_pct')}%`) "
            f"| WMA30 `{w_tech.get('WMA30')}` ({w_tech.get('close_vs_wma30_pct')}%) | WMA60 `{w_tech.get('WMA60')}` ({w_tech.get('close_vs_wma60_pct')}%，8周斜率 `{w_tech.get('wma60_slope_8w_pct')}%`) | WMA120 `{w_tech.get('WMA120')}` ({w_tech.get('close_vs_wma120_pct')}%)"
        )
        lines.append(
            f"- **周线阶段涨跌**：近1周 `{w_tech.get('return_1w_pct')}%` | 近2周 `{w_tech.get('return_2w_pct')}%` | 近4周 `{w_tech.get('return_4w_pct')}%` "
            f"| 近13周 `{w_tech.get('return_13w_pct')}%` | 近26周 `{w_tech.get('return_26w_pct')}%` | 近52周 `{w_tech.get('return_52w_pct')}%` | 近104周 `{w_tech.get('return_104w_pct')}%`"
        )
        lines.append(
            f"- **周线布林带 BOLL(20,2) 与动量**：中轨 `{wb.get('mid_wma20')}` / 上轨 `{wb.get('upper')}` / 下轨 `{wb.get('lower')}`（布林位置 %B = `{wb.get('percent_b')}%`） "
            f"| 周RSI(14) `{w_tech.get('weekly_rsi14')}` | 周MACD `{w_macd.get('state')}` (DIF `{w_macd.get('dif')}`, DEA `{w_macd.get('dea')}`, Hist `{w_macd.get('histogram')}`) | 14周ATR `{w_tech.get('weekly_atr14')}` ({w_tech.get('weekly_atr14_pct')}%)"
        )
        lines.append("")
        lines.append("| 周线窗口 | 周最高价 | 周最低价 | 周区间中位价 | 距中位偏离 | 周区间位置 | 周收盘历史分位 | 距高点回撤 | 距低点反弹 |")
        lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
        for label, key in (
            ("近1季(13周)", "range_13w"),
            ("近半年(26周)", "range_26w"),
            ("近1年(52周)", "range_52w"),
            ("近2年(104周)", "range_104w"),
        ):
            ww = w_tech.get(key) or {}
            vs_m = f"{ww['vs_mid_pct']:+.2f}%" if ww.get("vs_mid_pct") is not None else "-"
            lines.append(
                f"| {label} | {ww.get('high')} | {ww.get('low')} | {ww.get('mid_price')} | {vs_m} | {ww.get('position_pct')}% | **{ww.get('close_percentile_pct')}%** | {ww.get('drawdown_from_high_pct')}% | {ww.get('rebound_from_low_pct')}% |"
            )
    else:
        lines.append("- 暂无周K线数据。")

    lines.append("\n### 四、前十大重仓成分股行情、基本面财务增速与两融资金")
    if comp.get("available"):
        f_sum = comp.get("fundamentals_summary") or {}
        m_sum = comp.get("margin_summary") or {}
        lines.append(
            f"- **持仓披露期**：{comp.get('report_date')} | **前十合计占净值比**：`{comp.get('total_weight_pct')}%` "
            f"| **今日涨跌分布**：`{comp.get('up_count')}涨 / {comp.get('down_count')}跌 / {comp.get('flat_count')}平` (上涨家数占比 `{comp.get('breadth_up_pct')}%`)"
        )
        lines.append(
            f"- **重仓股加权涨跌幅**：`{comp.get('weighted_change_pct')}%`（对ETF净值直接贡献估算 `{comp.get('estimated_top10_contribution_pct'):+.3f}%`） "
            f"| **高于MA20权重占比**：`{comp.get('above_ma20_weighted_breadth_pct')}%` | **高于MA60权重占比**：`{comp.get('above_ma60_weighted_breadth_pct')}%` | **行业权重分布**：`{comp.get('industry_distribution_pct')}`"
        )
        lines.append(
            f"- **重仓股基本面财务增速汇总**：加权营收同比 **`{f_sum.get('weighted_rev_yoy_pct')}%`** | 加权归母净利同比 **`{f_sum.get('weighted_profit_yoy_pct')}%`**（中位数 **`{f_sum.get('median_profit_yoy_pct')}%`**，正增长 `{f_sum.get('profit_positive_growth_count')}/{comp.get('count')}` 家） | 加权ROE **`{f_sum.get('weighted_roe_pct')}%`**"
        )
        if f_sum.get("latest_earnings_forecasts"):
            lines.append(
                f"  - **最新三季报/业绩预告速递**：{' ； '.join(f_sum['latest_earnings_forecasts'])}"
            )
        lines.append(
            f"- **重仓股两融资金汇总**：前十合计融资余额 `{m_sum.get('top10_total_fin_balance_yi')}亿` "
            f"| 合计1日融资净买 **`{m_sum.get('top10_fin_net_buy_1d_yi'):+.2f}亿`**（`{m_sum.get('top10_fin_inflow_1d_count')}/{comp.get('count')}` 家净流入） "
            f"| 合计5日融资净买 **`{m_sum.get('top10_fin_net_buy_5d_yi'):+.2f}亿`**（`{m_sum.get('top10_fin_inflow_5d_count')}/{comp.get('count')}` 家净流入） "
            f"| 合计10日融资净买 `{m_sum.get('top10_fin_net_buy_10d_yi'):+.2f}亿`"
        )
        lines.append("")
        lines.append(
            "| 代码 | 名称 | 权重 | 行业 | 最新价 | 今日涨跌 | 近20日 | 高于MA20 | PE(TTM)/PB | 营收同比 | 归母净利同比 | ROE | 最新业绩预告 | 融资余额(亿) | 1日/5日融资净买(亿) |"
        )
        lines.append("|---|---|---:|---|---:|---:|---:|---|---:|---:|---:|---:|---|---:|---:|")
        for c in comp.get("constituents", []):
            chg_s = f"{c['change_pct']:+.2f}%" if c.get("change_pct") is not None else "-"
            r20_s = f"{c['return_20d_pct']:+.2f}%" if c.get("return_20d_pct") is not None else "-"
            ma20_s = "是" if c.get("above_ma20") else ("否" if c.get("above_ma20") is False else "-")
            pe_s = f"{c['pe_ttm']:.1f}" if c.get("pe_ttm") is not None else "-"
            pb_s = f"{c['pb']:.2f}" if c.get("pb") is not None else "-"
            rev_s = f"{c['rev_yoy_pct']:+.1f}%" if c.get("rev_yoy_pct") is not None else "-"
            prf_s = f"{c['profit_yoy_pct']:+.1f}%" if c.get("profit_yoy_pct") is not None else "-"
            roe_s = f"{c['roe_pct']:.1f}%" if c.get("roe_pct") is not None else "-"
            pred_s = c.get("latest_earnings_forecast") or (c.get("report_period") or "-")
            fbal_s = f"{c['fin_balance_yi']:.2f}" if c.get("fin_balance_yi") is not None else "-"
            f1_s = f"{c['fin_net_buy_1d_yi']:+.2f}" if c.get("fin_net_buy_1d_yi") is not None else "-"
            f5_s = f"{c['fin_net_buy_5d_yi']:+.2f}" if c.get("fin_net_buy_5d_yi") is not None else "-"
            lines.append(
                f"| {c['symbol']} | {c['name']} | {c['weight_pct']}% | {c.get('industry') or '-'} | {c.get('current_price')} | {chg_s} | {r20_s} | {ma20_s} "
                f"| {pe_s}/{pb_s} | {rev_s} | {prf_s} | {roe_s} | {pred_s} | {fbal_s} | {f1_s} / {f5_s} |"
            )
    else:
        lines.append("- 暂无重仓股明细数据。")

    lines.append("\n### 五、东方财富相关新闻资讯候选")
    lines.append(f"- **检索关键词**：`{', '.join(data.get('news_keywords') or [])}`")
    if news:
        for idx, n in enumerate(news[:12], 1):
            c_hit = f" [关联重仓股: {','.join(n['matched_constituents'])}]" if n.get("matched_constituents") else ""
            lines.append(
                f"{idx}. **[{n['time']}] {n['title']}**（来源：{n['source']}，匹配分：{n['relevance_score']}{c_hit}）  \n"
                f"   摘要：{n['summary'][:200]}... [原文链接]({n['url']})"
            )
    else:
        lines.append("- 最近检索窗口内无相关新闻。")

    return "\n".join(lines)


def fetch_etf_info(
    raw_symbol: str,
    *,
    market_ctx: list[dict[str, Any]],
    overseas_ctx: dict[str, dict[str, Any]],
    macro_ctx: dict[str, dict[str, Any]] | None = None,
    breadth_vol_ctx: dict[str, Any] | None = None,
    market_margin_ctx: dict[str, Any] | None = None,
    analysis_time: datetime,
    news_days: int = DEFAULT_NEWS_DAYS,
    news_limit: int = DEFAULT_NEWS_LIMIT,
    kline_limit: int = DEFAULT_KLINE_LIMIT,
    extra_keywords: Iterable[str] = (),
) -> dict[str, Any]:
    """获取单只 ETF 的完整客观信息包。"""
    secid, quote = resolve_security(raw_symbol)
    bars = fetch_daily_bars(secid, limit=kline_limit, quote=quote)
    weekly_bars = fetch_weekly_bars(secid, limit=DEFAULT_WEEKLY_KLINE_LIMIT, quote=quote)
    tech = build_technical_summary(quote, bars)
    weekly_tech = build_weekly_technical_summary(quote, weekly_bars)
    cn10y_val = ((macro_ctx or {}).get("cn10y") or {}).get("price")
    profile = fetch_fund_profile_and_valuation(quote.symbol, cn10y_yield=cn10y_val)
    constituents_info = fetch_constituents_analysis(quote.symbol)
    trade_date = (quote.quote_time or "")[:10] or bars[-1].date
    share_flow = update_etf_share_archive(quote, trade_date=trade_date, bars=bars)

    idx_name = ((profile.get("index_valuation") or {}).get("index_name"))
    keywords = build_news_keywords(
        quote.symbol,
        quote.name,
        index_name=idx_name,
        constituents=constituents_info.get("constituents"),
        extra_keywords=extra_keywords,
    )
    news = fetch_relevant_news(
        keywords,
        constituents=constituents_info.get("constituents"),
        cutoff=analysis_time,
        days=news_days,
        limit=news_limit,
    )

    return {
        "symbol": quote.symbol,
        "name": quote.name,
        "secid": secid,
        "analysis_time": analysis_time.isoformat(sep=" ", timespec="seconds"),
        "market_phase": market_phase(analysis_time),
        "quote": quote.to_dict(),
        "fund_profile": profile,
        "technical_summary": tech,
        "weekly_technical_summary": weekly_tech,
        "recent_daily_bars": [b.to_dict() for b in bars[-30:]],
        "recent_weekly_bars": [b.to_dict() for b in weekly_bars[-26:]],
        "constituents_analysis": constituents_info,
        "share_flow": share_flow,
        "market_context": market_ctx,
        "market_breadth_and_volume": breadth_vol_ctx,
        "market_margin_context": market_margin_ctx,
        "overseas_context": overseas_ctx,
        "macro_and_commodities": macro_ctx,
        "news_keywords": keywords,
        "news": news,
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="ETF 全维客观信息与知名博主专栏采集工具 (etf-analyzer)")
    parser.add_argument(
        "--symbols",
        nargs="+",
        default=list(DEFAULT_SYMBOLS),
        help="ETF 代码，支持一个或多个（空格或逗号分隔），例如: 515070 159338",
    )
    parser.add_argument("--news-days", type=int, default=DEFAULT_NEWS_DAYS, help="东方财富新闻回看天数，默认 3")
    parser.add_argument("--news-limit", type=int, default=DEFAULT_NEWS_LIMIT, help="每只 ETF 最多返回的新闻条数，默认 15")
    parser.add_argument("--kline-limit", type=int, default=DEFAULT_KLINE_LIMIT, help="前复权日K线回看根数，默认 260（约1年）")
    parser.add_argument("--keywords", nargs="*", default=[], help="追加自定义新闻检索关键词")
    parser.add_argument(
        "--kol-users",
        nargs="*",
        default=[],
        help="临时追加要抓取的雪球博主 UID 或主页/专栏 URL（默认自动加载 data/kol_sources.json 中的搬砖小组等博主）",
    )
    parser.add_argument(
        "--kol-limit",
        type=int,
        default=None,
        help=f"每位知名博主抓取的最新专栏/文章篇数（默认使用配置值 {DEFAULT_KOL_LIMIT}）",
    )
    parser.add_argument("--no-kol", action="store_true", help="跳过知名博主最新专栏抓取")
    parser.add_argument(
        "--add-kol",
        nargs="+",
        metavar="ARG",
        help="永久添加新博主到 data/kol_sources.json，用法: --add-kol <雪球UID或URL> [博主名称] [风格备注]",
    )
    parser.add_argument("--output-dir", default="outputs", help="JSON 与 Markdown 信息文件保存目录，默认 outputs")
    parser.add_argument("--json-only", action="store_true", help="终端仅输出 JSON 格式数据")
    parser.add_argument("--log-level", default="WARNING", help="日志级别，默认 WARNING")
    args = parser.parse_args(argv)
    args.symbols = split_symbol_values(args.symbols)
    return args


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.WARNING),
        format="%(asctime)s %(levelname)s - %(message)s",
    )
    if args.add_kol:
        uid_or_url = args.add_kol[0]
        kol_name = args.add_kol[1] if len(args.add_kol) > 1 else ""
        kol_style = args.add_kol[2] if len(args.add_kol) > 2 else "市场观点与复盘"
        added = add_kol_source_to_config(uid_or_url, name=kol_name, style=kol_style)
        logging.warning("已将博主写入配置文件 %s: %s", KOL_SOURCES_FILE, added)

    analysis_time = datetime.now()
    market_ctx, overseas_ctx = fetch_market_and_overseas_context()
    macro_ctx = fetch_global_macro_and_commodities()
    breadth_vol_ctx = fetch_market_breadth_and_volume(analysis_time)
    market_margin_ctx = fetch_market_margin_context()
    fast_news_ctx = fetch_global_fast_news(limit=12)
    kol_ctx = (
        {"available": False, "kol_list": []}
        if args.no_kol
        else fetch_kol_columns(extra_users=args.kol_users, limit_override=args.kol_limit)
    )

    results: list[dict[str, Any]] = []
    md_sections: list[str] = []

    mkt_line = " | ".join(
        f"{m['名称']} `{m['最新价']}` ({m['涨跌幅_pct']:+.2f}%)"
        for m in market_ctx
        if m.get("涨跌幅_pct") is not None
    )
    ov_line = " | ".join(
        f"{v['name']} `{v['price']}` ({v['change_percent']:+.2f}%)"
        for v in overseas_ctx.values()
        if v.get("change_percent") is not None
    )
    asia_sox_line = " | ".join(
        f"{v['name']} `{v['price']}` (最新 `{v['change_pct']:+.2f}%` / 前日 `{v['prev_change_pct']:+.2f}%` / 5日 `{v['return_5d_pct']:+.2f}%`)"
        for k, v in macro_ctx.items()
        if v.get("category") in ("asia_index", "us_index") and v.get("change_pct") is not None
    )
    rate_fx_line = " | ".join(
        f"{v['name']} `{v['price']}` (最新 `{v['change_pct']:+.2f}%` / 5日 `{v['return_5d_pct']:+.2f}%`)"
        for k, v in macro_ctx.items()
        if v.get("category") == "rate_fx" and v.get("price") is not None
    )
    comm_line = " | ".join(
        f"{v['name']} `{v['price']}` (最新 `{v['change_pct']:+.2f}%` / 前日 `{v['prev_change_pct']:+.2f}%` / 5日 `{v['return_5d_pct']:+.2f}%`)"
        for k, v in macro_ctx.items()
        if v.get("category") == "commodity" and v.get("price") is not None
    )

    bv_lines: list[str] = []
    if breadth_vol_ctx.get("available"):
        bv = breadth_vol_ctx
        breadth_str = (
            f"沪深上涨 `{bv.get('up_count')}` 家 / 下跌 `{bv.get('down_count')}` 家 / 平盘 `{bv.get('flat_count')}` 家（上涨占比 **{bv.get('up_ratio_pct')}%**） | 实时总成交额 `{bv.get('realtime_total_amount_yi')}亿`"
            if bv.get("up_count") is not None
            else ""
        )
        if bv.get("is_intraday") and bv.get("estimated_full_day_amount_yi"):
            breadth_str += f"（按已交易 `{bv.get('elapsed_trading_minutes')}分钟` 线性折算全天约 `{bv.get('estimated_full_day_amount_yi')}亿`，占60日峰值 `{bv.get('estimated_vs_60d_peak_pct')}%` / 占120日峰值 `{bv.get('estimated_vs_120d_peak_pct')}%`）"
        if breadth_str:
            bv_lines.append(f"- **全A市场宽度与实时量能**：{breadth_str}")
        bv_lines.append(
            f"- **全A成交额缩量择时指标（<45%低点监测）**：**{bv.get('volume_shrinkage_status')}**  \n"
            f"  - 上一完整日({bv.get('last_full_day_date')})成交 `{bv.get('last_full_day_amount_yi')}亿`（占60日峰值 `{bv.get('last_full_vs_60d_peak_pct')}%` / 占120日峰值 **{bv.get('last_full_vs_120d_peak_pct')}%**）  \n"
            f"  - 近5日最低完整日({bv.get('min_5d_full_date')})成交 `{bv.get('min_5d_full_amount_yi')}亿`（占60日峰值 `{bv.get('min_5d_vs_60d_peak_pct')}%` / 占120日峰值 **{bv.get('min_5d_vs_120d_peak_pct')}%**）  \n"
            f"  - 峰值坐标：60日峰值 `{bv.get('peak_60d_amount_yi')}亿` ({bv.get('peak_60d_date')}) | 120日峰值 `{bv.get('peak_120d_amount_yi')}亿` ({bv.get('peak_120d_date')}) | 5日均量 `{bv.get('avg_5d_amount_yi')}亿` / 20日均量 `{bv.get('avg_20d_amount_yi')}亿`"
        )
    if market_margin_ctx.get("available"):
        mm = market_margin_ctx
        bv_lines.append(
            f"- **全A两融杠杆资金（截至 {mm.get('date')}）**：两融总余额 `{mm.get('total_margin_balance_yi')}亿`（融资 `{mm.get('fin_balance_yi')}亿` / 融券 `{mm.get('loan_balance_yi')}亿`，占流通市值 `{mm.get('fin_ratio_of_float_mv_pct')}%`）  \n"
            f"  - **杠杆资金流向**：**{mm.get('status_summary')}**（近20日累计 `{mm.get('net_buy_20d_yi'):+.2f}亿`，20日余额变化 `{mm.get('fin_change_20d_pct'):+.2f}%`）"
        )

    fast_news_md = ""
    if fast_news_ctx:
        fn_items = [
            f"  {i}. `[{fn['time']}]` **{fn['title']}**"
            + (f" — {fn['summary'][:120]}" if fn.get("summary") and fn["summary"] != fn["title"] else "")
            for i, fn in enumerate(fast_news_ctx[:10], 1)
        ]
        fast_news_md = "- **7×24小时全球宏观与产业硬核快讯**：\n" + "\n".join(fn_items) + "\n"

    header_md = (
        f"# ETF 客观市场信息采集报告\n\n"
        f"- **采集时间**：{analysis_time:%Y-%m-%d %H:%M:%S}（{market_phase(analysis_time)}）\n"
        f"- **A股市场基准**：{mkt_line or '暂无'}\n"
        + ("\n".join(bv_lines) + "\n" if bv_lines else "")
        + f"- **亚太与费城半导体**：{asia_sox_line or '暂无'}\n"
        f"- **港美股与AI全链条风向标（含CoreWeave/美光/阿斯麦/台积电）**：{ov_line or '暂无'}\n"
        f"- **全球宏观利率与汇率**：{rate_fx_line or '暂无'}\n"
        f"- **全球能源与大宗商品底座**：{comm_line or '暂无'}\n"
        + fast_news_md
    )

    for sym in args.symbols:
        try:
            data = fetch_etf_info(
                sym,
                market_ctx=market_ctx,
                overseas_ctx=overseas_ctx,
                macro_ctx=macro_ctx,
                breadth_vol_ctx=breadth_vol_ctx,
                market_margin_ctx=market_margin_ctx,
                analysis_time=analysis_time,
                news_days=args.news_days,
                news_limit=args.news_limit,
                kline_limit=args.kline_limit,
                extra_keywords=args.keywords,
            )
            results.append(data)
            md_sections.append(format_markdown_report(data))
        except Exception as exc:
            logging.exception("获取 %s 信息失败", sym)
            md_sections.append(f"## {sym} 信息获取失败\n\n错误信息：`{exc}`")

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = "_".join(s.split(".")[-1] for s in args.symbols)
    ts_str = f"{analysis_time:%Y%m%d_%H%M%S}"
    md_path = out_dir / f"etf_info_{stem}_{ts_str}.md"
    json_path = out_dir / f"etf_info_{stem}_{ts_str}.json"

    kol_md = format_kol_markdown_section(kol_ctx)
    body_blocks = ([kol_md.strip()] if kol_md.strip() else []) + md_sections
    full_md = header_md + "\n---\n\n" + "\n\n---\n\n".join(body_blocks) + "\n"
    md_path.write_text(full_md, encoding="utf-8")
    json_payload = {
        "collected_at": analysis_time.isoformat(sep=" ", timespec="seconds"),
        "market_phase": market_phase(analysis_time),
        "market_context": market_ctx,
        "market_breadth_and_volume": breadth_vol_ctx,
        "market_margin_context": market_margin_ctx,
        "overseas_context": overseas_ctx,
        "macro_and_commodities": macro_ctx,
        "global_fast_news": fast_news_ctx,
        "kol_columns": kol_ctx,
        "etfs": results,
    }
    json_path.write_text(json.dumps(json_payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

    if args.json_only:
        print(json.dumps(json_payload, ensure_ascii=False, indent=2, default=str))
    else:
        print(full_md)
        print(f"\n[数据已保存]\n- Markdown 汇总: {md_path.resolve()}\n- JSON 原始数据: {json_path.resolve()}")


if __name__ == "__main__":
    main()




